import 'dart:async';

import 'package:flutter/material.dart';

import 'src/config/app_visibility_flags.dart';
import 'src/data/chat_repository.dart';
import 'src/data/custom_menu_request_repository.dart';
import 'src/data/order_repository.dart';
import 'src/data/sample_data.dart';
import 'src/data/seller_verification_repository.dart';
import 'src/data/seller_notes_repository.dart';
import 'src/models/app_models.dart';
import 'src/screens/buyer/buyer_experience.dart';
import 'src/screens/root/role_login_page.dart';
import 'src/screens/seller/seller_menu_manager_page.dart';
import 'src/screens/seller/seller_verification_page.dart';
import 'src/state/app_session_controller.dart';
import 'src/state/seller_menu_controller.dart';
import 'src/theme/app_theme.dart';
import 'src/utils/chat_payloads.dart';
import 'src/widgets/seller_property_switcher_card.dart';

void main() {
  runApp(const AskiaKostApp());
}

class AskiaKostApp extends StatelessWidget {
  const AskiaKostApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Askia Kost',
      theme: buildAppTheme(),
      home: const SplashFlow(),
    );
  }
}

class SplashFlow extends StatefulWidget {
  const SplashFlow({super.key});

  @override
  State<SplashFlow> createState() => _SplashFlowState();
}

class _SplashFlowState extends State<SplashFlow> {
  int _step = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _scheduleNext();
  }

  void _scheduleNext() {
    _timer?.cancel();
    _timer = Timer(Duration(milliseconds: _step == 0 ? 1400 : 1700), () {
      if (!mounted) return;
      if (_step < 2) {
        setState(() {
          _step += 1;
        });
        _scheduleNext();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_step == 0) {
      return const SplashLogoScreen();
    }
    if (_step == 1) {
      return const SplashTaglineScreen();
    }
    return const RootModeHost();
  }
}

class SplashLogoScreen extends StatelessWidget {
  const SplashLogoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: <Color>[Color(0xFFF1FCF4), Color(0xFFFFFFFF)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const AppLogo(size: 86),
              const SizedBox(height: 18),
              Text(
                'Askia Kost',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              Text(
                'Temukan kos yang pas untuk lokasi dan budgetmu.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SplashTaglineScreen extends StatelessWidget {
  const SplashTaglineScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(28),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: <Color>[Color(0xFFFFFFFF), Color(0xFFF3FBF6)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const AppLogo(size: 72),
            const SizedBox(height: 22),
            Text(
              'Askia Kost',
              style: Theme.of(
                context,
              ).textTheme.titleLarge?.copyWith(color: kPrimaryDark),
            ),
            const SizedBox(height: 12),
            Text(
              'Aplikasi pencarian kos yang membantu kamu menemukan hunian di lokasi yang tepat.',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 12),
            Text(
              'Cari properti, jelajahi peta, chat pemilik, dan kelola beberapa kos dalam satu aplikasi.',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ],
        ),
      ),
    );
  }
}

class RootModeHost extends StatefulWidget {
  const RootModeHost({super.key});

  @override
  State<RootModeHost> createState() => _RootModeHostState();
}

class _RootModeHostState extends State<RootModeHost> {
  final AppSessionController _sessionController = AppSessionController();

  @override
  void initState() {
    super.initState();
    _sessionController.initializeFirebase();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _sessionController,
      builder: (BuildContext context, _) {
        return AnimatedSwitcher(
          duration: const Duration(milliseconds: 220),
          child:
              _sessionController.activeMode == AppMode.seller
                  ? SellerShell(
                    key: const ValueKey<String>('seller-shell'),
                    onLogout: () {
                      _sessionController.logout();
                    },
                    statusMessage: _sessionController.authStatus,
                    isCloudReady: _sessionController.firebaseReady,
                  )
                  : _sessionController.activeMode == AppMode.admin
                  ? AdminShell(
                    key: const ValueKey<String>('admin-shell'),
                    onLogout: () {
                      _sessionController.logout();
                    },
                    statusMessage: _sessionController.authStatus,
                    isCloudReady: _sessionController.firebaseReady,
                  )
                  : BuyerShell(
                    key: ValueKey<String>(
                      _sessionController.isAuthenticated
                          ? 'buyer-shell-auth'
                          : 'buyer-shell-guest',
                    ),
                    isGuest: !_sessionController.isAuthenticated,
                    onRequireLogin: _openRoleLogin,
                    onSwitchMode: () {
                      if (_sessionController.activeMode == AppMode.buyer) {
                        _sessionController.switchMode(AppMode.seller);
                        return;
                      }
                      _openRoleLogin(context, preferredMode: AppMode.seller);
                    },
                    onLogout: () {
                      _sessionController.logout();
                    },
                    statusMessage: _sessionController.authStatus,
                    isCloudReady: _sessionController.firebaseReady,
                  ),
        );
      },
    );
  }

  Future<void> _openRoleLogin(
    BuildContext context, {
    AppMode? preferredMode,
  }) async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => RoleLoginPage(
          sessionController: _sessionController,
          preferredMode: preferredMode,
          onClose: () => Navigator.of(context).pop(),
        ),
      ),
    );
  }
}

class AdminShell extends StatefulWidget {
  const AdminShell({
    super.key,
    required this.onLogout,
    required this.statusMessage,
    required this.isCloudReady,
  });

  final VoidCallback onLogout;
  final String statusMessage;
  final bool isCloudReady;

  @override
  State<AdminShell> createState() => _AdminShellState();
}

class _AdminShellState extends State<AdminShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> tabs = <Widget>[
      AdminDashboardPage(
        onLogout: widget.onLogout,
        statusMessage: widget.statusMessage,
        isCloudReady: widget.isCloudReady,
      ),
      AdminVendorPage(
        statusMessage: widget.statusMessage,
        isCloudReady: widget.isCloudReady,
      ),
      AdminOrdersPage(
        statusMessage: widget.statusMessage,
        isCloudReady: widget.isCloudReady,
      ),
    ];

    return Scaffold(
      body: SafeArea(child: tabs[_index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFFFFF1E6),
        onDestinationSelected: (int value) {
          setState(() {
            _index = value;
          });
        },
        destinations: const <NavigationDestination>[
          NavigationDestination(
            icon: Icon(Icons.space_dashboard_rounded),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.store_mall_directory_outlined),
            label: 'Properti',
          ),
          NavigationDestination(
            icon: Icon(Icons.fact_check_outlined),
            label: 'Booking',
          ),
        ],
      ),
    );
  }
}

class SellerShell extends StatefulWidget {
  const SellerShell({
    super.key,
    required this.onLogout,
    required this.statusMessage,
    required this.isCloudReady,
  });

  final VoidCallback onLogout;
  final String statusMessage;
  final bool isCloudReady;

  @override
  State<SellerShell> createState() => _SellerShellState();
}

class _SellerShellState extends State<SellerShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> tabs = <Widget>[
      SellerDashboardPage(
        onOpenMenu: () {
          setState(() {
            _index = 1;
          });
        },
        onOpenOrders: () {
          setState(() {
            _index = 2;
          });
        },
        onOpenChat: () {
          setState(() {
            _index = 3;
          });
        },
        onOpenVerification: () async {
          await Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => const SellerVerificationPage(),
            ),
          );
          if (mounted) {
            setState(() {});
          }
        },
        statusMessage: widget.statusMessage,
        isCloudReady: widget.isCloudReady,
      ),
      const SellerMenuManagerPage(),
      SellerOrdersPage(
        statusMessage: widget.statusMessage,
        isCloudReady: widget.isCloudReady,
      ),
      SellerChatListPage(
        onLogout: widget.onLogout,
        statusMessage: widget.statusMessage,
        isCloudReady: widget.isCloudReady,
      ),
    ];

    return Scaffold(
      body: SafeArea(child: tabs[_index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFFE8EEFF),
        onDestinationSelected: (int value) {
          setState(() {
            _index = value;
          });
        },
        destinations: const <NavigationDestination>[
          NavigationDestination(
            icon: Icon(Icons.dashboard_customize_rounded),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.apartment_rounded),
            label: 'Properti',
          ),
          NavigationDestination(
            icon: Icon(Icons.inventory_2_outlined),
            label: 'Booking',
          ),
          NavigationDestination(
            icon: Icon(Icons.forum_outlined),
            label: 'Chat',
          ),
        ],
      ),
    );
  }
}

class SellerDashboardPage extends StatefulWidget {
  const SellerDashboardPage({
    super.key,
    required this.onOpenMenu,
    required this.onOpenOrders,
    required this.onOpenChat,
    required this.onOpenVerification,
    required this.statusMessage,
    required this.isCloudReady,
  });

  final VoidCallback onOpenMenu;
  final VoidCallback onOpenOrders;
  final VoidCallback onOpenChat;
  final VoidCallback onOpenVerification;
  final String statusMessage;
  final bool isCloudReady;

  @override
  State<SellerDashboardPage> createState() => _SellerDashboardPageState();
}

class _SellerDashboardPageState extends State<SellerDashboardPage> {
  final SellerMenuController _menuController = SellerMenuController.instance;
  List<String> _notes = <String>[];
  SellerVerificationData _verificationData = SellerVerificationRepository.fallback;

  @override
  void initState() {
    super.initState();
    _menuController.addListener(_reloadNotes);
    SellerVerificationRepository.updates.addListener(_reloadVerification);
    _reloadNotes();
    _reloadVerification();
  }

  @override
  void dispose() {
    _menuController.removeListener(_reloadNotes);
    SellerVerificationRepository.updates.removeListener(_reloadVerification);
    super.dispose();
  }

  Future<void> _reloadNotes() async {
    await SellerNotesRepository.ensureLoaded();
    if (!mounted) {
      return;
    }
    setState(() {
      _notes = SellerNotesRepository.notesForVendor(_menuController.activeVendorId);
    });
  }

  Future<void> _reloadVerification() async {
    await SellerVerificationRepository.ensureLoaded();
    if (!mounted) {
      return;
    }
    setState(() {
      _verificationData = SellerVerificationRepository.current();
    });
  }

  Future<void> _openNoteEditor({int? index}) async {
    final String? value = await showDialog<String>(
      context: context,
      builder: (BuildContext context) => _SellerNoteDialog(
        initialText: index == null ? '' : _notes[index],
        isEditing: index != null,
      ),
    );
    if (value == null || value.isEmpty) {
      return;
    }
    final List<String> updated = List<String>.from(_notes);
    if (index == null) {
      updated.add(value);
    } else {
      updated[index] = value;
    }
    await SellerNotesRepository.saveNotes(_menuController.activeVendorId, updated);
    await _reloadNotes();
  }

  Future<void> _removeNote(int index) async {
    final List<String> updated = List<String>.from(_notes)..removeAt(index);
    await SellerNotesRepository.saveNotes(_menuController.activeVendorId, updated);
    await _reloadNotes();
  }

  Future<void> _showSellerNotifications(Vendor activeVendor) async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      builder: (BuildContext context) {
        return _SellerNotificationsSheet(
          vendor: activeVendor,
          onOpenOrders: widget.onOpenOrders,
          onOpenChat: widget.onOpenChat,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<Vendor> ownedVendors = _menuController.ownedVendors(sampleVendors);
    final Vendor activeVendor = ownedVendors.firstWhere(
      (Vendor vendor) => vendor.id == _menuController.activeVendorId,
      orElse: () => ownedVendors.first,
    );
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'Dashboard Pemilik',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                ],
              ),
            ),
            AnimatedBuilder(
              animation: Listenable.merge(<Listenable>[
                OrderRepository.updates,
                ChatRepository.updates,
                CustomMenuRequestRepository.updates,
              ]),
              builder: (BuildContext context, _) {
                final int notificationCount =
                    _buildSellerNotifications(activeVendor).length;
                return NotificationBellButton(
                  count: notificationCount,
                  onTap: () => _showSellerNotifications(activeVendor),
                );
              },
            ),
          ],
        ),
        if (kShowInternalStatusBanners) ...<Widget>[
          const SizedBox(height: 18),
          DemoModeBanner(
            title: widget.isCloudReady ? 'Seller Cloud Aktif' : 'Seller Demo Aktif',
            message: widget.statusMessage,
          ),
        ],
        const SizedBox(height: 18),
        if (!_verificationData.hasSubmittedVerification) ...<Widget>[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFFFFBEB),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: const Color(0xFFFCD34D)),
            ),
            child: Row(
              children: <Widget>[
                const Icon(
                  Icons.verified_user_outlined,
                  color: Color(0xFF92400E),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Lengkapi verifikasi pemilik agar properti siap ditayangkan.',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: const Color(0xFF92400E),
                    ),
                  ),
                ),
                TextButton(
                  onPressed: widget.onOpenVerification,
                  child: const Text('Verifikasi'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
        ],
        if (ownedVendors.length > 1) ...<Widget>[
          SellerPropertySwitcherCard(
            activeVendor: activeVendor,
            ownedVendors: ownedVendors,
            title: 'Pilih properti yang ingin dikelola',
            subtitle:
                'Akun ${activeVendor.brandName} bisa berpindah antar lokasi tanpa membuat akun baru.',
            onChanged: (String? value) async {
              if (value == null) {
                return;
              }
              await _menuController.setActiveVendor(value);
            },
          ),
          const SizedBox(height: 18),
        ],
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: <Color>[Color(0xFF0F172A), Color(0xFF1E293B)],
            ),
            borderRadius: BorderRadius.circular(28),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                activeVendor.brandName,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '${activeVendor.name} • ${activeVendor.locationLabel}',
                style: const TextStyle(
                  color: Color(0xFFE2E8F0),
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: <Widget>[
                  _SellerInfoChip(
                    label: activeVendor.isOpen ? 'Buka' : 'Tutup',
                    icon: activeVendor.isOpen
                        ? Icons.check_circle_rounded
                        : Icons.pause_circle_rounded,
                  ),
                  _SellerInfoChip(
                    label: activeVendor.areaGroup,
                    icon: Icons.place_rounded,
                  ),
                  _SellerInfoChip(
                    label: '${ownedVendors.length} properti',
                    icon: Icons.apartment_rounded,
                  ),
                  _SellerInfoChip(
                    label: activeVendor.minimumOrderLabel,
                    icon: Icons.payments_outlined,
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        SellerStatsRow(
          onOpenMenu: widget.onOpenMenu,
          onOpenOrders: widget.onOpenOrders,
          onOpenChat: widget.onOpenChat,
        ),
        const SizedBox(height: 18),
        Text(
          'Pertanyaan pencari kos',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 12),
        StreamBuilder<List<CustomMenuRequest>>(
          stream: CustomMenuRequestRepository.watchSellerRequests(activeVendor.id),
          initialData: const <CustomMenuRequest>[],
          builder:
              (
                BuildContext context,
                AsyncSnapshot<List<CustomMenuRequest>> snapshot,
              ) {
                final List<CustomMenuRequest> requests =
                    snapshot.data ?? <CustomMenuRequest>[];
                    if (requests.isEmpty) {
                      return Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: kBorder),
                    ),
                    child: Text(
                      'Belum ada pertanyaan atau minat sewa yang masuk.',
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  );
                }
                return Column(
                  children: requests
                      .map(
                        (CustomMenuRequest request) => Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: SellerCustomRequestCard(request: request),
                        ),
                      )
                      .toList(),
                );
              },
        ),
        const SizedBox(height: 18),
        Row(
          children: <Widget>[
            Expanded(
              child: Text(
                'Catatan penjual',
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ),
            IconButton(
              onPressed: () => _openNoteEditor(),
              icon: const Icon(Icons.add_rounded),
              tooltip: 'Tambah catatan',
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (_notes.isEmpty)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kBorder),
            ),
            child: Text(
              'Belum ada catatan. Tekan tombol + untuk menambahkan note penjual.',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ),
        ...List<Widget>.generate(
          _notes.length,
          (int index) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: SellerTaskCard(
              text: _notes[index],
              onEdit: () => _openNoteEditor(index: index),
              onDelete: () => _removeNote(index),
            ),
          ),
        ),
      ],
    );
  }
}

class AdminDashboardPage extends StatelessWidget {
  const AdminDashboardPage({
    super.key,
    required this.onLogout,
    required this.statusMessage,
    required this.isCloudReady,
  });

  final VoidCallback onLogout;
  final String statusMessage;
  final bool isCloudReady;

  @override
  Widget build(BuildContext context) {
    final int vendorCount = sampleVendors.length;
    final int openVendors = sampleVendors.where((Vendor vendor) => vendor.isOpen).length;
    final int closedVendors = vendorCount - openVendors;
    final int totalMenu = sampleVendors.fold<int>(
      0,
      (int total, Vendor vendor) =>
          total +
          vendor.packages.length +
          vendor.foods.length +
          vendor.drinks.length +
          vendor.others.length,
    );
    final List<OrderRecord> allOrders = OrderRepository.localAllOrders();
    final int activeOrders = allOrders
        .where((OrderRecord order) => order.status != 'Selesai' && order.status != 'Dibatalkan')
        .length;
    final int unpaidOrders = allOrders
        .where((OrderRecord order) => order.paymentStatus != 'Lunas')
        .length;
    final int openRequests = sampleVendors.fold<int>(
      0,
      (int total, Vendor vendor) =>
          total + CustomMenuRequestRepository.localSellerRequests(vendor.id)
              .where((CustomMenuRequest request) => request.status == 'Masuk')
              .length,
    );

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(
                'Dashboard Admin',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
            ),
            TextButton.icon(
              onPressed: onLogout,
              icon: const Icon(Icons.logout_rounded),
              label: const Text('Keluar'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          'Pantau properti, kamar, dan booking dari satu panel admin.',
          style: Theme.of(context).textTheme.bodyLarge,
        ),
        if (kShowInternalStatusBanners) ...<Widget>[
          const SizedBox(height: 18),
          DemoModeBanner(
            title: isCloudReady ? 'Admin Cloud Aktif' : 'Admin Demo Aktif',
            message: statusMessage,
          ),
        ],
        const SizedBox(height: 18),
        Row(
          children: <Widget>[
            Expanded(
              child: SellerStatCard(
                label: 'Vendor buka',
                value: '$openVendors',
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: SellerStatCard(
                label: 'Order aktif',
                value: '$activeOrders',
              ),
            ),
            const SizedBox(width: 10),
            Expanded(child: SellerStatCard(label: 'Request baru', value: '$openRequests')),
          ],
        ),
        const SizedBox(height: 18),
        Row(
          children: <Widget>[
            Expanded(
              child: SellerStatCard(label: 'Vendor tutup', value: '$closedVendors'),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: SellerStatCard(label: 'Menu tercatat', value: '$totalMenu'),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: SellerStatCard(label: 'Belum lunas', value: '$unpaidOrders'),
            ),
          ],
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kBorder),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Prioritas Admin',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 12),
              const SellerTaskCard(
                text: 'Verifikasi properti baru yang masuk ke sistem.',
              ),
              const SizedBox(height: 10),
              SellerTaskCard(
                text: unpaidOrders == 0
                    ? 'Tidak ada booking yang menunggu pelunasan saat ini.'
                    : '$unpaidOrders booking masih menunggu pelunasan dari penyewa.',
              ),
              const SizedBox(height: 10),
              SellerTaskCard(
                text: openRequests == 0
                    ? 'Semua pertanyaan penyewa sudah tertangani.'
                    : '$openRequests percakapan minat sewa belum dibalas pemilik.',
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class AdminVendorPage extends StatelessWidget {
  const AdminVendorPage({
    super.key,
    required this.statusMessage,
    required this.isCloudReady,
  });

  final String statusMessage;
  final bool isCloudReady;

  @override
  Widget build(BuildContext context) {
    final int openCount = sampleVendors.where((Vendor vendor) => vendor.isOpen).length;
    final int closedCount = sampleVendors.length - openCount;
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
      children: <Widget>[
        Text('Properti Terdaftar', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 8),
        Text(
          'Ringkasan properti yang tampil ke pencari kos dan pemilik.',
          style: Theme.of(context).textTheme.bodyLarge,
        ),
        if (kShowInternalStatusBanners) ...<Widget>[
          const SizedBox(height: 18),
          DemoModeBanner(
            title: isCloudReady ? 'Sinkron Vendor Aktif' : 'Vendor Demo Tersedia',
            message: statusMessage,
          ),
        ],
        const SizedBox(height: 18),
        Row(
          children: <Widget>[
            Expanded(child: SellerStatCard(label: 'Toko buka', value: '$openCount')),
            const SizedBox(width: 10),
            Expanded(child: SellerStatCard(label: 'Toko tutup', value: '$closedCount')),
          ],
        ),
        const SizedBox(height: 18),
        ...sampleVendors.map(
          (Vendor vendor) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: kBorder),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          vendor.name,
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: vendor.isOpen
                              ? const Color(0xFFE8F7EE)
                              : const Color(0xFFFFF4E5),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          vendor.isOpen ? 'Buka' : 'Tutup',
                          style: TextStyle(
                            color: vendor.isOpen
                                ? const Color(0xFF15803D)
                                : const Color(0xFFB45309),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    vendor.locationLabel,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    vendor.serviceAreaSummary,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 10),
                  Text(
                    '${vendor.packages.length + vendor.foods.length + vendor.drinks.length + vendor.others.length} menu tercatat',
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class AdminOrdersPage extends StatelessWidget {
  const AdminOrdersPage({
    super.key,
    required this.statusMessage,
    required this.isCloudReady,
  });

  final String statusMessage;
  final bool isCloudReady;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<OrderRecord>>(
      stream: OrderRepository.watchBuyerOrders('buyer-demo'),
      initialData: const <OrderRecord>[],
      builder: (BuildContext context, AsyncSnapshot<List<OrderRecord>> snapshot) {
        final List<OrderRecord> orders = snapshot.data ?? <OrderRecord>[];
        final int activeOrders = orders
            .where((OrderRecord order) => order.status != 'Selesai' && order.status != 'Dibatalkan')
            .length;
        final int unpaidOrders = orders
            .where((OrderRecord order) => order.paymentStatus != 'Lunas')
            .length;
        final int cancelledOrders = orders
            .where((OrderRecord order) => order.status == 'Dibatalkan')
            .length;
        return ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
          children: <Widget>[
            Text('Monitoring Order', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            Text(
              'Admin melihat order yang masuk pada demo buyer saat ini.',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            if (kShowInternalStatusBanners) ...<Widget>[
              const SizedBox(height: 18),
              DemoModeBanner(
                title: isCloudReady ? 'Monitoring Online' : 'Monitoring Demo',
                message: statusMessage,
              ),
            ],
            const SizedBox(height: 18),
            Row(
              children: <Widget>[
                Expanded(child: SellerStatCard(label: 'Order aktif', value: '$activeOrders')),
                const SizedBox(width: 10),
                Expanded(child: SellerStatCard(label: 'Belum lunas', value: '$unpaidOrders')),
                const SizedBox(width: 10),
                Expanded(child: SellerStatCard(label: 'Dibatalkan', value: '$cancelledOrders')),
              ],
            ),
            const SizedBox(height: 18),
            if (orders.isEmpty)
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: kBorder),
                ),
                child: Text(
                  'Belum ada order yang masuk. Buat pesanan dari sisi pembeli untuk melihat monitoring admin bergerak.',
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ),
            ...orders.map(
              (OrderRecord order) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: kBorder),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      OrderStatusCard(
                        status: order.status,
                        title: order.vendorName,
                        subtitle:
                            '${order.compactMenuLabel} • ${order.totalUnits} unit',
                        total: formatRupiah(order.totalPrice),
                        schedule: order.scheduleLabel,
                        embedded: true,
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              'Buyer: ${order.buyerName}',
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                          ),
                          _SellerPaymentPill(status: order.paymentStatus),
                        ],
                      ),
                      if (order.remainingPayment > 0) ...<Widget>[
                        const SizedBox(height: 8),
                        Text(
                          'Sisa pelunasan ${formatRupiah(order.remainingPayment)}',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                      if (order.lineItems.length > 1) ...<Widget>[
                        const SizedBox(height: 10),
                        Text(
                          '${order.lineItems.length} item dalam 1 checkout',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class SellerOrdersPage extends StatelessWidget {
  const SellerOrdersPage({
    super.key,
    required this.statusMessage,
    required this.isCloudReady,
  });

  final String statusMessage;
  final bool isCloudReady;

  @override
  Widget build(BuildContext context) {
    final SellerMenuController controller = SellerMenuController.instance;
    return AnimatedBuilder(
      animation: controller,
      builder: (BuildContext context, _) {
        final List<Vendor> ownedVendors = controller.ownedVendors(sampleVendors);
        final Vendor activeVendor = ownedVendors.firstWhere(
          (Vendor vendor) => vendor.id == controller.activeVendorId,
          orElse: () => ownedVendors.first,
        );
        return StreamBuilder<List<OrderRecord>>(
          stream: OrderRepository.watchSellerOrders(controller.activeVendorId),
          initialData: OrderRepository.localSellerOrders(controller.activeVendorId),
          builder:
              (BuildContext context, AsyncSnapshot<List<OrderRecord>> snapshot) {
                final List<OrderRecord> orders = snapshot.data ?? <OrderRecord>[];
                return ListView(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
                  children: <Widget>[
                    Text(
                      'Booking Masuk',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${activeVendor.brandName} • ${activeVendor.name}',
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                    if (ownedVendors.length > 1) ...<Widget>[
                      const SizedBox(height: 14),
                      SellerPropertySwitcherCard(
                        activeVendor: activeVendor,
                        ownedVendors: ownedVendors,
                        subtitle:
                            'Pindah properti aktif untuk melihat booking tiap lokasi secara terpisah.',
                        onChanged: (String? value) async {
                          if (value == null) {
                            return;
                          }
                          await controller.setActiveVendor(value);
                        },
                      ),
                    ],
                    if (kShowInternalStatusBanners) ...<Widget>[
                      const SizedBox(height: 14),
                      DemoModeBanner(
                        title: isCloudReady ? 'Order Tersinkron' : 'Order Demo Aktif',
                        message: statusMessage,
                      ),
                    ],
                    const SizedBox(height: 14),
                    if (orders.isEmpty)
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: kBorder),
                        ),
                        child: Text(
                          'Belum ada booking masuk untuk properti ini.',
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                      ),
                    ...orders.map(
                      (OrderRecord order) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: SellerOrderCard(order: order),
                      ),
                    ),
                  ],
                );
              },
        );
      },
    );
  }
}

class SellerOrderCard extends StatelessWidget {
  const SellerOrderCard({super.key, required this.order});

  final OrderRecord order;

  String? get _nextStatus => switch (order.status) {
        'Diproses' => 'Dikirim',
        'Dikirim' => 'Selesai',
        _ => null,
      };

  String get _nextStatusLabel => switch (_nextStatus) {
        'Dikirim' => 'Tandai dikirim',
        'Selesai' => 'Tandai selesai',
        _ => 'Status final',
      };

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () {
        showOrderDetailsSheet(
          context,
          order: order,
          title: 'Pesanan dari ${order.buyerName}',
          subtitle: '${order.compactMenuLabel} • ${order.totalUnits} unit',
          footer: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: kBorder),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(
                      child: _SellerPaymentSummaryCard(
                        label: 'DP masuk',
                        value: formatRupiah(order.amountPaid),
                        accent: kPrimaryDark,
                        background: const Color(0xFFF0FDF4),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _SellerPaymentSummaryCard(
                        label: 'Sisa bayar',
                        value: formatRupiah(order.remainingPayment),
                        accent: const Color(0xFFB45309),
                        background: const Color(0xFFFFFBEB),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Text(
                  order.status == 'Dibatalkan' ? 'Status pesanan' : 'Ubah status',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 10),
                if (order.status == 'Dibatalkan')
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF1F2),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: const Color(0xFFFECDD3)),
                    ),
                    child: Text(
                      order.cancelReason.isEmpty
                          ? 'Pesanan ini sudah dibatalkan oleh pembeli dan tidak bisa diubah lagi.'
                          : 'Pesanan ini sudah dibatalkan oleh pembeli.\nAlasan: ${order.cancelReason}',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: const Color(0xFFB91C1C),
                      ),
                    ),
                  )
                else if (_nextStatus == null)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF0FDF4),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: const Color(0xFFBBF7D0)),
                    ),
                    child: Text(
                      'Pesanan ini sudah selesai dan tidak perlu diubah lagi.',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: const Color(0xFF166534),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  )
                else
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () {
                        OrderRepository.updateOrderStatus(
                          orderId: order.id,
                          status: _nextStatus!,
                        );
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        _nextStatus == 'Dikirim'
                            ? Icons.local_shipping_rounded
                            : Icons.check_circle_rounded,
                      ),
                      label: Text(_nextStatusLabel),
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFF1D4ED8),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
      child: Ink(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: kBorder),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            OrderStatusCard(
              status: order.status,
              title: 'Pesanan dari ${order.buyerName}',
              subtitle:
                  '${order.compactMenuLabel} • ${order.totalUnits} unit',
              total: formatRupiah(order.totalPrice),
              schedule: order.scheduleLabel,
              embedded: true,
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                _SellerPaymentPill(status: order.paymentStatus),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    order.remainingPayment > 0
                        ? 'Sisa ${formatRupiah(order.remainingPayment)}'
                        : 'Pembayaran sudah lunas',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    order.notes.isEmpty
                        ? 'Tap untuk lihat invoice dan ubah status'
                        : 'Tap untuk lihat invoice, status, dan catatan',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ),
                const Icon(Icons.chevron_right_rounded, color: kMuted),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SellerPaymentPill extends StatelessWidget {
  const _SellerPaymentPill({required this.status});

  final String status;

  @override
  Widget build(BuildContext context) {
    final Color background = status == 'Lunas'
        ? const Color(0xFFE8F7EE)
        : const Color(0xFFFFF4E5);
    final Color foreground = status == 'Lunas'
        ? const Color(0xFF15803D)
        : const Color(0xFFB45309);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        status,
        style: Theme.of(context).textTheme.bodySmall?.copyWith(
          color: foreground,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _SellerPaymentSummaryCard extends StatelessWidget {
  const _SellerPaymentSummaryCard({
    required this.label,
    required this.value,
    required this.accent,
    required this.background,
  });

  final String label;
  final String value;
  final Color accent;
  final Color background;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label, style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 6),
          Text(
            value,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: accent,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}
class SellerChatListPage extends StatelessWidget {
  const SellerChatListPage({
    super.key,
    required this.onLogout,
    required this.statusMessage,
    required this.isCloudReady,
  });

  final VoidCallback onLogout;
  final String statusMessage;
  final bool isCloudReady;

  @override
  Widget build(BuildContext context) {
    final SellerMenuController controller = SellerMenuController.instance;
    return AnimatedBuilder(
      animation: controller,
      builder: (BuildContext context, _) {
        final List<Vendor> ownedVendors = controller.ownedVendors(sampleVendors);
        final Vendor activeVendor = ownedVendors.firstWhere(
          (Vendor vendor) => vendor.id == controller.activeVendorId,
          orElse: () => ownedVendors.first,
        );
        return ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    'Chat Penyewa',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                ),
                TextButton.icon(
                  onPressed: onLogout,
                  icon: const Icon(Icons.logout_rounded),
                  label: const Text('Keluar'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              '${activeVendor.brandName} • ${activeVendor.name}',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            if (ownedVendors.length > 1) ...<Widget>[
              const SizedBox(height: 12),
              SellerPropertySwitcherCard(
                activeVendor: activeVendor,
                ownedVendors: ownedVendors,
                subtitle:
                    'Pilih properti aktif untuk membuka chat calon penyewa dari lokasi yang berbeda.',
                onChanged: (String? value) async {
                  if (value == null) {
                    return;
                  }
                  await controller.setActiveVendor(value);
                },
              ),
            ],
            if (kShowInternalStatusBanners) ...<Widget>[
              const SizedBox(height: 12),
              DemoModeBanner(
                title: isCloudReady ? 'Chat Online Siap' : 'Chat Demo Aktif',
                message: statusMessage,
              ),
            ],
            const SizedBox(height: 12),
            ChatListTile(vendor: activeVendor, sellerMode: true),
          ],
        );
      },
    );
  }
}

class SellerStatsRow extends StatelessWidget {
  const SellerStatsRow({
    super.key,
    required this.onOpenMenu,
    required this.onOpenOrders,
    required this.onOpenChat,
  });

  final VoidCallback onOpenMenu;
  final VoidCallback onOpenOrders;
  final VoidCallback onOpenChat;

  @override
  Widget build(BuildContext context) {
    final SellerMenuController controller = SellerMenuController.instance;
    final Vendor activeVendor = sampleVendors.firstWhere(
      (Vendor vendor) => vendor.id == controller.activeVendorId,
      orElse: () => sampleVendors.first,
    );
    final int baseMenuCount = activeVendor.packages.length +
        activeVendor.foods.length +
        activeVendor.drinks.length +
        activeVendor.others.length;
    final int customMenuCount = controller.entriesForVendor(controller.activeVendorId).length;
    return Row(
      children: <Widget>[
        Expanded(
          child: StreamBuilder<List<OrderRecord>>(
            stream: OrderRepository.watchSellerOrders(controller.activeVendorId),
            initialData: const <OrderRecord>[],
            builder: (BuildContext context, AsyncSnapshot<List<OrderRecord>> snapshot) {
              final int activeCount = (snapshot.data ?? <OrderRecord>[])
                  .where((OrderRecord order) => order.status != 'Selesai')
                  .length;
              return SellerStatCard(
                label: 'Order aktif',
                value: '$activeCount',
                onTap: onOpenOrders,
              );
            },
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: SellerStatCard(
            label: 'Menu aktif',
            value: '${baseMenuCount + customMenuCount}',
            onTap: onOpenMenu,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: StreamBuilder<List<ChatMessage>>(
            stream: ChatRepository.watchMessages(
              vendorId: controller.activeVendorId,
              currentSenderId: 'seller-${controller.activeVendorId}',
            ),
            initialData: const <ChatMessage>[],
            builder: (BuildContext context, AsyncSnapshot<List<ChatMessage>> snapshot) {
              final int unreadCount = ChatRepository.localHasUnreadMessage(
                vendorId: controller.activeVendorId,
                currentSenderId: 'seller-${controller.activeVendorId}',
              )
                  ? 1
                  : 0;
              return SellerStatCard(
                label: 'Chat baru',
                value: '$unreadCount',
                onTap: onOpenChat,
              );
            },
          ),
        ),
      ],
    );
  }
}

class SellerStatCard extends StatelessWidget {
  const SellerStatCard({
    super.key,
    required this.label,
    required this.value,
    this.onTap,
  });

  final String label;
  final String value;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: Ink(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kBorder),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Text(
              value,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                color: Color(0xFF1D4ED8),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }
}

class _SellerInfoChip extends StatelessWidget {
  const _SellerInfoChip({
    required this.label,
    required this.icon,
  });

  final String label;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0x14FFFFFF),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0x26FFFFFF)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, size: 16, color: Colors.white),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _SellerNotificationsSheet extends StatelessWidget {
  const _SellerNotificationsSheet({
    required this.vendor,
    required this.onOpenOrders,
    required this.onOpenChat,
  });

  final Vendor vendor;
  final VoidCallback onOpenOrders;
  final VoidCallback onOpenChat;

  @override
  Widget build(BuildContext context) {
    final List<AppNotificationItem> items = _buildSellerNotifications(vendor);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Notifikasi Penjual',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              'Pantau booking baru, pertanyaan calon penyewa, dan chat tanpa pindah-pindah menu.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),
            if (items.isEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: kBorder),
                ),
                child: Text(
                  'Belum ada notifikasi baru untuk properti ini.',
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              )
            else
              ...items.map(
                (AppNotificationItem item) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(22),
                    onTap: () {
                      Navigator.of(context).pop();
                      if (item.route == AppNotificationRoute.chat) {
                        onOpenChat();
                        return;
                      }
                      onOpenOrders();
                    },
                    child: Ink(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: kBorder),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: item.accent.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Icon(item.icon, color: item.accent),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  item.title,
                                  style: Theme.of(context).textTheme.titleMedium,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  item.message,
                                  style: Theme.of(context).textTheme.bodyMedium,
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  item.timeLabel,
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Icon(Icons.chevron_right_rounded, color: kMuted),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

List<AppNotificationItem> _buildSellerNotifications(Vendor vendor) {
  final List<AppNotificationItem> items = <AppNotificationItem>[];

  for (final OrderRecord order in OrderRepository.localSellerOrders(vendor.id)) {
    if (order.status == 'Diproses') {
      items.add(
        AppNotificationItem(
          title: 'Booking baru masuk',
          message: '${order.buyerName} mengajukan ${order.compactMenuLabel}.',
          timeLabel: order.scheduleLabel,
          icon: Icons.inventory_2_rounded,
          accent: const Color(0xFFB45309),
          category: AppNotificationCategory.orders,
          route: AppNotificationRoute.orders,
        ),
      );
    } else if (order.status == 'Dikirim') {
      items.add(
        AppNotificationItem(
          title: 'Penyewa siap check-in',
          message:
              '${order.compactMenuLabel} untuk ${order.buyerName} sudah masuk tahap check-in.',
          timeLabel: order.scheduleLabel,
          icon: Icons.local_shipping_rounded,
          accent: const Color(0xFF2563EB),
          category: AppNotificationCategory.orders,
          route: AppNotificationRoute.orders,
        ),
      );
    }
  }

  for (final CustomMenuRequest request
      in CustomMenuRequestRepository.localSellerRequests(vendor.id)) {
    if (request.status == 'Masuk' || request.status == 'Disetujui') {
      items.add(
        AppNotificationItem(
          title: request.status == 'Masuk'
              ? 'Request custom baru'
              : 'Penawaran sudah disetujui',
          message: request.status == 'Masuk'
              ? '${request.buyerName} meminta ${request.title}.'
              : '${request.buyerName} menyetujui ${request.title}.',
          timeLabel: request.createdAtLabel,
          icon: Icons.fact_check_rounded,
          accent: kPrimary,
          category: AppNotificationCategory.request,
          route: AppNotificationRoute.orders,
        ),
      );
    }
  }

  if (ChatRepository.localHasUnreadMessage(
    vendorId: vendor.id,
    currentSenderId: 'seller-${vendor.id}',
  )) {
    final ChatMessage? latest = ChatRepository.localLatestMessage(
      vendorId: vendor.id,
      currentSenderId: 'seller-${vendor.id}',
    );
    if (latest != null) {
      items.add(
        AppNotificationItem(
          title: 'Chat baru dari pembeli',
          message: chatPreviewText(latest.text),
          timeLabel: latest.time.isEmpty ? 'Baru saja' : latest.time,
          icon: Icons.chat_bubble_rounded,
          accent: const Color(0xFF1D4ED8),
          category: AppNotificationCategory.chat,
          route: AppNotificationRoute.chat,
        ),
      );
    }
  }

  return items.take(6).toList();
}

class SellerTaskCard extends StatelessWidget {
  const SellerTaskCard({
    super.key,
    required this.text,
    this.onEdit,
    this.onDelete,
  });

  final String text;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kBorder),
      ),
      child: Row(
        children: <Widget>[
          Container(
            width: 12,
            height: 12,
            decoration: const BoxDecoration(
              color: Color(0xFF1D4ED8),
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(text, style: Theme.of(context).textTheme.bodyLarge),
          ),
          if (onEdit != null)
            IconButton(
              onPressed: onEdit,
              icon: const Icon(Icons.edit_outlined, size: 18),
            ),
          if (onDelete != null)
            IconButton(
              onPressed: onDelete,
              icon: const Icon(Icons.remove_circle_outline_rounded, size: 18),
            ),
        ],
      ),
    );
  }
}

class _SellerNoteDialog extends StatefulWidget {
  const _SellerNoteDialog({
    required this.initialText,
    required this.isEditing,
  });

  final String initialText;
  final bool isEditing;

  @override
  State<_SellerNoteDialog> createState() => _SellerNoteDialogState();
}

class _SellerNoteDialogState extends State<_SellerNoteDialog> {
  late final TextEditingController _controller = TextEditingController(
    text: widget.initialText,
  );

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.isEditing ? 'Edit catatan' : 'Tambah catatan'),
      content: TextField(
        controller: _controller,
        maxLines: 4,
        decoration: const InputDecoration(
          hintText: 'Tulis catatan penting untuk operasional toko',
        ),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Batal'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(_controller.text.trim()),
          child: const Text('Simpan'),
        ),
      ],
    );
  }
}

class SellerCustomRequestCard extends StatelessWidget {
  const SellerCustomRequestCard({super.key, required this.request});

  final CustomMenuRequest request;

  Future<void> _openResponseDialog(BuildContext context) async {
    final _SellerCustomRequestDialogResult? result =
        await showDialog<_SellerCustomRequestDialogResult>(
      context: context,
      builder: (BuildContext context) => _SellerCustomRequestDialog(
        initialTitle: request.title,
        initialDescription: request.description,
        initialTargetPax: request.targetPax,
        initialPrice: request.quotedPriceLabel,
        initialResponse: request.sellerResponse,
      ),
    );
    if (result == null) {
      return;
    }
    await CustomMenuRequestRepository.respondToRequest(
      requestId: request.id,
      status: 'Dijawab',
      title: result.title,
      description: result.description,
      targetPax: result.targetPax,
      sellerResponse: result.response,
      quotedPriceLabel: result.price,
    );
    await ChatRepository.sendMessage(
      vendorId: request.vendorId,
      text: buildOfferChatPayload(
        requestId: request.id,
        title: result.title.trim(),
        targetPax: result.targetPax,
        quotedPriceLabel: result.price.trim(),
        sellerResponse: result.response.trim(),
      ),
      senderId: 'seller-${request.vendorId}',
      senderLabel: 'Penjual',
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool hasOffer =
        request.sellerResponse.isNotEmpty || request.quotedPriceLabel.isNotEmpty;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  request.title,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: kPrimarySoft,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  request.status,
                  style: const TextStyle(
                    color: kPrimaryDark,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Dari ${request.buyerName} • ${request.targetPax} pax • ${request.budgetLabel}',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 10),
          Text(
            request.description,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          if (hasOffer) ...<Widget>[
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFFFFCF4),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: const Color(0xFFF8D99A)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'Penawaran aktif',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                      color: const Color(0xFF92400E),
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  if (request.quotedPriceLabel.isNotEmpty) ...<Widget>[
                    const SizedBox(height: 8),
                    Text(
                      request.quotedPriceLabel,
                      style: Theme.of(
                        context,
                      ).textTheme.titleMedium?.copyWith(
                            color: const Color(0xFFB45309),
                          ),
                    ),
                  ],
                  if (request.sellerResponse.isNotEmpty) ...<Widget>[
                    const SizedBox(height: 8),
                    Text(
                      request.sellerResponse,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: const Color(0xFF475569),
                            height: 1.4,
                          ),
                    ),
                  ],
                ],
              ),
            ),
          ],
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <String>['Masuk', 'Diproses', 'Dijawab', 'Disetujui']
                .map(
                  (String status) => ChoiceChip(
                    label: Text(status),
                    selected: request.status == status,
                    onSelected: (_) {
                      CustomMenuRequestRepository.updateStatus(
                        requestId: request.id,
                        status: status,
                      );
                    },
                    selectedColor: const Color(0xFF1D4ED8),
                    backgroundColor: const Color(0xFFF8FAFC),
                    labelStyle: TextStyle(
                      color: request.status == status ? Colors.white : kText,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => _openResponseDialog(context),
            icon: Icon(
              hasOffer ? Icons.edit_rounded : Icons.local_offer_rounded,
            ),
            label: Text(
              request.sellerResponse.isEmpty ? 'Buat penawaran' : 'Edit penawaran',
            ),
          ),
        ],
      ),
    );
  }
}

class _SellerCustomRequestDialogResult {
  const _SellerCustomRequestDialogResult({
    required this.title,
    required this.description,
    required this.targetPax,
    required this.price,
    required this.response,
  });

  final String title;
  final String description;
  final int targetPax;
  final String price;
  final String response;
}

class _SellerCustomRequestDialog extends StatefulWidget {
  const _SellerCustomRequestDialog({
    required this.initialTitle,
    required this.initialDescription,
    required this.initialTargetPax,
    required this.initialPrice,
    required this.initialResponse,
  });

  final String initialTitle;
  final String initialDescription;
  final int initialTargetPax;
  final String initialPrice;
  final String initialResponse;

  @override
  State<_SellerCustomRequestDialog> createState() =>
      _SellerCustomRequestDialogState();
}

class _SellerCustomRequestDialogState extends State<_SellerCustomRequestDialog> {
  late final TextEditingController _titleController = TextEditingController(
    text: widget.initialTitle,
  );
  late final TextEditingController _descriptionController = TextEditingController(
    text: widget.initialDescription,
  );
  late final TextEditingController _priceController = TextEditingController(
    text: widget.initialPrice,
  );
  late final TextEditingController _responseController = TextEditingController(
    text: widget.initialResponse,
  );
  late int _targetPax = widget.initialTargetPax;

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    _responseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Susun penawaran pembeli'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          TextField(
            controller: _titleController,
            decoration: const InputDecoration(
              labelText: 'Nama paket',
              hintText: 'Contoh: Paket ayam bakar + sate kulit',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _descriptionController,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Isi menu final',
              hintText: 'Contoh: nasi, ayam bakar, sate kulit, sambal, air mineral',
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: <Widget>[
              const Text('Jumlah pax'),
              const Spacer(),
              IconButton(
                onPressed: _targetPax > 1
                    ? () {
                        setState(() {
                          _targetPax -= 1;
                        });
                      }
                    : null,
                icon: const Icon(Icons.remove_circle_outline_rounded),
              ),
              Text(
                '$_targetPax',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              IconButton(
                onPressed: () {
                  setState(() {
                    _targetPax += 1;
                  });
                },
                icon: const Icon(Icons.add_circle_outline_rounded),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _priceController,
            decoration: const InputDecoration(
              labelText: 'Penawaran harga',
              hintText: 'Contoh: 25rb per pax atau Rp25.000',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _responseController,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Catatan balasan',
              hintText: 'Contoh: bisa disiapkan untuk besok, minimal 30 pax',
            ),
          ),
        ],
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Batal'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(
            _SellerCustomRequestDialogResult(
              title: _titleController.text.trim(),
              description: _descriptionController.text.trim(),
              targetPax: _targetPax,
              price: _priceController.text.trim(),
              response: _responseController.text.trim(),
            ),
          ),
          child: const Text('Simpan'),
        ),
      ],
    );
  }
}
