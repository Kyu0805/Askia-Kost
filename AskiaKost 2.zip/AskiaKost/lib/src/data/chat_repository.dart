import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

import '../models/app_models.dart';
import 'sample_data.dart';

class ChatRepository {
  const ChatRepository._();

  static final Map<String, List<ChatMessage>> _localMessages =
      <String, List<ChatMessage>>{};
  static final Map<String, StreamController<List<ChatMessage>>> _controllers =
      <String, StreamController<List<ChatMessage>>>{};
  static final ValueNotifier<int> updates = ValueNotifier<int>(0);

  static bool get isReady => Firebase.apps.isNotEmpty;

  static Stream<List<ChatMessage>> watchMessages({
    required String vendorId,
    required String currentSenderId,
  }) {
    if (isReady) {
      try {
        return FirebaseFirestore.instance
            .collection('vendorChats')
            .doc(vendorId)
            .collection('messages')
            .orderBy('createdAt')
            .snapshots()
            .map(
              (QuerySnapshot<Map<String, dynamic>> snapshot) => snapshot.docs
                  .map(
                    (QueryDocumentSnapshot<Map<String, dynamic>> doc) =>
                        ChatMessage.fromJson(
                          doc.data(),
                          currentSenderId: currentSenderId,
                        ),
                  )
                  .toList(),
            );
      } catch (_) {}
    }

    _ensureLocalSeed(vendorId);
    return (() async* {
      yield _mapIsMine(
        List<ChatMessage>.from(_localMessages[vendorId] ?? <ChatMessage>[]),
        currentSenderId,
      );
      final StreamController<List<ChatMessage>> controller =
          _controllers.putIfAbsent(
        vendorId,
        () => StreamController<List<ChatMessage>>.broadcast(),
      );
      await for (final List<ChatMessage> messages in controller.stream) {
        yield _mapIsMine(messages, currentSenderId);
      }
    })();
  }

  static Future<void> markConversationRead({
    required String vendorId,
    required String currentSenderId,
  }) async {
    if (isReady) {
      try {
        final QuerySnapshot<Map<String, dynamic>> snapshot =
            await FirebaseFirestore.instance
                .collection('vendorChats')
                .doc(vendorId)
                .collection('messages')
                .where('deliveryStatus', isNotEqualTo: 'read')
                .get();
        for (final QueryDocumentSnapshot<Map<String, dynamic>> doc in snapshot.docs) {
          final String senderId = doc.data()['senderId'] as String? ?? '';
          if (senderId == currentSenderId) {
            continue;
          }
          await doc.reference.set(<String, Object?>{
            'deliveryStatus': 'read',
          }, SetOptions(merge: true));
        }
      } catch (_) {}
      return;
    }

    _ensureLocalSeed(vendorId);
    bool changed = false;
    final List<ChatMessage> updated = _localMessages[vendorId]!
        .map((ChatMessage message) {
          if (message.senderId == currentSenderId ||
              message.deliveryStatus == 'read') {
            return message;
          }
          changed = true;
          return ChatMessage(
            text: message.text,
            isMine: message.isMine,
            time: message.time,
            senderId: message.senderId,
            senderLabel: message.senderLabel,
            deliveryStatus: 'read',
          );
        })
        .toList();
    if (changed) {
      _localMessages[vendorId] = updated;
      _broadcastVendor(vendorId);
    }
  }

  static Future<void> sendMessage({
    required String vendorId,
    required String text,
    required String senderId,
    required String senderLabel,
  }) async {
    final String trimmedText = text.trim();
    if (trimmedText.isEmpty) {
      return;
    }

    final DateTime now = DateTime.now();
    final ChatMessage message = ChatMessage(
      text: trimmedText,
      isMine: true,
      time:
          '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}',
      senderId: senderId,
      senderLabel: senderLabel,
      deliveryStatus: 'sent',
    );

    if (isReady) {
      try {
        await FirebaseFirestore.instance
            .collection('vendorChats')
            .doc(vendorId)
            .set(<String, Object?>{
              'vendorId': vendorId,
              'updatedAt': FieldValue.serverTimestamp(),
            }, SetOptions(merge: true));
        await FirebaseFirestore.instance
            .collection('vendorChats')
            .doc(vendorId)
            .collection('messages')
            .add(<String, Object?>{
              ...message.toJson(),
              'createdAt': FieldValue.serverTimestamp(),
            });
        return;
      } catch (_) {}
    }

    _ensureLocalSeed(vendorId);
    _localMessages[vendorId]!.add(message);
    _broadcastVendor(vendorId);
  }

  static int localUnreadCount({
    required String currentSenderId,
    required List<String> vendorIds,
  }) {
    int total = 0;
    for (final String vendorId in vendorIds) {
      _ensureLocalSeed(vendorId);
      final List<ChatMessage> messages = _localMessages[vendorId] ?? <ChatMessage>[];
      final ChatMessage? latest = messages.isEmpty ? null : messages.last;
      if (latest != null &&
          latest.senderId != currentSenderId &&
          latest.deliveryStatus != 'read') {
        total += 1;
      }
    }
    return total;
  }

  static ChatMessage? localLatestMessage({
    required String vendorId,
    required String currentSenderId,
  }) {
    _ensureLocalSeed(vendorId);
    final List<ChatMessage> mapped = _mapIsMine(
      _localMessages[vendorId] ?? <ChatMessage>[],
      currentSenderId,
    );
    if (mapped.isEmpty) {
      return null;
    }
    return mapped.last;
  }

  static String localConversationLabel({
    required String vendorId,
    required String currentSenderId,
    String fallback = 'Pembeli',
  }) {
    _ensureLocalSeed(vendorId);
    final List<ChatMessage> messages = _localMessages[vendorId] ?? <ChatMessage>[];
    for (final ChatMessage message in messages.reversed) {
      if (message.senderId != currentSenderId &&
          message.senderLabel.trim().isNotEmpty) {
        return message.senderLabel.trim();
      }
    }
    return fallback;
  }

  static bool localHasUnreadMessage({
    required String vendorId,
    required String currentSenderId,
  }) {
    final ChatMessage? latest = localLatestMessage(
      vendorId: vendorId,
      currentSenderId: currentSenderId,
    );
    return latest != null &&
        !latest.isMine &&
        latest.text.isNotEmpty &&
        latest.deliveryStatus != 'read';
  }

  static Future<void> seedSampleConversation(String vendorId) async {
    if (!isReady) {
      return;
    }

    try {
      final CollectionReference<Map<String, dynamic>> messagesRef =
          FirebaseFirestore.instance
              .collection('vendorChats')
              .doc(vendorId)
              .collection('messages');
      final QuerySnapshot<Map<String, dynamic>> existing = await messagesRef.limit(1).get();
      if (existing.docs.isNotEmpty) {
        return;
      }

      await FirebaseFirestore.instance
          .collection('vendorChats')
          .doc(vendorId)
          .set(<String, Object?>{
            'vendorId': vendorId,
            'updatedAt': FieldValue.serverTimestamp(),
          }, SetOptions(merge: true));

      for (final ChatMessage message in _buildInitialMessages(vendorId)) {
        await messagesRef.add(<String, Object?>{
          ...message.toJson(),
          'createdAt': FieldValue.serverTimestamp(),
        });
      }
    } catch (_) {}
  }

  static void _ensureLocalSeed(String vendorId) {
    _localMessages.putIfAbsent(vendorId, () => _buildInitialMessages(vendorId));
  }

  static List<ChatMessage> _buildInitialMessages(String vendorId) {
    final String sellerId = 'seller-$vendorId';
    return <ChatMessage>[
      ChatMessage(
        text: sampleBuyerChat[0].text,
        isMine: false,
        time: sampleBuyerChat[0].time,
        senderId: 'buyer-demo',
        senderLabel: 'Pembeli',
        deliveryStatus: 'read',
      ),
      ChatMessage(
        text: sampleBuyerChat[1].text,
        isMine: false,
        time: sampleBuyerChat[1].time,
        senderId: sellerId,
        senderLabel: 'Penjual',
        deliveryStatus: 'read',
      ),
      ChatMessage(
        text: sampleBuyerChat[2].text,
        isMine: false,
        time: sampleBuyerChat[2].time,
        senderId: 'buyer-demo',
        senderLabel: 'Pembeli',
        deliveryStatus: 'read',
      ),
    ];
  }

  static List<ChatMessage> _mapIsMine(
    List<ChatMessage> messages,
    String currentSenderId,
  ) {
    return messages
        .map(
          (ChatMessage message) => ChatMessage(
            text: message.text,
            time: message.time,
            senderId: message.senderId,
            senderLabel: message.senderLabel,
            deliveryStatus: message.deliveryStatus,
            isMine: message.senderId == currentSenderId,
          ),
        )
        .toList();
  }

  static void _broadcastVendor(String vendorId) {
    updates.value++;
    final StreamController<List<ChatMessage>> controller = _controllers.putIfAbsent(
      vendorId,
      () => StreamController<List<ChatMessage>>.broadcast(),
    );
    controller.add(List<ChatMessage>.from(_localMessages[vendorId] ?? <ChatMessage>[]));
  }
}
