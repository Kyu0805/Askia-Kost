import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

import '../models/app_models.dart';

class CustomMenuRequestRepository {
  const CustomMenuRequestRepository._();

  static final List<CustomMenuRequest> _localRequests = <CustomMenuRequest>[];
  static final StreamController<List<CustomMenuRequest>> _localController =
      StreamController<List<CustomMenuRequest>>.broadcast();
  static final ValueNotifier<int> updates = ValueNotifier<int>(0);

  static bool get isReady => Firebase.apps.isNotEmpty;

  static Stream<List<CustomMenuRequest>> watchBuyerRequests(String buyerId) {
    if (isReady) {
      try {
        return FirebaseFirestore.instance
            .collection('customMenuRequests')
            .where('buyerId', isEqualTo: buyerId)
            .snapshots()
            .map(_mapSnapshot);
      } catch (_) {}
    }
    return _watchLocal(
      (CustomMenuRequest request) => request.buyerId == buyerId,
    );
  }

  static Stream<List<CustomMenuRequest>> watchSellerRequests(String vendorId) {
    if (isReady) {
      try {
        return FirebaseFirestore.instance
            .collection('customMenuRequests')
            .where('vendorId', isEqualTo: vendorId)
            .snapshots()
            .map(_mapSnapshot);
      } catch (_) {}
    }
    return _watchLocal(
      (CustomMenuRequest request) => request.vendorId == vendorId,
    );
  }

  static Future<CustomMenuRequest> placeRequest({
    required Vendor vendor,
    required String buyerId,
    required String buyerName,
    required String title,
    required String description,
    required int targetPax,
    required String budgetLabel,
  }) async {
    final DateTime now = DateTime.now();
    final String id = 'request-${now.microsecondsSinceEpoch}';
    final CustomMenuRequest request = CustomMenuRequest(
      id: id,
      vendorId: vendor.id,
      vendorName: vendor.name,
      buyerId: buyerId,
      buyerName: buyerName,
      title: title,
      description: description,
      targetPax: targetPax,
      budgetLabel: budgetLabel,
      status: 'Masuk',
      createdAtLabel:
          '${now.day.toString().padLeft(2, '0')} ${_monthName(now.month)} ${now.year} • ${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}',
    );

    if (isReady) {
      try {
        await FirebaseFirestore.instance
            .collection('customMenuRequests')
            .doc(id)
            .set(<String, Object?>{
              ...request.toJson(),
              'createdAt': FieldValue.serverTimestamp(),
            });
        return request;
      } catch (_) {}
    }

    _localRequests.insert(0, request);
    _emit();
    return request;
  }

  static Future<void> updateStatus({
    required String requestId,
    required String status,
  }) async {
    if (isReady) {
      try {
        await FirebaseFirestore.instance
            .collection('customMenuRequests')
            .doc(requestId)
            .set(<String, Object?>{
              'status': status,
              'updatedAt': FieldValue.serverTimestamp(),
            }, SetOptions(merge: true));
        return;
      } catch (_) {}
    }

    final int index = _localRequests.indexWhere(
      (CustomMenuRequest item) => item.id == requestId,
    );
    if (index == -1) {
      return;
    }
    final CustomMenuRequest current = _localRequests[index];
    _localRequests[index] = CustomMenuRequest(
      id: current.id,
      vendorId: current.vendorId,
      vendorName: current.vendorName,
      buyerId: current.buyerId,
      buyerName: current.buyerName,
      title: current.title,
      description: current.description,
      targetPax: current.targetPax,
      budgetLabel: current.budgetLabel,
      status: status,
      createdAtLabel: current.createdAtLabel,
      sellerResponse: current.sellerResponse,
      quotedPriceLabel: current.quotedPriceLabel,
    );
    _emit();
  }

  static Future<void> respondToRequest({
    required String requestId,
    required String status,
    required String sellerResponse,
    required String quotedPriceLabel,
    String? title,
    String? description,
    int? targetPax,
    String? budgetLabel,
  }) async {
    if (isReady) {
      try {
        await FirebaseFirestore.instance
            .collection('customMenuRequests')
            .doc(requestId)
            .set(<String, Object?>{
              'status': status,
              'sellerResponse': sellerResponse,
              'quotedPriceLabel': quotedPriceLabel,
              if (title != null) 'title': title,
              if (description != null) 'description': description,
              if (targetPax != null) 'targetPax': targetPax,
              if (budgetLabel != null) 'budgetLabel': budgetLabel,
              'updatedAt': FieldValue.serverTimestamp(),
            }, SetOptions(merge: true));
        return;
      } catch (_) {}
    }

    final int index = _localRequests.indexWhere(
      (CustomMenuRequest item) => item.id == requestId,
    );
    if (index == -1) {
      return;
    }
    final CustomMenuRequest current = _localRequests[index];
    _localRequests[index] = CustomMenuRequest(
      id: current.id,
      vendorId: current.vendorId,
      vendorName: current.vendorName,
      buyerId: current.buyerId,
      buyerName: current.buyerName,
      title: title ?? current.title,
      description: description ?? current.description,
      targetPax: targetPax ?? current.targetPax,
      budgetLabel: budgetLabel ?? current.budgetLabel,
      status: status,
      createdAtLabel: current.createdAtLabel,
      sellerResponse: sellerResponse,
      quotedPriceLabel: quotedPriceLabel,
    );
    _emit();
  }

  static Future<void> cancelRequest({
    required String requestId,
  }) async {
    await updateStatus(requestId: requestId, status: 'Dibatalkan');
  }

  static int localBuyerRequestCount(String buyerId) {
    return _localRequests.where((CustomMenuRequest item) => item.buyerId == buyerId).length;
  }

  static List<CustomMenuRequest> localBuyerRequests(String buyerId) {
    return _localRequests
        .where((CustomMenuRequest item) => item.buyerId == buyerId)
        .toList();
  }

  static List<CustomMenuRequest> localSellerRequests(String vendorId) {
    return _localRequests
        .where((CustomMenuRequest item) => item.vendorId == vendorId)
        .toList();
  }

  static CustomMenuRequest? localRequestById(String requestId) {
    try {
      return _localRequests.firstWhere(
        (CustomMenuRequest item) => item.id == requestId,
      );
    } catch (_) {
      return null;
    }
  }

  static List<CustomMenuRequest> _mapSnapshot(
    QuerySnapshot<Map<String, dynamic>> snapshot,
  ) {
    final List<CustomMenuRequest> items = snapshot.docs
        .map(
          (QueryDocumentSnapshot<Map<String, dynamic>> doc) =>
              CustomMenuRequest.fromJson(doc.id, doc.data()),
        )
        .toList();
    items.sort((CustomMenuRequest a, CustomMenuRequest b) => b.id.compareTo(a.id));
    return items;
  }

  static Stream<List<CustomMenuRequest>> _watchLocal(
    bool Function(CustomMenuRequest item) predicate,
  ) async* {
    yield _localRequests.where(predicate).toList();
    yield* _localController.stream.map(
      (_) => _localRequests.where(predicate).toList(),
    );
  }

  static void _emit() {
    _localController.add(List<CustomMenuRequest>.unmodifiable(_localRequests));
    updates.value++;
  }

  static String _monthName(int month) {
    const List<String> months = <String>[
      'Januari',
      'Februari',
      'Maret',
      'April',
      'Mei',
      'Juni',
      'Juli',
      'Agustus',
      'September',
      'Oktober',
      'November',
      'Desember',
    ];
    return months[month - 1];
  }
}
