import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class FavoriteRepository {
  const FavoriteRepository._();

  static const String _storageKey = 'favorite_vendor_ids_v1';

  static Future<Set<String>> loadFavorites() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String? raw = prefs.getString(_storageKey);
    if (raw == null || raw.isEmpty) {
      return <String>{};
    }
    final List<dynamic> decoded = jsonDecode(raw) as List<dynamic>;
    return decoded.map((dynamic value) => value.toString()).toSet();
  }

  static Future<Set<String>> toggleFavorite(String vendorId) async {
    final Set<String> current = await loadFavorites();
    if (current.contains(vendorId)) {
      current.remove(vendorId);
    } else {
      current.add(vendorId);
    }
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, jsonEncode(current.toList()));
    return current;
  }
}
