import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

class KosRecommendation {
  const KosRecommendation({
    required this.rank,
    required this.kosId,
    required this.name,
    required this.location,
    required this.city,
    required this.monthlyPrice,
    required this.currency,
    required this.roomType,
    required this.facilities,
    required this.cosineSimilarity,
    required this.reasons,
    this.isDemo = false,
  });

  final int rank;
  final String kosId;
  final String name;
  final String location;
  final String city;
  final int monthlyPrice;
  final String currency;
  final String roomType;
  final List<String> facilities;
  final double cosineSimilarity;
  final List<String> reasons;
  final bool isDemo;

  factory KosRecommendation.fromJson(
    Map<String, dynamic> json, {
    bool isDemo = false,
  }) {
    return KosRecommendation(
      rank: (json['rank'] as num?)?.toInt() ?? 0,
      kosId: json['kosId'] as String? ?? '',
      name: json['namaKos'] as String? ?? 'Kos',
      location: json['lokasi'] as String? ?? '',
      city: json['kota'] as String? ?? '',
      monthlyPrice: (json['hargaSewa'] as num?)?.toInt() ?? 0,
      currency: json['mataUang'] as String? ?? 'IDR',
      roomType: json['tipeKos'] as String? ?? '',
      facilities: _stringList(json['fasilitas']),
      cosineSimilarity: (json['cosineSimilarity'] as num?)?.toDouble() ?? 0,
      reasons: _stringList(json['reasons']),
      isDemo: isDemo,
    );
  }

  static List<String> _stringList(dynamic value) {
    return (value as List<dynamic>? ?? <dynamic>[])
        .map((dynamic item) => item.toString())
        .toList();
  }
}

class KosRecommendationRepository {
  const KosRecommendationRepository._();

  static const String demoProfileId = 'demo-mahasiswa-austin';
  static const List<KosRecommendation> demoRecommendations =
      <KosRecommendation>[
        KosRecommendation(
          rank: 1,
          kosId: '5668630273',
          name: 'Kos 4930 S Congress Ave',
          location: 'Austin, TX',
          city: 'Austin',
          monthlyPrice: 1285,
          currency: 'USD',
          roomType: 'Kamar Standard',
          facilities: <String>['ac', 'wifi', 'parkir', 'laundry', 'kulkas'],
          cosineSimilarity: 0.314126,
          reasons: <String>[
            'Lokasi, budget, tipe kamar, dan empat fasilitas sesuai',
          ],
          isDemo: true,
        ),
        KosRecommendation(
          rank: 2,
          kosId: '5668630298',
          name: 'Kos 2313 Thornton Rd',
          location: 'Austin, TX',
          city: 'Austin',
          monthlyPrice: 1421,
          currency: 'USD',
          roomType: 'Kamar Standard',
          facilities: <String>['ac', 'wifi', 'parkir', 'laundry'],
          cosineSimilarity: 0.311507,
          reasons: <String>[
            'Lokasi, budget, tipe kamar, dan empat fasilitas sesuai',
          ],
          isDemo: true,
        ),
        KosRecommendation(
          rank: 3,
          kosId: '5668630490',
          name: 'Kos 2700 Barton Creek Blvd',
          location: 'Austin, TX',
          city: 'Austin',
          monthlyPrice: 1299,
          currency: 'USD',
          roomType: 'Kamar Standard',
          facilities: <String>['ac', 'wifi', 'parkir'],
          cosineSimilarity: 0.309727,
          reasons: <String>[
            'Lokasi, budget, tipe kamar, dan tiga fasilitas sesuai',
          ],
          isDemo: true,
        ),
        KosRecommendation(
          rank: 4,
          kosId: '5668630291',
          name: 'Kos 2613 Rogers Ave',
          location: 'Austin, TX',
          city: 'Austin',
          monthlyPrice: 1409,
          currency: 'USD',
          roomType: 'Kamar Standard',
          facilities: <String>['ac', 'wifi', 'parkir', 'laundry'],
          cosineSimilarity: 0.309591,
          reasons: <String>[
            'Lokasi, budget, tipe kamar, dan empat fasilitas sesuai',
          ],
          isDemo: true,
        ),
        KosRecommendation(
          rank: 5,
          kosId: '5668630287',
          name: 'Kos 3601 S Congress Ave',
          location: 'Austin, TX',
          city: 'Austin',
          monthlyPrice: 1451,
          currency: 'USD',
          roomType: 'Kamar Standard',
          facilities: <String>['ac', 'wifi', 'parkir'],
          cosineSimilarity: 0.309,
          reasons: <String>[
            'Lokasi, budget, tipe kamar, dan tiga fasilitas sesuai',
          ],
          isDemo: true,
        ),
      ];

  static bool get isReady => Firebase.apps.isNotEmpty;

  static Future<List<KosRecommendation>> fetchForCurrentUser() async {
    if (!isReady) {
      return demoRecommendations;
    }

    final String? userId = FirebaseAuth.instance.currentUser?.uid;
    final List<String> documentIds = <String>[
      if (userId != null) userId,
      demoProfileId,
    ];

    for (final String documentId in documentIds) {
      try {
        final DocumentSnapshot<Map<String, dynamic>> snapshot =
            await FirebaseFirestore.instance
                .collection('recommendations')
                .doc(documentId)
                .get()
                .timeout(const Duration(seconds: 8));
        final Map<String, dynamic>? data = snapshot.data();
        final List<dynamic> items =
            data?['items'] as List<dynamic>? ?? <dynamic>[];
        if (items.isEmpty) {
          continue;
        }

        final List<KosRecommendation> recommendations =
            items
                .whereType<Map<dynamic, dynamic>>()
                .map(
                  (Map<dynamic, dynamic> item) => KosRecommendation.fromJson(
                    Map<String, dynamic>.from(item),
                    isDemo: data?['isDummy'] == true,
                  ),
                )
                .toList()
              ..sort(
                (KosRecommendation a, KosRecommendation b) =>
                    a.rank.compareTo(b.rank),
              );
        return recommendations;
      } catch (_) {
        // Try the demo document if a user-specific document is unavailable.
      }
    }
    return demoRecommendations;
  }
}
