import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

import '../models/app_models.dart';
import 'payment_transaction_repository.dart';

class OrderRepository {
  const OrderRepository._();

  static final List<OrderRecord> _localOrders = <OrderRecord>[
    const OrderRecord(
      id: 'seed-order-1',
      vendorId: 'vendor-1',
      vendorName: 'Askia Dapur Nusantara',
      menuName: 'Paket Premium Meeting',
      quantity: 35,
      totalPrice: 1470000,
      status: 'Diproses',
      scheduleLabel: '25 Maret 2026 • 11:30',
      deliveryAddress: 'Jl. Raya Pengasinan No. 12, Sawangan, Depok',
      buyerId: 'buyer-demo',
      buyerName: 'Halip',
      amountPaid: 735000,
      paymentMethodLabel: 'QRIS',
      paymentStatus: 'DP 50%',
      notes: 'Tolong tambah sambal dan tisu.',
      lineItems: <OrderLineItem>[
        OrderLineItem(
          name: 'Paket Premium Meeting',
          unitPrice: 42000,
          quantity: 35,
        ),
      ],
    ),
    const OrderRecord(
      id: 'seed-order-2',
      vendorId: 'vendor-4',
      vendorName: 'Katering Cinere Sehat',
      menuName: 'Paket Diet Office',
      quantity: 20,
      totalPrice: 720000,
      status: 'Selesai',
      scheduleLabel: '17 Maret 2026 • 12:00',
      deliveryAddress: 'Jl. Cinere Raya No. 8, Cinere, Depok',
      buyerId: 'buyer-demo',
      buyerName: 'Halip',
      amountPaid: 720000,
      paymentMethodLabel: 'QRIS',
      paymentStatus: 'Lunas',
      lineItems: <OrderLineItem>[
        OrderLineItem(
          name: 'Paket Diet Office',
          unitPrice: 36000,
          quantity: 20,
        ),
      ],
    ),
  ];
  static final StreamController<List<OrderRecord>> _localOrderController =
      StreamController<List<OrderRecord>>.broadcast();
  static final ValueNotifier<int> updates = ValueNotifier<int>(0);
  static final Map<String, List<OrderRecord>> _buyerCloudOrders =
      <String, List<OrderRecord>>{};
  static final Map<String, List<OrderRecord>> _sellerCloudOrders =
      <String, List<OrderRecord>>{};
  static final Set<String> _fetchingBuyerIds = <String>{};
  static final Set<String> _fetchingSellerIds = <String>{};
  static bool _fetchingAllOrders = false;
  static List<OrderRecord>? _allCloudOrders;

  static bool get isReady => Firebase.apps.isNotEmpty;

  static Stream<List<OrderRecord>> watchBuyerOrders(String buyerId) {
    if (isReady) {
      try {
        return FirebaseFirestore.instance
            .collection('orders')
            .where('buyerId', isEqualTo: buyerId)
            .snapshots()
            .map((QuerySnapshot<Map<String, dynamic>> snapshot) {
              final List<OrderRecord> orders = _mapSnapshotToOrders(snapshot);
              _buyerCloudOrders[buyerId] = orders;
              _cacheOrders(orders);
              updates.value++;
              return orders;
            });
      } catch (_) {}
    }
    return _watchLocalOrders(
      (OrderRecord order) => order.buyerId == buyerId,
    );
  }

  static Stream<List<OrderRecord>> watchSellerOrders(String vendorId) {
    if (isReady) {
      try {
        return FirebaseFirestore.instance
            .collection('orders')
            .where('vendorId', isEqualTo: vendorId)
            .snapshots()
            .map((QuerySnapshot<Map<String, dynamic>> snapshot) {
              final List<OrderRecord> orders = _mapSnapshotToOrders(snapshot);
              _sellerCloudOrders[vendorId] = orders;
              _cacheOrders(orders);
              updates.value++;
              return orders;
            });
      } catch (_) {}
    }
    return _watchLocalOrders(
      (OrderRecord order) => order.vendorId == vendorId,
    );
  }

  static Future<OrderRecord> placeOrder({
    required Vendor vendor,
    required MenuItemData item,
    required int quantity,
    required String scheduleLabel,
    required String deliveryAddress,
    required String buyerId,
    required String buyerName,
    required int amountPaid,
    required String paymentMethodLabel,
    required String paymentStatus,
    String notes = '',
  }) async {
    final DateTime now = DateTime.now();
    final String orderId = now.microsecondsSinceEpoch.toString();
    final OrderRecord order = OrderRecord(
      id: orderId,
      vendorId: vendor.id,
      vendorName: vendor.name,
      menuName: item.name,
      quantity: quantity,
      totalPrice: item.price * quantity,
      status: 'Diproses',
      scheduleLabel: scheduleLabel,
      deliveryAddress: deliveryAddress,
      buyerId: buyerId,
      buyerName: buyerName,
      amountPaid: amountPaid,
      paymentMethodLabel: paymentMethodLabel,
      paymentStatus: paymentStatus,
      notes: notes,
      lineItems: <OrderLineItem>[
        OrderLineItem(
          name: item.name,
          unitPrice: item.price,
          quantity: quantity,
        ),
      ],
    );

    if (isReady) {
      _localOrders.insert(0, order);
      _rememberCloudOrder(order);
      _emitLocalOrders();
      unawaited(_syncCreatedOrder(order));
      unawaited(
        PaymentTransactionRepository.recordPayment(
          orderId: order.id,
          stageLabel: paymentStatus == 'Lunas' ? 'Pelunasan' : 'DP 50%',
          amount: amountPaid,
          methodLabel: paymentMethodLabel,
          createdAtLabel: scheduleLabel,
          gatewayReference: 'ASKIA-${order.id}',
        ),
      );
      return order;
    }

    _localOrders.insert(0, order);
    _emitLocalOrders();
    await PaymentTransactionRepository.recordPayment(
      orderId: order.id,
      stageLabel: paymentStatus == 'Lunas' ? 'Pelunasan' : 'DP 50%',
      amount: amountPaid,
      methodLabel: paymentMethodLabel,
      createdAtLabel: scheduleLabel,
      gatewayReference: 'ASKIA-${order.id}',
    );
    return order;
  }

  static Future<OrderRecord> placeCustomOrder({
    required String vendorId,
    required String vendorName,
    required String menuName,
    required int unitPrice,
    required int quantity,
    required String scheduleLabel,
    required String deliveryAddress,
    required String buyerId,
    required String buyerName,
    required int amountPaid,
    required String paymentMethodLabel,
    required String paymentStatus,
    String notes = '',
  }) async {
    final DateTime now = DateTime.now();
    final String orderId = now.microsecondsSinceEpoch.toString();
    final OrderRecord order = OrderRecord(
      id: orderId,
      vendorId: vendorId,
      vendorName: vendorName,
      menuName: menuName,
      quantity: quantity,
      totalPrice: unitPrice * quantity,
      status: 'Diproses',
      scheduleLabel: scheduleLabel,
      deliveryAddress: deliveryAddress,
      buyerId: buyerId,
      buyerName: buyerName,
      amountPaid: amountPaid,
      paymentMethodLabel: paymentMethodLabel,
      paymentStatus: paymentStatus,
      notes: notes,
      lineItems: <OrderLineItem>[
        OrderLineItem(
          name: menuName,
          unitPrice: unitPrice,
          quantity: quantity,
        ),
      ],
    );

    if (isReady) {
      _localOrders.insert(0, order);
      _rememberCloudOrder(order);
      _emitLocalOrders();
      unawaited(_syncCreatedOrder(order));
      unawaited(
        PaymentTransactionRepository.recordPayment(
          orderId: order.id,
          stageLabel: paymentStatus == 'Lunas' ? 'Pelunasan' : 'DP 50%',
          amount: amountPaid,
          methodLabel: paymentMethodLabel,
          createdAtLabel: scheduleLabel,
          gatewayReference: 'ASKIA-${order.id}',
        ),
      );
      return order;
    }

    _localOrders.insert(0, order);
    _emitLocalOrders();
    await PaymentTransactionRepository.recordPayment(
      orderId: order.id,
      stageLabel: paymentStatus == 'Lunas' ? 'Pelunasan' : 'DP 50%',
      amount: amountPaid,
      methodLabel: paymentMethodLabel,
      createdAtLabel: scheduleLabel,
      gatewayReference: 'ASKIA-${order.id}',
    );
    return order;
  }

  static Future<OrderRecord> placeCartOrder({
    required Vendor vendor,
    required List<OrderLineItem> items,
    required String scheduleLabel,
    required String deliveryAddress,
    required String buyerId,
    required String buyerName,
    required int amountPaid,
    required String paymentMethodLabel,
    required String paymentStatus,
    String notes = '',
  }) async {
    final DateTime now = DateTime.now();
    final String orderId = now.microsecondsSinceEpoch.toString();
    final int totalPrice = items.fold<int>(
      0,
      (int sum, OrderLineItem item) => sum + item.subtotal,
    );
    final int totalUnits = items.fold<int>(
      0,
      (int sum, OrderLineItem item) => sum + item.quantity,
    );
    final String menuLabel = items.length == 1
        ? items.first.name
        : '${items.first.name} +${items.length - 1} lainnya';
    final OrderRecord order = OrderRecord(
      id: orderId,
      vendorId: vendor.id,
      vendorName: vendor.name,
      menuName: menuLabel,
      quantity: totalUnits,
      totalPrice: totalPrice,
      status: 'Diproses',
      scheduleLabel: scheduleLabel,
      deliveryAddress: deliveryAddress,
      buyerId: buyerId,
      buyerName: buyerName,
      amountPaid: amountPaid,
      paymentMethodLabel: paymentMethodLabel,
      paymentStatus: paymentStatus,
      notes: notes,
      lineItems: items,
    );

    if (isReady) {
      _localOrders.insert(0, order);
      _rememberCloudOrder(order);
      _emitLocalOrders();
      unawaited(_syncCreatedOrder(order));
      unawaited(
        PaymentTransactionRepository.recordPayment(
          orderId: order.id,
          stageLabel: paymentStatus == 'Lunas' ? 'Pelunasan' : 'DP 50%',
          amount: amountPaid,
          methodLabel: paymentMethodLabel,
          createdAtLabel: scheduleLabel,
          gatewayReference: 'ASKIA-${order.id}',
        ),
      );
      return order;
    }

    _localOrders.insert(0, order);
    _emitLocalOrders();
    await PaymentTransactionRepository.recordPayment(
      orderId: order.id,
      stageLabel: paymentStatus == 'Lunas' ? 'Pelunasan' : 'DP 50%',
      amount: amountPaid,
      methodLabel: paymentMethodLabel,
      createdAtLabel: scheduleLabel,
      gatewayReference: 'ASKIA-${order.id}',
    );
    return order;
  }

  static Future<void> updateOrderStatus({
    required String orderId,
    required String status,
    String cancelReason = '',
  }) async {
    if (isReady) {
      final OrderRecord? cached = _findKnownOrder(orderId);
      if (cached != null && cached.status == 'Dibatalkan' && status != 'Dibatalkan') {
        return;
      }
      _patchCachedOrder(
        orderId,
        (OrderRecord current) => current.copyWith(
          status: status,
          cancelReason:
              cancelReason.isEmpty ? current.cancelReason : cancelReason,
        ),
      );
      _patchLocalOrder(
        orderId,
        (OrderRecord current) => current.copyWith(
          status: status,
          cancelReason:
              cancelReason.isEmpty ? current.cancelReason : cancelReason,
        ),
      );
      unawaited(
        _syncOrderFields(orderId, <String, Object?>{
          'status': status,
          'cancelReason': cancelReason,
          'updatedAt': FieldValue.serverTimestamp(),
        }),
      );
      return;
    }

    final int index = _localOrders.indexWhere(
      (OrderRecord order) => order.id == orderId,
    );
    if (index == -1) {
      return;
    }
    final OrderRecord current = _localOrders[index];
    if (current.status == 'Dibatalkan' && status != 'Dibatalkan') {
      return;
    }
    _localOrders[index] = OrderRecord(
      id: current.id,
      vendorId: current.vendorId,
      vendorName: current.vendorName,
      menuName: current.menuName,
      quantity: current.quantity,
      totalPrice: current.totalPrice,
      status: status,
      scheduleLabel: current.scheduleLabel,
      deliveryAddress: current.deliveryAddress,
      buyerId: current.buyerId,
      buyerName: current.buyerName,
      amountPaid: current.amountPaid,
      paymentMethodLabel: current.paymentMethodLabel,
      paymentStatus: current.paymentStatus,
      notes: current.notes,
      cancelReason: cancelReason.isEmpty ? current.cancelReason : cancelReason,
      lineItems: current.lineItems,
    );
    _emitLocalOrders();
  }

  static Future<void> completePayment({
    required String orderId,
  }) async {
    if (isReady) {
      final OrderRecord? current = _findKnownOrder(orderId);
      if (current == null) {
        return;
      }
      final int remainingPayment = current.remainingPayment;
      if (remainingPayment <= 0) {
        return;
      }
      final OrderRecord updated = current.copyWith(
        amountPaid: current.totalPrice,
        paymentMethodLabel: 'QRIS',
        paymentStatus: 'Lunas',
      );
      _patchCachedOrder(orderId, (_) => updated);
      _patchLocalOrder(orderId, (_) => updated);
      unawaited(
        _syncOrderFields(orderId, <String, Object?>{
          'amountPaid': updated.totalPrice,
          'paymentStatus': 'Lunas',
          'paymentMethodLabel': 'QRIS',
          'updatedAt': FieldValue.serverTimestamp(),
        }),
      );
      unawaited(
        PaymentTransactionRepository.recordPayment(
          orderId: orderId,
          stageLabel: 'Pelunasan',
          amount: remainingPayment,
          methodLabel: 'QRIS',
          createdAtLabel: current.scheduleLabel,
          gatewayReference: 'ASKIA-SETTLEMENT-$orderId',
        ),
      );
      return;
    }

    final int index = _localOrders.indexWhere(
      (OrderRecord order) => order.id == orderId,
    );
    if (index == -1) {
      return;
    }
    final OrderRecord current = _localOrders[index];
    final int remainingPayment = current.remainingPayment;
    if (remainingPayment <= 0) {
      return;
    }
    _localOrders[index] = OrderRecord(
      id: current.id,
      vendorId: current.vendorId,
      vendorName: current.vendorName,
      menuName: current.menuName,
      quantity: current.quantity,
      totalPrice: current.totalPrice,
      status: current.status,
      scheduleLabel: current.scheduleLabel,
      deliveryAddress: current.deliveryAddress,
      buyerId: current.buyerId,
      buyerName: current.buyerName,
      amountPaid: current.totalPrice,
      paymentMethodLabel: 'QRIS',
      paymentStatus: 'Lunas',
      notes: current.notes,
      cancelReason: current.cancelReason,
      lineItems: current.lineItems,
    );
    _emitLocalOrders();
    await PaymentTransactionRepository.recordPayment(
      orderId: current.id,
      stageLabel: 'Pelunasan',
      amount: remainingPayment,
      methodLabel: 'QRIS',
      createdAtLabel: current.scheduleLabel,
      gatewayReference: 'ASKIA-SETTLEMENT-${current.id}',
    );
  }

  static int localBuyerOrderCount(String buyerId) {
    return localBuyerOrders(buyerId).length;
  }

  static List<OrderRecord> localBuyerOrders(String buyerId) {
    if (isReady) {
      final List<OrderRecord>? cached = _buyerCloudOrders[buyerId];
      if (cached != null) {
        return List<OrderRecord>.from(cached);
      }
      _fetchBuyerOrders(buyerId);
    }
    return _localOrders.where((OrderRecord order) => order.buyerId == buyerId).toList();
  }

  static int localSellerActiveOrderCount(String vendorId) {
    return localSellerOrders(vendorId)
        .where(
          (OrderRecord order) =>
              order.status != 'Selesai' &&
              order.status != 'Dibatalkan',
        )
        .length;
  }

  static List<OrderRecord> localSellerOrders(String vendorId) {
    if (isReady) {
      final List<OrderRecord>? cached = _sellerCloudOrders[vendorId];
      if (cached != null) {
        return List<OrderRecord>.from(cached);
      }
      _fetchSellerOrders(vendorId);
    }
    return _localOrders.where((OrderRecord order) => order.vendorId == vendorId).toList();
  }

  static List<OrderRecord> localAllOrders() {
    if (isReady) {
      if (_allCloudOrders != null) {
        return List<OrderRecord>.from(_allCloudOrders!);
      }
      _fetchAllOrders();
    }
    return List<OrderRecord>.from(_localOrders);
  }

  static List<OrderRecord> _mapSnapshotToOrders(
    QuerySnapshot<Map<String, dynamic>> snapshot,
  ) {
    final List<OrderRecord> orders = snapshot.docs
        .map(
          (QueryDocumentSnapshot<Map<String, dynamic>> doc) =>
              OrderRecord.fromJson(doc.id, doc.data()),
        )
        .toList();
    orders.sort((OrderRecord a, OrderRecord b) => b.id.compareTo(a.id));
    return orders;
  }

  static Stream<List<OrderRecord>> _watchLocalOrders(
    bool Function(OrderRecord order) predicate,
  ) async* {
    yield _localOrders.where(predicate).toList();
    yield* _localOrderController.stream.map(
      (_) => _localOrders.where(predicate).toList(),
    );
  }

  static void _emitLocalOrders() {
    _localOrderController.add(List<OrderRecord>.unmodifiable(_localOrders));
    updates.value++;
  }

  static Future<void> _syncCreatedOrder(OrderRecord order) async {
    if (!isReady) {
      return;
    }
    try {
      await FirebaseFirestore.instance
          .collection('orders')
          .doc(order.id)
          .set(<String, Object?>{
            ...order.toJson(),
            'createdAt': FieldValue.serverTimestamp(),
          })
          .timeout(const Duration(seconds: 12));
    } catch (_) {}
  }

  static Future<void> _syncOrderFields(
    String orderId,
    Map<String, Object?> payload,
  ) async {
    if (!isReady) {
      return;
    }
    try {
      await FirebaseFirestore.instance
          .collection('orders')
          .doc(orderId)
          .set(payload, SetOptions(merge: true))
          .timeout(const Duration(seconds: 12));
    } catch (_) {}
  }

  static void _fetchBuyerOrders(String buyerId) {
    if (!isReady || _fetchingBuyerIds.contains(buyerId)) {
      return;
    }
    _fetchingBuyerIds.add(buyerId);
    unawaited(
      FirebaseFirestore.instance
          .collection('orders')
          .where('buyerId', isEqualTo: buyerId)
          .get()
          .then((QuerySnapshot<Map<String, dynamic>> snapshot) {
            final List<OrderRecord> orders = _mapSnapshotToOrders(snapshot);
            _buyerCloudOrders[buyerId] = orders;
            _cacheOrders(orders);
            updates.value++;
          })
          .catchError((_) {})
          .whenComplete(() {
            _fetchingBuyerIds.remove(buyerId);
          }),
    );
  }

  static void _fetchSellerOrders(String vendorId) {
    if (!isReady || _fetchingSellerIds.contains(vendorId)) {
      return;
    }
    _fetchingSellerIds.add(vendorId);
    unawaited(
      FirebaseFirestore.instance
          .collection('orders')
          .where('vendorId', isEqualTo: vendorId)
          .get()
          .then((QuerySnapshot<Map<String, dynamic>> snapshot) {
            final List<OrderRecord> orders = _mapSnapshotToOrders(snapshot);
            _sellerCloudOrders[vendorId] = orders;
            _cacheOrders(orders);
            updates.value++;
          })
          .catchError((_) {})
          .whenComplete(() {
            _fetchingSellerIds.remove(vendorId);
          }),
    );
  }

  static void _fetchAllOrders() {
    if (!isReady || _fetchingAllOrders) {
      return;
    }
    _fetchingAllOrders = true;
    unawaited(
      FirebaseFirestore.instance
          .collection('orders')
          .get()
          .then((QuerySnapshot<Map<String, dynamic>> snapshot) {
            final List<OrderRecord> orders = _mapSnapshotToOrders(snapshot);
            _allCloudOrders = orders;
            _cacheOrders(orders);
            updates.value++;
          })
          .catchError((_) {})
          .whenComplete(() {
            _fetchingAllOrders = false;
          }),
    );
  }

  static void _rememberCloudOrder(OrderRecord order) {
    _cacheOrders(<OrderRecord>[order]);
    _buyerCloudOrders[order.buyerId] = <OrderRecord>[
      order,
      ...(_buyerCloudOrders[order.buyerId] ?? const <OrderRecord>[])
          .where((OrderRecord item) => item.id != order.id),
    ];
    _sellerCloudOrders[order.vendorId] = <OrderRecord>[
      order,
      ...(_sellerCloudOrders[order.vendorId] ?? const <OrderRecord>[])
          .where((OrderRecord item) => item.id != order.id),
    ];
    _allCloudOrders = <OrderRecord>[
      order,
      ...(_allCloudOrders ?? const <OrderRecord>[])
          .where((OrderRecord item) => item.id != order.id),
    ];
    updates.value++;
  }

  static void _cacheOrders(List<OrderRecord> orders) {
    final Map<String, OrderRecord> merged = <String, OrderRecord>{
      for (final OrderRecord order in (_allCloudOrders ?? const <OrderRecord>[]))
        order.id: order,
      for (final OrderRecord order in orders) order.id: order,
    };
    _allCloudOrders = merged.values.toList()
      ..sort((OrderRecord a, OrderRecord b) => b.id.compareTo(a.id));
  }

  static void _patchCachedOrder(
    String orderId,
    OrderRecord Function(OrderRecord current) transform,
  ) {
    bool changed = false;
    for (final MapEntry<String, List<OrderRecord>> entry in _buyerCloudOrders.entries) {
      final int index =
          entry.value.indexWhere((OrderRecord item) => item.id == orderId);
      if (index != -1) {
        entry.value[index] = transform(entry.value[index]);
        changed = true;
      }
    }
    for (final MapEntry<String, List<OrderRecord>> entry in _sellerCloudOrders.entries) {
      final int index =
          entry.value.indexWhere((OrderRecord item) => item.id == orderId);
      if (index != -1) {
        entry.value[index] = transform(entry.value[index]);
        changed = true;
      }
    }
    if (_allCloudOrders != null) {
      final int index =
          _allCloudOrders!.indexWhere((OrderRecord item) => item.id == orderId);
      if (index != -1) {
        _allCloudOrders![index] = transform(_allCloudOrders![index]);
        changed = true;
      }
    }
    if (changed) {
      updates.value++;
    }
  }

  static void _patchLocalOrder(
    String orderId,
    OrderRecord Function(OrderRecord current) transform,
  ) {
    final int index =
        _localOrders.indexWhere((OrderRecord item) => item.id == orderId);
    if (index == -1) {
      return;
    }
    _localOrders[index] = transform(_localOrders[index]);
    _emitLocalOrders();
  }

  static OrderRecord? _findKnownOrder(String orderId) {
    for (final OrderRecord order in _allCloudOrders ?? const <OrderRecord>[]) {
      if (order.id == orderId) {
        return order;
      }
    }
    for (final OrderRecord order in _localOrders) {
      if (order.id == orderId) {
        return order;
      }
    }
    return null;
  }

}
