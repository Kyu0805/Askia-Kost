import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_models.dart';

class PaymentTransactionRepository {
  const PaymentTransactionRepository._();

  static const String _storageKey = 'askia_payment_transactions_v1';
  static final ValueNotifier<int> updates = ValueNotifier<int>(0);
  static final Map<String, List<PaymentTransactionRecord>> _localTransactions =
      <String, List<PaymentTransactionRecord>>{};
  static final Map<String, List<PaymentTransactionRecord>> _cloudTransactions =
      <String, List<PaymentTransactionRecord>>{};
  static final Set<String> _fetchingOrderIds = <String>{};
  static bool _loaded = false;

  static bool get isReady => Firebase.apps.isNotEmpty;

  static Future<void> ensureLoaded() async {
    if (_loaded) {
      return;
    }
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String? raw = prefs.getString(_storageKey);
    if (raw == null || raw.isEmpty) {
      _seedDefaults();
      await _persist();
      _loaded = true;
      return;
    }
    try {
      final Map<String, dynamic> decoded =
          jsonDecode(raw) as Map<String, dynamic>;
      _localTransactions
        ..clear()
        ..addEntries(
          decoded.entries.map(
            (MapEntry<String, dynamic> entry) => MapEntry<String,
                List<PaymentTransactionRecord>>(
              entry.key,
              (entry.value as List<dynamic>)
                  .cast<Map<String, dynamic>>()
                  .map(
                    (Map<String, dynamic> item) =>
                        PaymentTransactionRecord.fromJson(
                      item['id'] as String? ?? '',
                      item,
                    ),
                  )
                  .toList(),
            ),
          ),
        );
    } catch (_) {
      _seedDefaults();
      await _persist();
    }
    _loaded = true;
  }

  static List<PaymentTransactionRecord> localTransactionsForOrder(String orderId) {
    if (isReady) {
      final List<PaymentTransactionRecord>? cached = _cloudTransactions[orderId];
      if (cached != null) {
        return List<PaymentTransactionRecord>.from(cached);
      }
      _fetchCloudTransactions(orderId);
    }
    if (!_loaded) {
      unawaited(
        ensureLoaded().then((_) {
          _emit();
        }),
      );
    }
    return List<PaymentTransactionRecord>.from(
      _localTransactions[orderId] ?? const <PaymentTransactionRecord>[],
    );
  }

  static Future<void> recordPayment({
    required String orderId,
    required String stageLabel,
    required int amount,
    required String methodLabel,
    required String createdAtLabel,
    String status = 'Berhasil',
    String gatewayReference = '',
  }) async {
    await ensureLoaded();
    final String id = DateTime.now().microsecondsSinceEpoch.toString();
    final PaymentTransactionRecord record = PaymentTransactionRecord(
      id: id,
      orderId: orderId,
      stageLabel: stageLabel,
      amount: amount,
      methodLabel: methodLabel,
      status: status,
      createdAtLabel: createdAtLabel,
      gatewayReference: gatewayReference,
    );
    final List<PaymentTransactionRecord> current =
        List<PaymentTransactionRecord>.from(_localTransactions[orderId] ?? const <PaymentTransactionRecord>[]);
    current.insert(0, record);
    _localTransactions[orderId] = current;
    _cloudTransactions[orderId] = List<PaymentTransactionRecord>.from(current);
    await _persist();
    _emit();
    await _syncToCloud(record);
  }

  static void _seedDefaults() {
    _localTransactions
      ..clear()
      ..addAll(<String, List<PaymentTransactionRecord>>{
        'seed-order-1': <PaymentTransactionRecord>[
          const PaymentTransactionRecord(
            id: 'payment-seed-1',
            orderId: 'seed-order-1',
            stageLabel: 'DP 50%',
            amount: 735000,
            methodLabel: 'QRIS',
            status: 'Berhasil',
            createdAtLabel: '24 Maret 2026 • 10:00',
            gatewayReference: 'ASKIA-DP-0001',
          ),
        ],
        'seed-order-2': <PaymentTransactionRecord>[
          const PaymentTransactionRecord(
            id: 'payment-seed-2',
            orderId: 'seed-order-2',
            stageLabel: 'Pelunasan',
            amount: 360000,
            methodLabel: 'QRIS',
            status: 'Berhasil',
            createdAtLabel: '17 Maret 2026 • 09:30',
            gatewayReference: 'ASKIA-FULL-0002',
          ),
          const PaymentTransactionRecord(
            id: 'payment-seed-3',
            orderId: 'seed-order-2',
            stageLabel: 'DP 50%',
            amount: 360000,
            methodLabel: 'QRIS',
            status: 'Berhasil',
            createdAtLabel: '15 Maret 2026 • 15:00',
            gatewayReference: 'ASKIA-DP-0002',
          ),
        ],
      });
  }

  static Future<void> _persist() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final Map<String, Object> payload = <String, Object>{
      for (final MapEntry<String, List<PaymentTransactionRecord>> entry
          in _localTransactions.entries)
        entry.key: entry.value
            .map(
              (PaymentTransactionRecord item) => <String, Object>{
                'id': item.id,
                ...item.toJson(),
              },
            )
            .toList(),
    };
    await prefs.setString(_storageKey, jsonEncode(payload));
  }

  static void _emit() {
    updates.value++;
  }

  static Future<void> _syncToCloud(PaymentTransactionRecord record) async {
    if (!isReady) {
      return;
    }
    try {
      await FirebaseFirestore.instance
          .collection('orders')
          .doc(record.orderId)
          .collection('payments')
          .doc(record.id)
          .set(record.toJson());
    } catch (_) {}
  }

  static void _fetchCloudTransactions(String orderId) {
    if (!isReady || _fetchingOrderIds.contains(orderId)) {
      return;
    }
    _fetchingOrderIds.add(orderId);
    unawaited(
      FirebaseFirestore.instance
          .collection('orders')
          .doc(orderId)
          .collection('payments')
          .get()
          .then((QuerySnapshot<Map<String, dynamic>> snapshot) {
            final List<PaymentTransactionRecord> items = snapshot.docs
                .map(
                  (QueryDocumentSnapshot<Map<String, dynamic>> doc) =>
                      PaymentTransactionRecord.fromJson(doc.id, doc.data()),
                )
                .toList()
              ..sort(
                (PaymentTransactionRecord a, PaymentTransactionRecord b) =>
                    b.id.compareTo(a.id),
              );
            _cloudTransactions[orderId] = items;
            _emit();
          })
          .catchError((_) {})
          .whenComplete(() {
            _fetchingOrderIds.remove(orderId);
          }),
    );
  }
}
