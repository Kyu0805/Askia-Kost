import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

enum AppMode { buyer, seller, admin }

enum SellerEntryType { paket, item }

class Vendor {
  const Vendor({
    required this.id,
    required this.brandId,
    required this.brandName,
    required this.name,
    required this.locationLabel,
    required this.rating,
    required this.reviewCount,
    required this.chatHint,
    required this.description,
    required this.areaGroup,
    required this.position,
    required this.gallery,
    required this.packages,
    required this.foods,
    required this.drinks,
    required this.others,
    this.contactLabel = '0812-3456-7890',
    this.minimumOrderLabel = 'Mulai sewa 1 bulan',
    this.serviceAreaSummary = 'Depok dan sekitarnya',
    this.addressDetail = 'Alamat properti belum diperbarui.',
    this.isOpen = true,
  });

  final String id;
  final String brandId;
  final String brandName;
  final String name;
  final String locationLabel;
  final double rating;
  final int reviewCount;
  final String chatHint;
  final String description;
  final String areaGroup;
  final LatLng position;
  final List<StoreMedia> gallery;
  final List<MenuItemData> packages;
  final List<MenuItemData> foods;
  final List<MenuItemData> drinks;
  final List<MenuItemData> others;
  final String contactLabel;
  final String minimumOrderLabel;
  final String serviceAreaSummary;
  final String addressDetail;
  final bool isOpen;
}

class StoreMedia {
  const StoreMedia({
    required this.title,
    required this.subtitle,
    required this.color,
    required this.icon,
    this.imagePath,
  });

  final String title;
  final String subtitle;
  final Color color;
  final IconData icon;
  final String? imagePath;

  Map<String, Object?> toJson() {
    return <String, Object?>{
      'title': title,
      'subtitle': subtitle,
      'imagePath': imagePath,
    };
  }

  factory StoreMedia.fromJson(
    Map<String, dynamic> json, {
    required Color fallbackColor,
    required IconData fallbackIcon,
  }) {
    return StoreMedia(
      title: json['title'] as String? ?? 'Foto Properti',
      subtitle: json['subtitle'] as String? ?? 'Dokumentasi kos',
      color: fallbackColor,
      icon: fallbackIcon,
      imagePath: json['imagePath'] as String?,
    );
  }
}

class MenuItemData {
  const MenuItemData({
    required this.name,
    required this.price,
    required this.description,
    this.components = const <String>[],
  });

  final String name;
  final int price;
  final String description;
  final List<String> components;
}

class OrderLineItem {
  const OrderLineItem({
    required this.name,
    required this.unitPrice,
    required this.quantity,
  });

  final String name;
  final int unitPrice;
  final int quantity;

  int get subtotal => unitPrice * quantity;

  Map<String, Object> toJson() {
    return <String, Object>{
      'name': name,
      'unitPrice': unitPrice,
      'quantity': quantity,
    };
  }

  factory OrderLineItem.fromJson(Map<String, dynamic> json) {
    return OrderLineItem(
      name: json['name'] as String? ?? '',
      unitPrice: json['unitPrice'] as int? ?? 0,
      quantity: json['quantity'] as int? ?? 0,
    );
  }
}

class ChatMessage {
  const ChatMessage({
    required this.text,
    required this.isMine,
    required this.time,
    this.senderId = '',
    this.senderLabel = '',
    this.deliveryStatus = 'sent',
  });

  final String text;
  final bool isMine;
  final String time;
  final String senderId;
  final String senderLabel;
  final String deliveryStatus;

  Map<String, Object> toJson() {
    return <String, Object>{
      'text': text,
      'time': time,
      'senderId': senderId,
      'senderLabel': senderLabel,
      'deliveryStatus': deliveryStatus,
    };
  }

  factory ChatMessage.fromJson(
    Map<String, dynamic> json, {
    required String currentSenderId,
  }) {
    final String senderId = json['senderId'] as String? ?? '';
    return ChatMessage(
      text: json['text'] as String? ?? '',
      time: json['time'] as String? ?? '',
      senderId: senderId,
      senderLabel: json['senderLabel'] as String? ?? '',
      deliveryStatus: json['deliveryStatus'] as String? ?? 'sent',
      isMine: senderId == currentSenderId,
    );
  }
}

class CustomMenuRequest {
  const CustomMenuRequest({
    required this.id,
    required this.vendorId,
    required this.vendorName,
    required this.buyerId,
    required this.buyerName,
    required this.title,
    required this.description,
    required this.targetPax,
    required this.budgetLabel,
    required this.status,
    required this.createdAtLabel,
    this.sellerResponse = '',
    this.quotedPriceLabel = '',
  });

  final String id;
  final String vendorId;
  final String vendorName;
  final String buyerId;
  final String buyerName;
  final String title;
  final String description;
  final int targetPax;
  final String budgetLabel;
  final String status;
  final String createdAtLabel;
  final String sellerResponse;
  final String quotedPriceLabel;

  Map<String, Object> toJson() {
    return <String, Object>{
      'vendorId': vendorId,
      'vendorName': vendorName,
      'buyerId': buyerId,
      'buyerName': buyerName,
      'title': title,
      'description': description,
      'targetPax': targetPax,
      'budgetLabel': budgetLabel,
      'status': status,
      'createdAtLabel': createdAtLabel,
      'sellerResponse': sellerResponse,
      'quotedPriceLabel': quotedPriceLabel,
    };
  }

  factory CustomMenuRequest.fromJson(String id, Map<String, dynamic> json) {
    return CustomMenuRequest(
      id: id,
      vendorId: json['vendorId'] as String? ?? '',
      vendorName: json['vendorName'] as String? ?? '',
      buyerId: json['buyerId'] as String? ?? 'buyer-demo',
      buyerName: json['buyerName'] as String? ?? 'Pembeli',
      title: json['title'] as String? ?? '',
      description: json['description'] as String? ?? '',
      targetPax: json['targetPax'] as int? ?? 0,
      budgetLabel: json['budgetLabel'] as String? ?? '',
      status: json['status'] as String? ?? 'Masuk',
      createdAtLabel: json['createdAtLabel'] as String? ?? '',
      sellerResponse: json['sellerResponse'] as String? ?? '',
      quotedPriceLabel: json['quotedPriceLabel'] as String? ?? '',
    );
  }
}

class OrderRecord {
  const OrderRecord({
    required this.id,
    required this.vendorId,
    required this.vendorName,
    required this.menuName,
    required this.quantity,
    required this.totalPrice,
    required this.status,
    required this.scheduleLabel,
    required this.deliveryAddress,
    required this.buyerId,
    required this.buyerName,
    this.amountPaid = 0,
    this.paymentMethodLabel = 'QRIS',
    this.paymentStatus = 'DP 50%',
    this.notes = '',
    this.cancelReason = '',
    this.lineItems = const <OrderLineItem>[],
  });

  final String id;
  final String vendorId;
  final String vendorName;
  final String menuName;
  final int quantity;
  final int totalPrice;
  final String status;
  final String scheduleLabel;
  final String deliveryAddress;
  final String buyerId;
  final String buyerName;
  final int amountPaid;
  final String paymentMethodLabel;
  final String paymentStatus;
  final String notes;
  final String cancelReason;
  final List<OrderLineItem> lineItems;

  int get remainingPayment => (totalPrice - amountPaid).clamp(0, totalPrice);
  int get totalUnits =>
      lineItems.isNotEmpty
          ? lineItems.fold<int>(0, (int sum, OrderLineItem item) => sum + item.quantity)
          : quantity;

  String get compactMenuLabel {
    if (lineItems.isEmpty) {
      return menuName;
    }
    if (lineItems.length == 1) {
      return lineItems.first.name;
    }
    return '${lineItems.first.name} +${lineItems.length - 1} lainnya';
  }

  OrderRecord copyWith({
    String? status,
    int? amountPaid,
    String? paymentMethodLabel,
    String? paymentStatus,
    String? notes,
    String? cancelReason,
    List<OrderLineItem>? lineItems,
  }) {
    return OrderRecord(
      id: id,
      vendorId: vendorId,
      vendorName: vendorName,
      menuName: menuName,
      quantity: quantity,
      totalPrice: totalPrice,
      status: status ?? this.status,
      scheduleLabel: scheduleLabel,
      deliveryAddress: deliveryAddress,
      buyerId: buyerId,
      buyerName: buyerName,
      amountPaid: amountPaid ?? this.amountPaid,
      paymentMethodLabel: paymentMethodLabel ?? this.paymentMethodLabel,
      paymentStatus: paymentStatus ?? this.paymentStatus,
      notes: notes ?? this.notes,
      cancelReason: cancelReason ?? this.cancelReason,
      lineItems: lineItems ?? this.lineItems,
    );
  }

  Map<String, Object> toJson() {
    return <String, Object>{
      'vendorId': vendorId,
      'vendorName': vendorName,
      'menuName': menuName,
      'quantity': quantity,
      'totalPrice': totalPrice,
      'status': status,
      'scheduleLabel': scheduleLabel,
      'deliveryAddress': deliveryAddress,
      'buyerId': buyerId,
      'buyerName': buyerName,
      'amountPaid': amountPaid,
      'paymentMethodLabel': paymentMethodLabel,
      'paymentStatus': paymentStatus,
      'notes': notes,
      'cancelReason': cancelReason,
      'lineItems': lineItems.map((OrderLineItem item) => item.toJson()).toList(),
    };
  }

  factory OrderRecord.fromJson(String id, Map<String, dynamic> json) {
    return OrderRecord(
      id: id,
      vendorId: json['vendorId'] as String? ?? '',
      vendorName: json['vendorName'] as String? ?? '',
      menuName: json['menuName'] as String? ?? '',
      quantity: json['quantity'] as int? ?? 0,
      totalPrice: json['totalPrice'] as int? ?? 0,
      status: json['status'] as String? ?? 'Baru',
      scheduleLabel: json['scheduleLabel'] as String? ?? '',
      deliveryAddress: json['deliveryAddress'] as String? ?? '',
      buyerId: json['buyerId'] as String? ?? 'buyer-demo',
      buyerName: json['buyerName'] as String? ?? 'Pembeli',
      amountPaid: json['amountPaid'] as int? ?? 0,
      paymentMethodLabel: json['paymentMethodLabel'] as String? ?? 'QRIS',
      paymentStatus: json['paymentStatus'] as String? ?? 'DP 50%',
      notes: json['notes'] as String? ?? '',
      cancelReason: json['cancelReason'] as String? ?? '',
      lineItems: ((json['lineItems'] as List<dynamic>?) ?? <dynamic>[])
          .whereType<Map>()
          .map(
            (Map item) => OrderLineItem.fromJson(
              Map<String, dynamic>.from(item),
            ),
          )
          .toList(),
    );
  }
}

class PaymentTransactionRecord {
  const PaymentTransactionRecord({
    required this.id,
    required this.orderId,
    required this.stageLabel,
    required this.amount,
    required this.methodLabel,
    required this.status,
    required this.createdAtLabel,
    this.gatewayReference = '',
  });

  final String id;
  final String orderId;
  final String stageLabel;
  final int amount;
  final String methodLabel;
  final String status;
  final String createdAtLabel;
  final String gatewayReference;

  Map<String, Object> toJson() {
    return <String, Object>{
      'orderId': orderId,
      'stageLabel': stageLabel,
      'amount': amount,
      'methodLabel': methodLabel,
      'status': status,
      'createdAtLabel': createdAtLabel,
      'gatewayReference': gatewayReference,
    };
  }

  factory PaymentTransactionRecord.fromJson(
    String id,
    Map<String, dynamic> json,
  ) {
    return PaymentTransactionRecord(
      id: id,
      orderId: json['orderId'] as String? ?? '',
      stageLabel: json['stageLabel'] as String? ?? 'Pembayaran',
      amount: json['amount'] as int? ?? 0,
      methodLabel: json['methodLabel'] as String? ?? 'QRIS',
      status: json['status'] as String? ?? 'Berhasil',
      createdAtLabel: json['createdAtLabel'] as String? ?? '',
      gatewayReference: json['gatewayReference'] as String? ?? '',
    );
  }
}

class SellerMenuEntry {
  const SellerMenuEntry({
    required this.id,
    required this.vendorId,
    required this.name,
    required this.price,
    required this.category,
    required this.type,
    required this.items,
  });

  final String id;
  final String vendorId;
  final String name;
  final int price;
  final String category;
  final SellerEntryType type;
  final List<String> items;

  Map<String, Object> toJson() {
    return <String, Object>{
      'id': id,
      'vendorId': vendorId,
      'name': name,
      'price': price,
      'category': category,
      'type': type.name,
      'items': items,
    };
  }

  factory SellerMenuEntry.fromJson(Map<String, dynamic> json) {
    return SellerMenuEntry(
      id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
      vendorId: json['vendorId'] as String? ?? 'vendor-1',
      name: json['name'] as String? ?? '',
      price: json['price'] as int? ?? 0,
      category: json['category'] as String? ?? 'Lainnya',
      type: (json['type'] as String?) == SellerEntryType.item.name
          ? SellerEntryType.item
          : SellerEntryType.paket,
      items: ((json['items'] as List<dynamic>?) ?? <dynamic>[])
          .map((dynamic item) => item.toString())
          .toList(),
    );
  }
}
