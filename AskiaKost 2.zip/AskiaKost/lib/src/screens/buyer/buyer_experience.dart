import 'dart:async';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../config/app_visibility_flags.dart';
import '../../data/buyer_profile_repository.dart';
import '../../data/custom_menu_request_repository.dart';
import '../../data/sample_data.dart';
import '../../data/chat_repository.dart';
import '../../data/favorite_repository.dart';
import '../../data/kos_recommendation_repository.dart';
import '../../data/order_repository.dart';
import '../../data/payment_transaction_repository.dart';
import '../../data/vendor_cloud_repository.dart';
import '../../data/vendor_location_repository.dart';
import '../../data/vendor_menu_cloud_repository.dart';
import '../../data/vendor_media_repository.dart';
import '../../data/vendor_profile_repository.dart';
import '../../models/app_models.dart';
import '../../state/seller_menu_controller.dart';
import '../../theme/app_theme.dart';
import '../../utils/chat_payloads.dart';

final ValueNotifier<int> _buyerOpenOrdersSignal = ValueNotifier<int>(0);

class BuyerShell extends StatefulWidget {
  const BuyerShell({
    super.key,
    required this.isGuest,
    required this.onRequireLogin,
    required this.onSwitchMode,
    required this.onLogout,
    required this.statusMessage,
    required this.isCloudReady,
  });

  final bool isGuest;
  final Future<void> Function(BuildContext context, {AppMode? preferredMode})
  onRequireLogin;
  final VoidCallback onSwitchMode;
  final VoidCallback onLogout;
  final String statusMessage;
  final bool isCloudReady;

  @override
  State<BuyerShell> createState() => _BuyerShellState();
}

class _BuyerShellState extends State<BuyerShell> with WidgetsBindingObserver {
  int _index = 0;
  List<Vendor> _vendors = sampleVendors;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    VendorLocationRepository.updates.addListener(_loadVendors);
    VendorMediaRepository.updates.addListener(_loadVendors);
    VendorProfileRepository.updates.addListener(_loadVendors);
    _buyerOpenOrdersSignal.addListener(_openOrdersTab);
    _loadVendors();
  }

  @override
  void dispose() {
    VendorLocationRepository.updates.removeListener(_loadVendors);
    VendorMediaRepository.updates.removeListener(_loadVendors);
    VendorProfileRepository.updates.removeListener(_loadVendors);
    _buyerOpenOrdersSignal.removeListener(_openOrdersTab);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _openOrdersTab() {
    if (!mounted) {
      return;
    }
    setState(() {
      _index = 2;
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _loadVendors();
    }
  }

  Future<void> _loadVendors() async {
    final List<Vendor> vendors = await VendorCloudRepository.fetchVendors();
    if (!mounted) {
      return;
    }
    setState(() {
      _vendors = vendors;
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> tabs = <Widget>[
      BuyerHomePage(
        isGuest: widget.isGuest,
        onRequireLogin: widget.onRequireLogin,
        onSwitchMode: widget.onSwitchMode,
        onOpenOrders: () {
          setState(() {
            _index = 2;
          });
        },
        onOpenChat: () {
          setState(() {
            _index = 3;
          });
        },
        onOpenMap: () {
          setState(() {
            _index = 1;
          });
        },
        vendors: _vendors,
        statusMessage: widget.statusMessage,
        isCloudReady: widget.isCloudReady,
      ),
      BuyerMapPage(
        vendors: _vendors,
        isGuest: widget.isGuest,
        onRequireLogin: widget.onRequireLogin,
      ),
      const BuyerOrdersPage(),
      BuyerChatListPage(vendors: _vendors),
      BuyerProfilePage(
        vendors: _vendors,
        onSwitchMode: widget.onSwitchMode,
        onLogout: widget.onLogout,
        onOpenOrders: () {
          setState(() {
            _index = 2;
          });
        },
        onOpenChat: () {
          setState(() {
            _index = 3;
          });
        },
        statusMessage: widget.statusMessage,
        isCloudReady: widget.isCloudReady,
      ),
    ];

    return Scaffold(
      body: SafeArea(child: tabs[_index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        backgroundColor: Colors.white,
        indicatorColor: kPrimarySoft,
        onDestinationSelected: (int value) async {
          if (widget.isGuest && value >= 2) {
            await widget.onRequireLogin(
              context,
              preferredMode: value == 4 ? null : AppMode.buyer,
            );
            return;
          }
          setState(() {
            _index = value;
          });
          _loadVendors();
        },
        destinations: <NavigationDestination>[
          NavigationDestination(
            icon: const Icon(Icons.search_rounded),
            label: 'Beranda',
          ),
          const NavigationDestination(
            icon: Icon(Icons.map_rounded),
            label: 'Peta',
          ),
          const NavigationDestination(
            icon: Icon(Icons.receipt_long_rounded),
            label: 'Pesanan',
          ),
          const NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline_rounded),
            label: 'Chat',
          ),
          NavigationDestination(
            icon: Icon(
              widget.isGuest
                  ? Icons.login_rounded
                  : Icons.person_outline_rounded,
            ),
            label: widget.isGuest ? 'Masuk' : 'Profil',
          ),
        ],
      ),
    );
  }
}

class _CheckoutScaffold extends StatelessWidget {
  const _CheckoutScaffold({required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackground,
      appBar: AppBar(title: Text(title), backgroundColor: kBackground),
      body: SafeArea(child: child),
    );
  }
}

class BuyerHomePage extends StatefulWidget {
  const BuyerHomePage({
    super.key,
    required this.isGuest,
    required this.onRequireLogin,
    required this.onSwitchMode,
    required this.onOpenOrders,
    required this.onOpenChat,
    required this.onOpenMap,
    required this.vendors,
    required this.statusMessage,
    required this.isCloudReady,
  });

  final bool isGuest;
  final Future<void> Function(BuildContext context, {AppMode? preferredMode})
  onRequireLogin;
  final VoidCallback onSwitchMode;
  final VoidCallback onOpenOrders;
  final VoidCallback onOpenChat;
  final VoidCallback onOpenMap;
  final List<Vendor> vendors;
  final String statusMessage;
  final bool isCloudReady;

  @override
  State<BuyerHomePage> createState() => _BuyerHomePageState();
}

class _BuyerHomePageState extends State<BuyerHomePage> {
  String _searchQuery = '';
  late final TextEditingController _searchController = TextEditingController();
  late final PageController _vendorPageController = PageController(
    viewportFraction: 0.92,
  );
  late Future<List<KosRecommendation>> _recommendationsFuture;
  int _currentVendorPage = 0;

  @override
  void initState() {
    super.initState();
    _recommendationsFuture = KosRecommendationRepository.fetchForCurrentUser();
  }

  @override
  void didUpdateWidget(covariant BuyerHomePage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!oldWidget.isCloudReady && widget.isCloudReady) {
      _recommendationsFuture =
          KosRecommendationRepository.fetchForCurrentUser();
    }
  }

  List<Vendor> get _filteredVendors {
    if (_searchQuery.isEmpty) {
      return widget.vendors;
    }
    final String query = _searchQuery.toLowerCase();
    return widget.vendors.where((Vendor vendor) {
      return vendor.name.toLowerCase().contains(query) ||
          vendor.locationLabel.toLowerCase().contains(query) ||
          vendor.areaGroup.toLowerCase().contains(query) ||
          vendor.description.toLowerCase().contains(query);
    }).toList();
  }

  void _resetVendorPager() {
    _currentVendorPage = 0;
    if (_vendorPageController.hasClients) {
      _vendorPageController.jumpToPage(0);
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    _vendorPageController.dispose();
    super.dispose();
  }

  Future<void> _showBuyerNotifications() async {
    if (widget.isGuest) {
      await widget.onRequireLogin(context, preferredMode: AppMode.buyer);
      return;
    }
    if (!mounted) {
      return;
    }
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      builder: (BuildContext context) {
        return _BuyerNotificationsSheet(
          vendors: widget.vendors,
          onOpenOrders: widget.onOpenOrders,
          onOpenChat: widget.onOpenChat,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: <Widget>[
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          sliver: SliverToBoxAdapter(
            child: Row(
              children: <Widget>[
                const AppLogo(size: 42),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'askia kost',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: kPrimaryDark,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        'Cari kos jadi lebih mudah',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ],
                  ),
                ),
                AnimatedBuilder(
                  animation: Listenable.merge(<Listenable>[
                    OrderRepository.updates,
                    ChatRepository.updates,
                    CustomMenuRequestRepository.updates,
                  ]),
                  builder: (BuildContext context, _) {
                    final int notificationCount =
                        widget.isGuest
                            ? 0
                            : _buildBuyerNotifications(widget.vendors).length;
                    return NotificationBellButton(
                      count: notificationCount,
                      onTap: _showBuyerNotifications,
                    );
                  },
                ),
              ],
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 20)),
        SliverToBoxAdapter(
          child: FutureBuilder<List<KosRecommendation>>(
            future: _recommendationsFuture,
            builder: (
              BuildContext context,
              AsyncSnapshot<List<KosRecommendation>> snapshot,
            ) {
              final List<KosRecommendation> recommendations =
                  snapshot.data ?? const <KosRecommendation>[];
              if (recommendations.isEmpty) {
                return const SizedBox.shrink();
              }
              return _KosRecommendationSection(
                recommendations: recommendations,
              );
            },
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverToBoxAdapter(
            child: Text(
              'Askia Kost',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 6)),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverToBoxAdapter(
            child: Text(
              'Pilih kos berdasarkan area, budget, dan fasilitas yang paling cocok untuk kamu.',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ),
        ),
        if (kShowInternalStatusBanners) ...<Widget>[
          const SliverToBoxAdapter(child: SizedBox(height: 18)),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            sliver: SliverToBoxAdapter(
              child: DemoModeBanner(
                title:
                    widget.isCloudReady ? 'Cloud Aktif' : 'Demo Siap Dipakai',
                message:
                    widget.isCloudReady
                        ? widget.statusMessage
                        : 'Maps, chat, booking, favorite, admin, dan seller flow sudah aktif. ${widget.statusMessage}',
              ),
            ),
          ),
        ],
        const SliverToBoxAdapter(child: SizedBox(height: 18)),
        SliverPersistentHeader(
          pinned: true,
          delegate: _PinnedSearchBarDelegate(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
              child: Material(
                color: const Color(0xFFF6FAF7),
                borderRadius: BorderRadius.circular(20),
                child: TextField(
                  controller: _searchController,
                  onChanged: (String value) {
                    setState(() {
                      _searchQuery = value;
                      _resetVendorPager();
                    });
                  },
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search_rounded),
                    hintText: 'Cari kos atau area',
                    suffixIcon:
                        _searchQuery.isEmpty
                            ? null
                            : IconButton(
                              onPressed: () {
                                setState(() {
                                  _searchQuery = '';
                                  _searchController.clear();
                                  _resetVendorPager();
                                });
                              },
                              icon: const Icon(Icons.close_rounded),
                            ),
                  ),
                ),
              ),
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 6, 20, 0),
          sliver: SliverToBoxAdapter(
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(28),
                boxShadow: const <BoxShadow>[
                  BoxShadow(
                    color: Color(0x10000000),
                    blurRadius: 24,
                    offset: Offset(0, 8),
                  ),
                ],
              ),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          '#EnaknyaCariKos',
                          style: Theme.of(context).textTheme.headlineSmall,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Temukan kos yang pas, lihat lokasi, chat pemilik, dan bandingkan tipe kamar dengan lebih cepat.',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  Container(
                    width: 88,
                    height: 88,
                    decoration: BoxDecoration(
                      color: kPrimarySoft,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: const Icon(
                      Icons.apartment_rounded,
                      color: kPrimary,
                      size: 42,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 18)),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverToBoxAdapter(
            child: _HomeShortcutCard(
              icon: Icons.map_rounded,
              title: 'Lihat kos dari peta',
              subtitle:
                  'Temukan kos di area Depok, Sawangan, Margonda, dan sekitarnya.',
              onTap: widget.onOpenMap,
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 20)),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverToBoxAdapter(
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: const LinearGradient(
                  colors: <Color>[Color(0xFF4C1D95), Color(0xFF7C3AED)],
                ),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    'PROMO ASKIA',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  SizedBox(height: 12),
                  Text(
                    'Temukan kos dekat kampus, stasiun, dan area kerja favoritmu.',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      height: 1.2,
                    ),
                  ),
                  SizedBox(height: 18),
                  Row(
                    children: <Widget>[
                      _PromoBox(label: '01 hari'),
                      SizedBox(width: 10),
                      _PromoBox(label: '10'),
                      SizedBox(width: 10),
                      _PromoBox(label: '39'),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 20)),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverToBoxAdapter(
            child: Text(
              _searchQuery.isEmpty
                  ? 'Semua Kos'
                  : 'Hasil Pencarian (${_filteredVendors.length})',
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 12)),
        if (_filteredVendors.isEmpty)
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            sliver: SliverToBoxAdapter(
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: kBorder),
                ),
                child: Text(
                  'Belum ada kos yang cocok dengan pencarianmu.',
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ),
            ),
          ),
        if (_filteredVendors.isNotEmpty) ...<Widget>[
          SliverToBoxAdapter(
            child: SizedBox(
              height: 372,
              child: PageView.builder(
                controller: _vendorPageController,
                itemCount: _filteredVendors.length,
                onPageChanged: (int index) {
                  setState(() {
                    _currentVendorPage = index;
                  });
                },
                itemBuilder: (BuildContext context, int index) {
                  final Vendor vendor = _filteredVendors[index];
                  return Padding(
                    padding: EdgeInsets.only(
                      left: 20,
                      right: index == _filteredVendors.length - 1 ? 20 : 8,
                    ),
                    child: BuyerVendorListCard(
                      vendor: vendor,
                      allVendors: widget.vendors,
                      isGuest: widget.isGuest,
                      onRequireLogin: widget.onRequireLogin,
                    ),
                  );
                },
              ),
            ),
          ),
          const SliverToBoxAdapter(child: SizedBox(height: 12)),
          if (_filteredVendors.length > 1)
            SliverToBoxAdapter(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List<Widget>.generate(_filteredVendors.length, (
                  int index,
                ) {
                  final bool isActive = index == _currentVendorPage;
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: isActive ? 20 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: isActive ? kPrimary : const Color(0xFFD1D5DB),
                      borderRadius: BorderRadius.circular(999),
                    ),
                  );
                }),
              ),
            ),
        ],
        const SliverToBoxAdapter(child: SizedBox(height: 18)),
      ],
    );
  }
}

class _KosRecommendationSection extends StatelessWidget {
  const _KosRecommendationSection({required this.recommendations});

  final List<KosRecommendation> recommendations;

  String _formatPrice(KosRecommendation item) {
    final String amount = item.monthlyPrice.toString().replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (_) => '.',
    );
    return '${item.currency} $amount/bulan';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Rekomendasi untukmu',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        recommendations.every(
                              (KosRecommendation item) => item.isDemo,
                            )
                            ? 'Data demo • TF-IDF dan cosine similarity'
                            : 'Diurutkan dengan TF-IDF dan cosine similarity',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.auto_awesome_rounded, color: kPrimary),
              ],
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 224,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              scrollDirection: Axis.horizontal,
              itemCount: recommendations.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (BuildContext context, int index) {
                final KosRecommendation item = recommendations[index];
                return Container(
                  width: 270,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: kBorder),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 9,
                              vertical: 5,
                            ),
                            decoration: BoxDecoration(
                              color: kPrimarySoft,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              '#${item.rank}',
                              style: const TextStyle(
                                color: kPrimaryDark,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          const Spacer(),
                          Text(
                            'Skor ${item.cosineSimilarity.toStringAsFixed(3)}',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        item.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 6),
                      Text(
                        item.location,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        _formatPrice(item),
                        style: Theme.of(
                          context,
                        ).textTheme.titleSmall?.copyWith(color: kPrimaryDark),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        item.reasons.isEmpty
                            ? 'Cocok dengan profil pencarianmu'
                            : item.reasons.last,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class BuyerVendorListCard extends StatelessWidget {
  const BuyerVendorListCard({
    super.key,
    required this.vendor,
    required this.allVendors,
    this.isGuest = false,
    this.onRequireLogin,
  });

  final Vendor vendor;
  final List<Vendor> allVendors;
  final bool isGuest;
  final Future<void> Function(BuildContext context, {AppMode? preferredMode})?
  onRequireLogin;

  int get _brandPropertyCount =>
      allVendors
          .where((Vendor candidate) => candidate.brandId == vendor.brandId)
          .length;

  @override
  Widget build(BuildContext context) {
    final StoreMedia? coverMedia =
        vendor.gallery.isNotEmpty ? vendor.gallery.first : null;
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder:
                (_) => StoreDetailPage(
                  vendor: vendor,
                  allVendors: allVendors,
                  isGuest: isGuest,
                  onRequireLogin: onRequireLogin,
                ),
          ),
        );
      },
      child: Ink(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: kBorder),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                _StoreStatusChip(isOpen: vendor.isOpen),
                const Spacer(),
                Text(
                  vendor.minimumOrderLabel,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              height: 168,
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                gradient: const LinearGradient(
                  colors: <Color>[Color(0xFFD7F3E2), Color(0xFFE7F4FD)],
                ),
              ),
              child:
                  coverMedia?.imagePath != null
                      ? Stack(
                        fit: StackFit.expand,
                        children: <Widget>[
                          Image.file(
                            File(coverMedia!.imagePath!),
                            fit: BoxFit.cover,
                            errorBuilder:
                                (_, __, ___) => Container(
                                  color: coverMedia.color,
                                  child: Center(
                                    child: Icon(
                                      coverMedia.icon,
                                      size: 52,
                                      color: kPrimaryDark,
                                    ),
                                  ),
                                ),
                          ),
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: <Color>[
                                  Colors.transparent,
                                  Colors.black.withValues(alpha: 0.18),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                      : Center(
                        child: Icon(
                          coverMedia?.icon ?? Icons.storefront_rounded,
                          size: 52,
                          color: kPrimaryDark,
                        ),
                      ),
            ),
            const SizedBox(height: 14),
            Text(vendor.name, style: Theme.of(context).textTheme.titleLarge),
            if (_brandPropertyCount > 1) ...<Widget>[
              const SizedBox(height: 4),
              Text(
                '${vendor.brandName} • $_brandPropertyCount lokasi',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: kPrimaryDark,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
            const SizedBox(height: 6),
            Text(
              vendor.description,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 10),
            Row(
              children: <Widget>[
                const Icon(Icons.star_rounded, size: 18, color: Colors.amber),
                const SizedBox(width: 4),
                Text(
                  '${vendor.rating} (${vendor.reviewCount})',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(width: 12),
                const Icon(Icons.place_rounded, size: 18, color: kMuted),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    vendor.locationLabel,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class BuyerMapPage extends StatefulWidget {
  const BuyerMapPage({
    super.key,
    required this.vendors,
    required this.isGuest,
    required this.onRequireLogin,
  });

  final List<Vendor> vendors;
  final bool isGuest;
  final Future<void> Function(BuildContext context, {AppMode? preferredMode})
  onRequireLogin;

  @override
  State<BuyerMapPage> createState() => _BuyerMapPageState();
}

class _BuyerMapPageState extends State<BuyerMapPage> {
  String _selectedArea = 'Sawangan';
  String _searchQuery = '';
  BitmapDescriptor? _singleMarker;
  final Map<String, BitmapDescriptor> _clusterMarkers =
      <String, BitmapDescriptor>{};

  @override
  void initState() {
    super.initState();
    _prepareMarkers();
  }

  Future<void> _prepareMarkers() async {
    final BitmapDescriptor single = await _buildSingleMarker();
    final Map<String, List<Vendor>> grouped = _groupedVendors;
    final Map<String, BitmapDescriptor> clusterMarkers =
        <String, BitmapDescriptor>{};
    for (final MapEntry<String, List<Vendor>> entry in grouped.entries) {
      if (entry.value.length > 1) {
        clusterMarkers[entry.key] = await _buildClusterMarker(
          entry.value.length,
        );
      }
    }
    if (!mounted) return;
    setState(() {
      _singleMarker = single;
      _clusterMarkers
        ..clear()
        ..addAll(clusterMarkers);
    });
  }

  Map<String, List<Vendor>> get _groupedVendors {
    final Map<String, List<Vendor>> grouped = <String, List<Vendor>>{};
    for (final Vendor vendor in _filteredVendors) {
      grouped.putIfAbsent(vendor.areaGroup, () => <Vendor>[]).add(vendor);
    }
    return grouped;
  }

  List<Vendor> get _filteredVendors {
    if (_searchQuery.isEmpty) {
      return widget.vendors;
    }
    final String query = _searchQuery.toLowerCase();
    return widget.vendors.where((Vendor vendor) {
      return vendor.name.toLowerCase().contains(query) ||
          vendor.locationLabel.toLowerCase().contains(query) ||
          vendor.areaGroup.toLowerCase().contains(query);
    }).toList();
  }

  Set<Marker> get _markers {
    if (_singleMarker == null) return <Marker>{};
    final Set<Marker> markers = <Marker>{};
    for (final MapEntry<String, List<Vendor>> entry
        in _groupedVendors.entries) {
      final List<Vendor> vendors = entry.value;
      if (vendors.length == 1) {
        final Vendor vendor = vendors.first;
        markers.add(
          Marker(
            markerId: MarkerId(vendor.id),
            position: vendor.position,
            icon: _singleMarker!,
            onTap: () {
              setState(() {
                _selectedArea = vendor.areaGroup;
              });
            },
          ),
        );
      } else {
        markers.add(
          Marker(
            markerId: MarkerId('cluster-${entry.key}'),
            position: vendors.first.position,
            icon: _clusterMarkers[entry.key] ?? _singleMarker!,
            onTap: () {
              setState(() {
                _selectedArea = entry.key;
              });
            },
          ),
        );
      }
    }
    return markers;
  }

  List<Vendor> get _selectedVendors {
    if (_groupedVendors.isEmpty) {
      return <Vendor>[];
    }
    return _groupedVendors[_selectedArea] ?? _filteredVendors;
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Positioned.fill(
          child:
              _singleMarker == null
                  ? const Center(child: CircularProgressIndicator())
                  : GoogleMap(
                    initialCameraPosition: const CameraPosition(
                      target: LatLng(-6.3822, 106.8009),
                      zoom: 12.4,
                    ),
                    markers: _markers,
                    myLocationButtonEnabled: false,
                    zoomControlsEnabled: false,
                  ),
        ),
        Positioned(
          top: 12,
          left: 16,
          right: 16,
          child: Column(
            children: <Widget>[
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: const <BoxShadow>[
                    BoxShadow(
                      color: Color(0x18000000),
                      blurRadius: 20,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                child: Row(
                  children: <Widget>[
                    const Icon(Icons.arrow_back_rounded),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        onChanged: (String value) {
                          setState(() {
                            _searchQuery = value;
                            if (_groupedVendors.isNotEmpty &&
                                !_groupedVendors.containsKey(_selectedArea)) {
                              _selectedArea = _groupedVendors.keys.first;
                            }
                          });
                        },
                        decoration: InputDecoration(
                          isDense: true,
                          border: InputBorder.none,
                          hintText: 'Cari area atau toko',
                          prefixIcon: const Icon(Icons.search_rounded),
                          suffixIcon:
                              _searchQuery.isEmpty
                                  ? null
                                  : IconButton(
                                    onPressed: () {
                                      setState(() {
                                        _searchQuery = '';
                                        if (_groupedVendors.isNotEmpty) {
                                          _selectedArea =
                                              _groupedVendors.keys.first;
                                        }
                                      });
                                    },
                                    icon: const Icon(Icons.close_rounded),
                                  ),
                        ),
                      ),
                    ),
                    const Icon(Icons.favorite_border_rounded),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              if (_groupedVendors.isNotEmpty)
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children:
                        _groupedVendors.keys.map((String area) {
                          final bool selected = _selectedArea == area;
                          return Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child: ChoiceChip(
                              label: Text(area),
                              selected: selected,
                              onSelected: (_) {
                                setState(() {
                                  _selectedArea = area;
                                });
                              },
                              backgroundColor: Colors.white,
                              selectedColor: kPrimary,
                              labelStyle: TextStyle(
                                color: selected ? Colors.white : kText,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          );
                        }).toList(),
                  ),
                )
              else
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Text(
                    'Tidak ada area yang cocok dengan pencarian.',
                  ),
                ),
            ],
          ),
        ),
        Positioned(
          left: 16,
          right: 16,
          bottom: 22,
          child: Column(
            children: <Widget>[
              Container(
                width: 126,
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF202124),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Icon(Icons.view_list_rounded, color: Colors.white),
                    SizedBox(width: 8),
                    Text(
                      'List',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: kBorder),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      _selectedArea.isEmpty
                          ? 'Hasil Peta'
                          : 'Area $_selectedArea',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Vendor di area ini',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 12),
                    if (_selectedVendors.isEmpty)
                      Text(
                        'Belum ada vendor yang cocok dengan pencarian.',
                        style: Theme.of(context).textTheme.bodyLarge,
                      )
                    else
                      SizedBox(
                        height: 104,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: _selectedVendors.length,
                          separatorBuilder:
                              (_, __) => const SizedBox(width: 10),
                          itemBuilder: (BuildContext context, int index) {
                            final Vendor vendor = _selectedVendors[index];
                            return SizedBox(
                              width: 220,
                              child: InkWell(
                                onTap: () {
                                  Navigator.of(context).push(
                                    MaterialPageRoute<void>(
                                      builder:
                                          (_) => StoreDetailPage(
                                            vendor: vendor,
                                            allVendors: widget.vendors,
                                            isGuest: widget.isGuest,
                                            onRequireLogin:
                                                widget.onRequireLogin,
                                          ),
                                    ),
                                  );
                                },
                                child: Ink(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFF8FAFC),
                                    borderRadius: BorderRadius.circular(18),
                                  ),
                                  child: Row(
                                    children: <Widget>[
                                      Container(
                                        width: 42,
                                        height: 42,
                                        decoration: BoxDecoration(
                                          color: kPrimarySoft,
                                          borderRadius: BorderRadius.circular(
                                            14,
                                          ),
                                        ),
                                        child: const Icon(
                                          Icons.storefront_rounded,
                                          color: kPrimary,
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: <Widget>[
                                            Text(
                                              vendor.name,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style:
                                                  Theme.of(
                                                    context,
                                                  ).textTheme.titleMedium,
                                            ),
                                            const SizedBox(height: 4),
                                            Text(
                                              vendor.locationLabel,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style:
                                                  Theme.of(
                                                    context,
                                                  ).textTheme.bodyMedium,
                                            ),
                                            const SizedBox(height: 4),
                                            _StoreStatusChip(
                                              isOpen: vendor.isOpen,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class BuyerOrdersPage extends StatefulWidget {
  const BuyerOrdersPage({super.key});

  @override
  State<BuyerOrdersPage> createState() => _BuyerOrdersPageState();
}

class _BuyerOrdersPageState extends State<BuyerOrdersPage> {
  String _selectedContentMode = 'Booking';
  String _selectedOrderFilter = 'Semua';
  String _selectedRequestFilter = 'Semua';

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<OrderRecord>>(
      stream: OrderRepository.watchBuyerOrders(BuyerProfileRepository.buyerId),
      initialData: OrderRepository.localBuyerOrders(
        BuyerProfileRepository.buyerId,
      ),
      builder: (
        BuildContext context,
        AsyncSnapshot<List<OrderRecord>> snapshot,
      ) {
        final List<OrderRecord> orders = snapshot.data ?? <OrderRecord>[];
        final List<OrderRecord> filteredOrders = _filterOrders(
          orders,
          _selectedOrderFilter,
        );
        return ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
          children: <Widget>[
            Text(
              'Booking Saya',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            Text(
              'Lihat booking aktif dan histori pembayaran sewa.',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 18),
            _BuyerOrderSummaryRow(
              totalOrders: orders.length,
              activeOrders: orders.where(_isBuyerActiveOrder).length,
              completedOrders:
                  orders
                      .where((OrderRecord order) => order.status == 'Selesai')
                      .length,
            ),
            const SizedBox(height: 16),
            _SectionFilterChips(
              labels: const <String>['Booking', 'Pertanyaan'],
              selectedLabel: _selectedContentMode,
              onSelected: (String value) {
                setState(() {
                  _selectedContentMode = value;
                });
              },
            ),
            const SizedBox(height: 14),
            if (_selectedContentMode == 'Booking') ...<Widget>[
              _SectionFilterChips(
                labels: const <String>[
                  'Semua',
                  'Diproses',
                  'Dikirim',
                  'Selesai',
                  'Batal',
                ],
                selectedLabel: _selectedOrderFilter,
                onSelected: (String value) {
                  setState(() {
                    _selectedOrderFilter = value;
                  });
                },
              ),
              const SizedBox(height: 14),
              if (orders.isEmpty)
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: kBorder),
                  ),
                  child: Text(
                    'Belum ada booking. Coba pilih properti dari halaman utama dulu ya.',
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                ),
              if (orders.isNotEmpty && filteredOrders.isEmpty)
                _EmptySectionCard(
                  message:
                      'Belum ada booking dengan filter "$_selectedOrderFilter".',
                ),
              ...filteredOrders.map(
                (OrderRecord order) => Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: OrderStatusCard(
                    status: order.status,
                    title: order.vendorName,
                    subtitle:
                        '${order.compactMenuLabel} • ${order.totalUnits} unit',
                    total: formatRupiah(order.totalPrice),
                    schedule: order.scheduleLabel,
                    order: order,
                  ),
                ),
              ),
            ] else ...<Widget>[
              Text(
                'Pertanyaan & Minat Sewa',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 8),
              Text(
                'Pertanyaan kamar, minat survey, dan negosiasi awal akan muncul di sini.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 12),
              StreamBuilder<List<CustomMenuRequest>>(
                stream: CustomMenuRequestRepository.watchBuyerRequests(
                  BuyerProfileRepository.buyerId,
                ),
                initialData: const <CustomMenuRequest>[],
                builder: (
                  BuildContext context,
                  AsyncSnapshot<List<CustomMenuRequest>> requestSnapshot,
                ) {
                  final List<CustomMenuRequest> requests =
                      requestSnapshot.data ?? <CustomMenuRequest>[];
                  final List<CustomMenuRequest> filteredRequests =
                      _filterRequests(requests, _selectedRequestFilter);
                  if (requests.isEmpty) {
                    return Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: kBorder),
                      ),
                      child: Text(
                        'Belum ada pertanyaan properti. Gunakan tombol tanya di halaman detail kos kalau butuh info lebih lanjut.',
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                    );
                  }
                  return Column(
                    children: <Widget>[
                      _SectionFilterChips(
                        labels: const <String>[
                          'Semua',
                          'Masuk',
                          'Diproses',
                          'Dijawab',
                          'Disetujui',
                          'Dibatalkan',
                        ],
                        selectedLabel: _selectedRequestFilter,
                        onSelected: (String value) {
                          setState(() {
                            _selectedRequestFilter = value;
                          });
                        },
                      ),
                      const SizedBox(height: 14),
                      if (filteredRequests.isEmpty)
                        const _EmptySectionCard(
                          message:
                              'Belum ada request custom yang cocok dengan filter ini.',
                        ),
                      ...filteredRequests.map(
                        (CustomMenuRequest request) => Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: BuyerCustomRequestCard(request: request),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ],
          ],
        );
      },
    );
  }

  List<OrderRecord> _filterOrders(List<OrderRecord> orders, String filter) {
    switch (filter) {
      case 'Diproses':
        return orders
            .where((OrderRecord order) => order.status == 'Diproses')
            .toList();
      case 'Dikirim':
        return orders
            .where((OrderRecord order) => order.status == 'Dikirim')
            .toList();
      case 'Selesai':
        return orders
            .where((OrderRecord order) => order.status == 'Selesai')
            .toList();
      case 'Batal':
        return orders
            .where((OrderRecord order) => order.status == 'Dibatalkan')
            .toList();
      default:
        return orders;
    }
  }

  List<CustomMenuRequest> _filterRequests(
    List<CustomMenuRequest> requests,
    String filter,
  ) {
    if (filter == 'Semua') {
      return requests;
    }
    return requests
        .where((CustomMenuRequest request) => request.status == filter)
        .toList();
  }
}

class BuyerCustomRequestCard extends StatelessWidget {
  const BuyerCustomRequestCard({super.key, required this.request});

  final CustomMenuRequest request;

  Future<void> _openQuoteApprovalSheet(BuildContext context) async {
    final int unitPrice = _extractPrice(request.quotedPriceLabel);
    if (unitPrice <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Penawaran harga belum terbaca. Minta seller isi harga dengan nominal yang jelas ya.',
          ),
        ),
      );
      return;
    }
    final OrderRecord? order = await Navigator.of(context).push<OrderRecord>(
      MaterialPageRoute<OrderRecord>(
        builder:
            (_) => _CheckoutScaffold(
              title: 'Checkout request custom',
              child: _CustomRequestApprovalSheet(
                request: request,
                unitPrice: unitPrice,
              ),
            ),
      ),
    );
    if (order == null || !context.mounted) {
      return;
    }
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => _OrderSuccessPage(order: order)),
    );
  }

  Future<void> _cancelRequest(BuildContext context) async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Batalkan request?'),
          content: const Text(
            'Request menu ini akan dibatalkan dan seller akan melihat status pembatalannya.',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Tidak'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Batalkan'),
            ),
          ],
        );
      },
    );
    if (confirmed != true) {
      return;
    }
    await CustomMenuRequestRepository.cancelRequest(requestId: request.id);
    if (!context.mounted) {
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Request berhasil dibatalkan.')),
    );
  }

  Future<void> _openNegotiateAgain(BuildContext context) async {
    final bool? created = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (BuildContext context) {
        return _CustomMenuRequestSheet(
          vendor: sampleVendors.firstWhere(
            (Vendor vendor) => vendor.id == request.vendorId,
            orElse: () => sampleVendors.first,
          ),
          initialTitle: request.title,
          initialDescription: request.description,
          initialBudgetLabel:
              request.quotedPriceLabel.isNotEmpty
                  ? request.quotedPriceLabel
                  : request.budgetLabel,
          initialTargetPax: request.targetPax,
        );
      },
    );
    if (created == true && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Negosiasi baru sudah dikirim ke chat penjual.'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final int quotedPrice = _extractPrice(request.quotedPriceLabel);
    final bool canConvertToOrder =
        request.quotedPriceLabel.isNotEmpty &&
        quotedPrice > 0 &&
        request.status != 'Dibatalkan' &&
        request.status != 'Disetujui';
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  request.vendorName,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: kPrimarySoft,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  request.status,
                  style: const TextStyle(
                    color: kPrimaryDark,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(request.title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 6),
          Text(
            '${request.targetPax} pax • ${request.budgetLabel}',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 8),
          Text(
            request.description,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          if (request.sellerResponse.isNotEmpty ||
              request.quotedPriceLabel.isNotEmpty) ...<Widget>[
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFC),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: kBorder),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'Respon penjual',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  if (request.quotedPriceLabel.isNotEmpty) ...<Widget>[
                    const SizedBox(height: 8),
                    Text(
                      'Penawaran: ${request.quotedPriceLabel}',
                      style: Theme.of(
                        context,
                      ).textTheme.bodyLarge?.copyWith(color: kPrimaryDark),
                    ),
                  ],
                  if (request.sellerResponse.isNotEmpty) ...<Widget>[
                    const SizedBox(height: 8),
                    Text(
                      request.sellerResponse,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ],
              ),
            ),
          ],
          if (canConvertToOrder) ...<Widget>[
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => _openQuoteApprovalSheet(context),
                    icon: const Icon(Icons.receipt_long_rounded),
                    label: const Text('Terima penawaran'),
                    style: FilledButton.styleFrom(
                      backgroundColor: kPrimary,
                      minimumSize: const Size.fromHeight(50),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                OutlinedButton(
                  onPressed: () => _openNegotiateAgain(context),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(0, 50),
                  ),
                  child: const Text('Nego lagi'),
                ),
              ],
            ),
          ],
          if (request.status == 'Dijawab' &&
              request.quotedPriceLabel.isEmpty &&
              request.sellerResponse.isNotEmpty) ...<Widget>[
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () => _openNegotiateAgain(context),
              icon: const Icon(Icons.reply_rounded),
              label: const Text('Lanjutkan negosiasi'),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
            ),
          ],
          if (request.status == 'Masuk' ||
              request.status == 'Diproses') ...<Widget>[
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () => _cancelRequest(context),
              icon: const Icon(Icons.close_rounded),
              label: const Text('Batalkan request'),
            ),
          ],
          const SizedBox(height: 10),
          Text(
            request.createdAtLabel,
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}

class _BuyerNotificationsSheet extends StatefulWidget {
  const _BuyerNotificationsSheet({
    required this.vendors,
    required this.onOpenOrders,
    required this.onOpenChat,
  });

  final List<Vendor> vendors;
  final VoidCallback onOpenOrders;
  final VoidCallback onOpenChat;

  @override
  State<_BuyerNotificationsSheet> createState() =>
      _BuyerNotificationsSheetState();
}

class _BuyerNotificationsSheetState extends State<_BuyerNotificationsSheet> {
  String _selectedNotificationFilter = 'Semua';

  @override
  Widget build(BuildContext context) {
    final List<AppNotificationItem> items = _buildBuyerNotifications(
      widget.vendors,
    );
    final List<AppNotificationItem> filteredItems =
        switch (_selectedNotificationFilter) {
          'Pesanan' =>
            items
                .where(
                  (AppNotificationItem item) =>
                      item.category == AppNotificationCategory.orders,
                )
                .toList(),
          'Chat' =>
            items
                .where(
                  (AppNotificationItem item) =>
                      item.category == AppNotificationCategory.chat,
                )
                .toList(),
          'Request' =>
            items
                .where(
                  (AppNotificationItem item) =>
                      item.category == AppNotificationCategory.request,
                )
                .toList(),
          _ => items,
        };
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('Notifikasi', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            Text(
              'Pantau order, balasan seller, dan chat terbaru di satu tempat.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),
            _SectionFilterChips(
              labels: const <String>['Semua', 'Pesanan', 'Chat', 'Request'],
              selectedLabel: _selectedNotificationFilter,
              onSelected: (String value) {
                setState(() {
                  _selectedNotificationFilter = value;
                });
              },
            ),
            const SizedBox(height: 16),
            if (items.isEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: kBorder),
                ),
                child: Text(
                  'Belum ada notifikasi baru. Aktivitas pesanan dan chat akan muncul di sini.',
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              )
            else
              ...filteredItems.map(
                (AppNotificationItem item) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(22),
                    onTap: () {
                      Navigator.of(context).pop();
                      if (item.route == AppNotificationRoute.chat) {
                        widget.onOpenChat();
                        return;
                      }
                      widget.onOpenOrders();
                    },
                    child: Ink(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: kBorder),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: item.accent.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Icon(item.icon, color: item.accent),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  item.title,
                                  style:
                                      Theme.of(context).textTheme.titleMedium,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  item.message,
                                  style: Theme.of(context).textTheme.bodyMedium,
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  item.timeLabel,
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Icon(
                            Icons.chevron_right_rounded,
                            color: kMuted,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            if (items.isNotEmpty && filteredItems.isEmpty)
              const _EmptySectionCard(
                message: 'Belum ada notifikasi pada kategori ini.',
              ),
          ],
        ),
      ),
    );
  }
}

class _CustomRequestApprovalSheet extends StatefulWidget {
  const _CustomRequestApprovalSheet({
    required this.request,
    required this.unitPrice,
  });

  final CustomMenuRequest request;
  final int unitPrice;

  @override
  State<_CustomRequestApprovalSheet> createState() =>
      _CustomRequestApprovalSheetState();
}

class _CustomRequestApprovalSheetState
    extends State<_CustomRequestApprovalSheet> {
  late BuyerProfileData _buyerProfile = BuyerProfileRepository.current();
  late final TextEditingController _addressController = TextEditingController(
    text: BuyerProfileRepository.current().primaryAddress,
  );
  late final TextEditingController _notesController = TextEditingController(
    text: widget.request.description,
  );
  late int _quantity = widget.request.targetPax;
  bool _isSubmitting = false;
  DateTime _deliveryDate = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _deliveryTime = const TimeOfDay(hour: 11, minute: 30);

  @override
  void initState() {
    super.initState();
    _hydrateBuyerProfile();
  }

  @override
  void dispose() {
    _addressController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _hydrateBuyerProfile() async {
    await BuyerProfileRepository.ensureLoaded();
    final BuyerProfileData profile = BuyerProfileRepository.current();
    if (!mounted) {
      return;
    }
    setState(() {
      _buyerProfile = profile;
      if (_addressController.text ==
          BuyerProfileRepository.fallback.primaryAddress) {
        _addressController.text = profile.primaryAddress;
      }
    });
  }

  String get _scheduleLabel {
    const List<String> monthNames = <String>[
      'Januari',
      'Februari',
      'Maret',
      'April',
      'Mei',
      'Juni',
      'Juli',
      'Agustus',
      'September',
      'Oktober',
      'November',
      'Desember',
    ];
    return '${_deliveryDate.day.toString().padLeft(2, '0')} ${monthNames[_deliveryDate.month - 1]} ${_deliveryDate.year} • ${_deliveryTime.hour.toString().padLeft(2, '0')}:${_deliveryTime.minute.toString().padLeft(2, '0')}';
  }

  Future<void> _pickDate() async {
    final DateTime now = DateTime.now();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _deliveryDate,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: now.add(const Duration(days: 180)),
    );
    if (picked == null) {
      return;
    }
    setState(() {
      _deliveryDate = picked;
    });
  }

  Future<void> _pickTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _deliveryTime,
    );
    if (picked == null) {
      return;
    }
    setState(() {
      _deliveryTime = picked;
    });
  }

  Future<void> _submit() async {
    final String address = _addressController.text.trim();
    if (address.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Isi alamat pengantaran dulu ya.')),
      );
      return;
    }

    final int totalPrice = widget.unitPrice * _quantity;
    final int downPayment = _calculateDownPayment(totalPrice);
    setState(() {
      _isSubmitting = true;
    });

    final bool paymentConfirmed = await _showMockQrisPaymentPage(
      context,
      vendorName: widget.request.vendorName,
      menuName: widget.request.title,
      scheduleLabel: _scheduleLabel,
      totalPrice: downPayment,
      paymentStage: 'Bayar DP 50%',
    );
    if (!mounted) {
      return;
    }
    if (!paymentConfirmed) {
      setState(() {
        _isSubmitting = false;
      });
      return;
    }

    final OrderRecord order = await OrderRepository.placeCustomOrder(
      vendorId: widget.request.vendorId,
      vendorName: widget.request.vendorName,
      menuName: widget.request.title,
      unitPrice: widget.unitPrice,
      quantity: _quantity,
      scheduleLabel: _scheduleLabel,
      deliveryAddress: address,
      buyerId: BuyerProfileRepository.buyerId,
      buyerName: _buyerProfile.name,
      amountPaid: downPayment,
      paymentMethodLabel: 'QRIS',
      paymentStatus: 'DP 50%',
      notes: _notesController.text.trim(),
    );
    if (!mounted) {
      return;
    }
    unawaited(
      Future.wait<void>(<Future<void>>[
        CustomMenuRequestRepository.updateStatus(
          requestId: widget.request.id,
          status: 'Disetujui',
        ),
        ChatRepository.sendMessage(
          vendorId: widget.request.vendorId,
          text:
              'Saya setuju dengan penawaran ${widget.request.title}. Tolong proses pesanan untuk $_quantity pax ya.',
          senderId: BuyerProfileRepository.buyerId,
          senderLabel: _buyerProfile.name,
        ),
      ]),
    );
    Navigator.of(context).pop(order);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        20,
        20,
        MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: ListView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        children: <Widget>[
          Text(
            'Setujui penawaran seller',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          Text(
            widget.request.vendorName,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kBorder),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _InvoiceRow(label: 'Request', value: widget.request.title),
                const SizedBox(height: 8),
                _InvoiceRow(
                  label: 'Penawaran seller',
                  value: widget.request.quotedPriceLabel,
                ),
                const SizedBox(height: 8),
                _InvoiceRow(
                  label: 'Harga satuan terbaca',
                  value: formatRupiah(widget.unitPrice),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: <Widget>[
              const Text('Jumlah pax'),
              const Spacer(),
              IconButton(
                onPressed:
                    _quantity > 1
                        ? () {
                          setState(() {
                            _quantity -= 1;
                          });
                        }
                        : null,
                icon: const Icon(Icons.remove_circle_outline_rounded),
              ),
              Text(
                '$_quantity',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              IconButton(
                onPressed: () {
                  setState(() {
                    _quantity += 1;
                  });
                },
                icon: const Icon(Icons.add_circle_outline_rounded),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: <Widget>[
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _pickDate,
                  icon: const Icon(Icons.calendar_today_rounded),
                  label: Text(
                    '${_deliveryDate.day.toString().padLeft(2, '0')}/${_deliveryDate.month.toString().padLeft(2, '0')}/${_deliveryDate.year}',
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _pickTime,
                  icon: const Icon(Icons.access_time_rounded),
                  label: Text(
                    '${_deliveryTime.hour.toString().padLeft(2, '0')}:${_deliveryTime.minute.toString().padLeft(2, '0')}',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _addressController,
            minLines: 2,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Alamat pengantaran',
              hintText: 'Masukkan alamat lengkap tujuan pesanan',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _notesController,
            minLines: 2,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Catatan final pesanan',
              hintText:
                  'Bisa revisi sedikit detail menu atau instruksi pengiriman',
            ),
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kBorder),
            ),
            child: Row(
              children: <Widget>[
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: kPrimarySoft,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(
                    Icons.qr_code_2_rounded,
                    color: kPrimaryDark,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Pembayaran QRIS',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Buyer akan bayar DP 50% dulu. Sisa pembayaran bisa dilunasi nanti dari halaman pesanan.',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const _CancellationPolicyCard(
            title: 'Kebijakan DP & pembatalan',
            lines: <String>[
              'Pesanan dikunci setelah DP 50% berhasil dibayar.',
              'DP yang sudah dibayar tidak dapat dikembalikan jika pesanan dibatalkan.',
              'Sisa pembayaran bisa dilunasi nanti dari halaman pesanan.',
            ],
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kBorder),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _InvoiceRow(label: 'Jadwal kirim', value: _scheduleLabel),
                const SizedBox(height: 8),
                _InvoiceRow(
                  label: 'DP 50%',
                  value: formatRupiah(
                    _calculateDownPayment(widget.unitPrice * _quantity),
                  ),
                ),
                const SizedBox(height: 8),
                _InvoiceRow(
                  label: 'Sisa pelunasan',
                  value: formatRupiah(
                    (widget.unitPrice * _quantity) -
                        _calculateDownPayment(widget.unitPrice * _quantity),
                  ),
                ),
                const SizedBox(height: 8),
                _InvoiceRow(label: 'Metode bayar', value: 'QRIS'),
                const SizedBox(height: 8),
                _InvoiceRow(
                  label: 'Status bayar',
                  value: 'DP dibayar, sisa dilunasi nanti',
                ),
                const SizedBox(height: 8),
                _InvoiceRow(
                  label: 'Total invoice',
                  value: formatRupiah(widget.unitPrice * _quantity),
                  emphasized: true,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _isSubmitting ? null : _submit,
            icon:
                _isSubmitting
                    ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                    : const Icon(Icons.check_circle_outline_rounded),
            label: Text(
              _isSubmitting ? 'Memproses...' : 'Lanjut ke pembayaran',
            ),
            style: FilledButton.styleFrom(
              backgroundColor: kPrimary,
              minimumSize: const Size.fromHeight(52),
            ),
          ),
        ],
      ),
    );
  }
}

class BuyerChatListPage extends StatelessWidget {
  const BuyerChatListPage({super.key, required this.vendors});

  final List<Vendor> vendors;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
      children: <Widget>[
        Text('Chat Penjual', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 8),
        Text(
          'Gunakan chat untuk request menu paket atau tanya detail pesanan.',
          style: Theme.of(context).textTheme.bodyLarge,
        ),
        const SizedBox(height: 18),
        ...vendors
            .take(3)
            .map(
              (Vendor vendor) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: ChatListTile(vendor: vendor),
              ),
            ),
      ],
    );
  }
}

class BuyerProfilePage extends StatefulWidget {
  const BuyerProfilePage({
    super.key,
    required this.vendors,
    required this.onSwitchMode,
    required this.onLogout,
    required this.onOpenOrders,
    required this.onOpenChat,
    required this.statusMessage,
    required this.isCloudReady,
  });

  final List<Vendor> vendors;
  final VoidCallback onSwitchMode;
  final VoidCallback onLogout;
  final VoidCallback onOpenOrders;
  final VoidCallback onOpenChat;
  final String statusMessage;
  final bool isCloudReady;

  @override
  State<BuyerProfilePage> createState() => _BuyerProfilePageState();
}

class _BuyerProfilePageState extends State<BuyerProfilePage> {
  Set<String> _favoriteVendorIds = <String>{};
  final ScrollController _scrollController = ScrollController();
  BuyerProfileData _profile = BuyerProfileRepository.fallback;
  bool _isLoadingProfile = true;

  @override
  void initState() {
    super.initState();
    BuyerProfileRepository.updates.addListener(_loadProfile);
    _loadFavorites();
    _loadProfile();
  }

  @override
  void dispose() {
    BuyerProfileRepository.updates.removeListener(_loadProfile);
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadFavorites() async {
    final Set<String> favorites = await FavoriteRepository.loadFavorites();
    if (!mounted) {
      return;
    }
    setState(() {
      _favoriteVendorIds = favorites;
    });
  }

  Future<void> _loadProfile() async {
    await BuyerProfileRepository.ensureLoaded();
    if (!mounted) {
      return;
    }
    setState(() {
      _profile = BuyerProfileRepository.current();
      _isLoadingProfile = false;
    });
  }

  void _scrollToFavorites() {
    if (!_scrollController.hasClients) {
      return;
    }
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 450),
      curve: Curves.easeOutCubic,
    );
  }

  Future<void> _openEditProfileSheet() async {
    final BuyerProfileData? updated =
        await showModalBottomSheet<BuyerProfileData>(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.white,
          builder: (BuildContext context) {
            return _BuyerProfileSheet(initialProfile: _profile);
          },
        );
    if (updated == null) {
      return;
    }
    await BuyerProfileRepository.save(updated);
  }

  Future<void> _openHelpSheet() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      builder: (BuildContext context) {
        return const _BuyerHelpSheet();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<Vendor> favoriteVendors =
        widget.vendors
            .where((Vendor vendor) => _favoriteVendorIds.contains(vendor.id))
            .toList();

    return ListView(
      controller: _scrollController,
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
      children: <Widget>[
        Text(
          'Profil Pembeli',
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        if (kShowInternalStatusBanners) ...<Widget>[
          const SizedBox(height: 18),
          DemoModeBanner(
            title: widget.isCloudReady ? 'Akun Terhubung' : 'Akun Demo',
            message:
                widget.isCloudReady
                    ? widget.statusMessage
                    : 'Data favorit, order, chat, dan vendor favorit akan tetap terasa hidup meski belum login produksi penuh.',
          ),
        ],
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kBorder),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  CircleAvatar(
                    radius: 28,
                    backgroundColor: kPrimarySoft,
                    child: Text(
                      _profile.name.characters.take(1).toString().toUpperCase(),
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: kPrimary,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          _profile.name,
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        Text(
                          _profile.email,
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _profile.phone,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              if (_isLoadingProfile)
                const Padding(
                  padding: EdgeInsets.only(bottom: 16),
                  child: LinearProgressIndicator(minHeight: 3),
                ),
              Row(
                children: <Widget>[
                  Expanded(
                    child: _ProfileStatCard(
                      label: 'Favorit',
                      value: '${favoriteVendors.length}',
                      onTap: _scrollToFavorites,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ValueListenableBuilder<int>(
                      valueListenable: OrderRepository.updates,
                      builder: (BuildContext context, _, __) {
                        return _ProfileStatCard(
                          label: 'Order',
                          value:
                              '${OrderRepository.localBuyerOrderCount(BuyerProfileRepository.buyerId)}',
                          onTap: widget.onOpenOrders,
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ValueListenableBuilder<int>(
                      valueListenable: ChatRepository.updates,
                      builder: (BuildContext context, _, __) {
                        return _ProfileStatCard(
                          label: 'Chat',
                          value:
                              '${ChatRepository.localUnreadCount(currentSenderId: BuyerProfileRepository.buyerId, vendorIds: widget.vendors.map((Vendor vendor) => vendor.id).toList())}',
                          onTap: widget.onOpenChat,
                        );
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _openEditProfileSheet,
                icon: const Icon(Icons.edit_rounded),
                label: const Text('Ubah profil pembeli'),
                style: FilledButton.styleFrom(
                  backgroundColor: kPrimary,
                  padding: const EdgeInsets.symmetric(
                    vertical: 14,
                    horizontal: 18,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: _openHelpSheet,
                icon: const Icon(Icons.support_agent_rounded),
                label: const Text('Pusat bantuan'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    vertical: 14,
                    horizontal: 18,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: widget.onLogout,
                icon: const Icon(Icons.logout_rounded),
                label: const Text('Keluar'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    vertical: 14,
                    horizontal: 18,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kBorder),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Data Pengantaran',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 8),
              Text(
                'Alamat dan preferensi ini akan dipakai sebagai default saat membuat pesanan.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 14),
              _InvoiceRow(
                label: 'Alamat utama',
                value: _profile.primaryAddress,
              ),
              const SizedBox(height: 10),
              _InvoiceRow(
                label: 'Alamat cadangan',
                value:
                    _profile.secondaryAddress.isEmpty
                        ? 'Belum ditambahkan'
                        : _profile.secondaryAddress,
              ),
              const SizedBox(height: 10),
              _InvoiceRow(
                label: 'Preferensi pesanan',
                value: _profile.preferenceSummary,
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kBorder),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Toko Favorit',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 8),
              Text(
                'Toko yang kamu tandai favorit akan muncul di sini.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 14),
              if (favoriteVendors.isEmpty)
                Text(
                  'Belum ada toko favorit. Coba tandai dari halaman detail toko ya.',
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ...favoriteVendors.map(
                (Vendor vendor) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: BuyerVendorListCard(
                    vendor: vendor,
                    allVendors: widget.vendors,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _BuyerProfileSheet extends StatefulWidget {
  const _BuyerProfileSheet({required this.initialProfile});

  final BuyerProfileData initialProfile;

  @override
  State<_BuyerProfileSheet> createState() => _BuyerProfileSheetState();
}

class _BuyerProfileSheetState extends State<_BuyerProfileSheet> {
  late final TextEditingController _nameController = TextEditingController(
    text: widget.initialProfile.name,
  );
  late final TextEditingController _emailController = TextEditingController(
    text: widget.initialProfile.email,
  );
  late final TextEditingController _phoneController = TextEditingController(
    text: widget.initialProfile.phone,
  );
  late final TextEditingController _primaryAddressController =
      TextEditingController(text: widget.initialProfile.primaryAddress);
  late final TextEditingController _secondaryAddressController =
      TextEditingController(text: widget.initialProfile.secondaryAddress);
  late final TextEditingController _preferenceController =
      TextEditingController(text: widget.initialProfile.preferenceSummary);

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _primaryAddressController.dispose();
    _secondaryAddressController.dispose();
    _preferenceController.dispose();
    super.dispose();
  }

  void _submit() {
    if (_nameController.text.trim().isEmpty ||
        _phoneController.text.trim().isEmpty ||
        _primaryAddressController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Nama, nomor HP, dan alamat utama perlu diisi dulu ya.',
          ),
        ),
      );
      return;
    }
    Navigator.of(context).pop(
      BuyerProfileData(
        name: _nameController.text.trim(),
        email:
            _emailController.text.trim().isEmpty
                ? BuyerProfileRepository.fallback.email
                : _emailController.text.trim(),
        phone: _phoneController.text.trim(),
        primaryAddress: _primaryAddressController.text.trim(),
        secondaryAddress: _secondaryAddressController.text.trim(),
        preferenceSummary:
            _preferenceController.text.trim().isEmpty
                ? BuyerProfileRepository.fallback.preferenceSummary
                : _preferenceController.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        20,
        20,
        MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Ubah profil pembeli',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              'Data ini akan dipakai untuk profil, order, dan alamat pengantaran default.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 18),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Nama lengkap'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _emailController,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Nomor HP / WhatsApp',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _primaryAddressController,
              minLines: 2,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'Alamat utama'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _secondaryAddressController,
              minLines: 2,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Alamat cadangan',
                hintText: 'Opsional, misalnya kantor atau kampus',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _preferenceController,
              minLines: 2,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'Preferensi pesanan',
                hintText: 'Contoh: tidak terlalu pedas, lebih suka air mineral',
              ),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: _submit,
              icon: const Icon(Icons.save_rounded),
              label: const Text('Simpan profil'),
              style: FilledButton.styleFrom(
                backgroundColor: kPrimary,
                minimumSize: const Size.fromHeight(52),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BuyerHelpSheet extends StatelessWidget {
  const _BuyerHelpSheet();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Pusat bantuan', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text(
            'Kalau ada kendala order, pembayaran, atau request menu custom, kamu bisa hubungi customer service.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 18),
          _HelpActionTile(
            icon: Icons.phone_in_talk_rounded,
            title: 'WhatsApp CS',
            subtitle: '0812-9000-ASKIA',
            onTap: () async {
              await Clipboard.setData(
                const ClipboardData(text: '0812-9000-ASKIA'),
              );
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Nomor WhatsApp CS berhasil disalin.'),
                  ),
                );
              }
            },
          ),
          const SizedBox(height: 10),
          _HelpActionTile(
            icon: Icons.mail_outline_rounded,
            title: 'Email bantuan',
            subtitle: 'cs@askiacatering.app',
            onTap: () async {
              await Clipboard.setData(
                const ClipboardData(text: 'cs@askiacatering.app'),
              );
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Email bantuan berhasil disalin.'),
                  ),
                );
              }
            },
          ),
        ],
      ),
    );
  }
}

class _HelpActionTile extends StatelessWidget {
  const _HelpActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Ink(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFF8FAFC),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: kBorder),
        ),
        child: Row(
          children: <Widget>[
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: kPrimarySoft,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: kPrimaryDark),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 4),
                  Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
            const Icon(Icons.copy_rounded, color: kMuted),
          ],
        ),
      ),
    );
  }
}

class _ProfileStatCard extends StatelessWidget {
  const _ProfileStatCard({
    required this.label,
    required this.value,
    this.onTap,
  });

  final String label;
  final String value;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Ink(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFF8FAFC),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              value,
              style: Theme.of(
                context,
              ).textTheme.titleLarge?.copyWith(color: kPrimaryDark),
            ),
            const SizedBox(height: 4),
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    label,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
                const Icon(
                  Icons.chevron_right_rounded,
                  size: 18,
                  color: kMuted,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _BuyerOrderSummaryRow extends StatelessWidget {
  const _BuyerOrderSummaryRow({
    required this.totalOrders,
    required this.activeOrders,
    required this.completedOrders,
  });

  final int totalOrders;
  final int activeOrders;
  final int completedOrders;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(
          child: _SummaryMetricCard(
            label: 'Total',
            value: '$totalOrders',
            accent: const Color(0xFF0F766E),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _SummaryMetricCard(
            label: 'Aktif',
            value: '$activeOrders',
            accent: const Color(0xFFB45309),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _SummaryMetricCard(
            label: 'Selesai',
            value: '$completedOrders',
            accent: const Color(0xFF166534),
          ),
        ),
      ],
    );
  }
}

class _SummaryMetricCard extends StatelessWidget {
  const _SummaryMetricCard({
    required this.label,
    required this.value,
    required this.accent,
  });

  final String label;
  final String value;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            value,
            style: Theme.of(
              context,
            ).textTheme.titleLarge?.copyWith(color: accent),
          ),
          const SizedBox(height: 4),
          Text(label, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

class _SectionFilterChips extends StatelessWidget {
  const _SectionFilterChips({
    required this.labels,
    required this.selectedLabel,
    required this.onSelected,
  });

  final List<String> labels;
  final String selectedLabel;
  final ValueChanged<String> onSelected;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children:
            labels.map((String label) {
              final bool selected = label == selectedLabel;
              return Padding(
                padding: const EdgeInsets.only(right: 10),
                child: ChoiceChip(
                  label: Text(label),
                  selected: selected,
                  onSelected: (_) => onSelected(label),
                  backgroundColor: Colors.white,
                  selectedColor: kPrimary,
                  labelStyle: TextStyle(
                    color: selected ? Colors.white : kText,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              );
            }).toList(),
      ),
    );
  }
}

class _EmptySectionCard extends StatelessWidget {
  const _EmptySectionCard({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: kBorder),
      ),
      child: Text(message, style: Theme.of(context).textTheme.bodyLarge),
    );
  }
}

class StoreDetailPage extends StatefulWidget {
  const StoreDetailPage({
    super.key,
    required this.vendor,
    required this.allVendors,
    this.isGuest = false,
    this.onRequireLogin,
  });

  final Vendor vendor;
  final List<Vendor> allVendors;
  final bool isGuest;
  final Future<void> Function(BuildContext context, {AppMode? preferredMode})?
  onRequireLogin;

  @override
  State<StoreDetailPage> createState() => _StoreDetailPageState();
}

class _CheckoutDraftItem {
  const _CheckoutDraftItem({required this.item, required this.quantity});

  final MenuItemData item;
  final int quantity;

  int get subtotal => item.price * quantity;
}

class _StoreDetailPageState extends State<StoreDetailPage>
    with TickerProviderStateMixin {
  final SellerMenuController _sellerMenuController =
      SellerMenuController.instance;
  List<SellerMenuEntry> _cloudMenuEntries = const <SellerMenuEntry>[];
  List<StoreMedia> _gallery = const <StoreMedia>[];
  Set<String> _favoriteVendorIds = <String>{};
  String _activeCategory = 'Paket';
  String _searchQuery = '';
  final Map<String, _CheckoutDraftItem> _checkoutDraft =
      <String, _CheckoutDraftItem>{};

  @override
  void initState() {
    super.initState();
    _loadSellerEntries();
    _loadCloudMenus();
    _loadGallery();
    _loadFavorites();
    VendorMediaRepository.updates.addListener(_handleMediaUpdates);
  }

  @override
  void dispose() {
    VendorMediaRepository.updates.removeListener(_handleMediaUpdates);
    super.dispose();
  }

  Future<void> _loadSellerEntries() async {
    await _sellerMenuController.ensureLoaded();
    if (!mounted) {
      return;
    }
    setState(() {});
  }

  Future<void> _loadCloudMenus() async {
    final List<SellerMenuEntry> entries =
        await VendorMenuCloudRepository.fetchVendorMenus(widget.vendor.id);
    if (!mounted || entries.isEmpty) {
      return;
    }
    setState(() {
      _cloudMenuEntries = entries;
    });
  }

  Future<void> _loadGallery() async {
    final List<StoreMedia> gallery =
        await VendorMediaRepository.galleryForVendor(
          widget.vendor.id,
          widget.vendor.gallery,
        );
    if (!mounted) {
      return;
    }
    setState(() {
      _gallery = gallery;
    });
  }

  void _handleMediaUpdates() {
    _loadGallery();
  }

  Future<void> _loadFavorites() async {
    final Set<String> favorites = await FavoriteRepository.loadFavorites();
    if (!mounted) {
      return;
    }
    setState(() {
      _favoriteVendorIds = favorites;
    });
  }

  Future<void> _toggleFavorite() async {
    if (widget.isGuest) {
      await _requestLogin();
      return;
    }
    final Set<String> favorites = await FavoriteRepository.toggleFavorite(
      widget.vendor.id,
    );
    if (!mounted) {
      return;
    }
    setState(() {
      _favoriteVendorIds = favorites;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          favorites.contains(widget.vendor.id)
              ? 'Properti ditambahkan ke favorit.'
              : 'Properti dihapus dari favorit.',
        ),
      ),
    );
  }

  Future<void> _shareStore() async {
    final String text =
        'Cek ${widget.vendor.name} di Askia Kost. Lokasi: ${widget.vendor.locationLabel}. Rating: ${widget.vendor.rating}.';
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) {
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Info properti disalin. Tinggal paste ke chat atau media sosial.',
        ),
      ),
    );
  }

  Future<void> _requestLogin() async {
    if (widget.onRequireLogin != null) {
      await widget.onRequireLogin!(context, preferredMode: AppMode.buyer);
      return;
    }
    if (!mounted) {
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Masuk dulu untuk melanjutkan fitur ini.')),
    );
  }

  List<MenuItemData> get _sellerSyncedItems {
    final List<SellerMenuEntry> sourceEntries =
        _cloudMenuEntries.isNotEmpty
            ? _cloudMenuEntries
            : _sellerMenuController.entriesForVendor(widget.vendor.id);
    final Iterable<SellerMenuEntry> matchingEntries = sourceEntries.where((
      SellerMenuEntry entry,
    ) {
      if (_activeCategory == 'Paket') {
        return entry.type == SellerEntryType.paket || entry.category == 'Paket';
      }
      return entry.category == _activeCategory;
    });

    return matchingEntries
        .map(
          (SellerMenuEntry entry) => MenuItemData(
            name: entry.name,
            price: entry.price,
            description:
                entry.type == SellerEntryType.paket
                    ? 'Tipe kamar racikan pengelola dengan detail ${entry.items.join(', ')}.'
                    : 'Item tambahan dari pengelola Askia Kost.',
            components: entry.items,
          ),
        )
        .toList();
  }

  List<MenuItemData> get _activeItems {
    final List<MenuItemData> baseItems = switch (_activeCategory) {
      'Paket' => widget.vendor.packages,
      'Makanan' => widget.vendor.foods,
      'Minuman' => widget.vendor.drinks,
      _ => widget.vendor.others,
    };
    final List<MenuItemData> items = <MenuItemData>[
      ..._sellerSyncedItems,
      ...baseItems,
    ];
    return items
        .where(
          (MenuItemData item) =>
              _searchQuery.isEmpty ||
              item.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
              item.description.toLowerCase().contains(
                _searchQuery.toLowerCase(),
              ),
        )
        .toList();
  }

  bool get _isFavorite => _favoriteVendorIds.contains(widget.vendor.id);
  List<StoreMedia> get _resolvedGallery =>
      _gallery.isNotEmpty ? _gallery : widget.vendor.gallery;
  List<_CheckoutDraftItem> get _checkoutItems =>
      _checkoutDraft.values.toList(growable: false);
  int get _checkoutItemKinds => _checkoutDraft.length;
  int get _checkoutUnits => _checkoutItems.fold<int>(
    0,
    (int sum, _CheckoutDraftItem entry) => sum + entry.quantity,
  );
  int get _checkoutTotal => _checkoutItems.fold<int>(
    0,
    (int sum, _CheckoutDraftItem entry) => sum + entry.subtotal,
  );
  List<Vendor> get _brandProperties => widget.allVendors
      .where((Vendor candidate) => candidate.brandId == widget.vendor.brandId)
      .toList(growable: false);

  Future<void> _addItemToCheckout(MenuItemData item) async {
    if (widget.isGuest) {
      await _requestLogin();
      return;
    }
    if (!widget.vendor.isOpen) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Properti sedang nonaktif. Coba chat pengelola dulu ya.',
          ),
        ),
      );
      return;
    }
    setState(() {
      final _CheckoutDraftItem? current = _checkoutDraft[item.name];
      _checkoutDraft[item.name] = _CheckoutDraftItem(
        item: item,
        quantity: (current?.quantity ?? 0) + 1,
      );
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${item.name} ditambahkan ke booking sementara.'),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  Future<void> _openCheckoutSheet() async {
    if (_checkoutItems.isEmpty) {
      return;
    }
    final OrderRecord? order = await showModalBottomSheet<OrderRecord>(
      context: context,
      isScrollControlled: true,
      isDismissible: false,
      enableDrag: false,
      backgroundColor: Colors.transparent,
      builder:
          (BuildContext context) => FractionallySizedBox(
            heightFactor: 0.78,
            child: _CartCheckoutSheet(
              vendor: widget.vendor,
              initialItems: _checkoutItems,
            ),
          ),
    );
    if (order == null || !mounted) {
      return;
    }
    setState(() {
      _checkoutDraft.clear();
    });
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => _OrderSuccessPage(order: order)),
    );
  }

  Future<void> _openBrandProperty(Vendor vendor) async {
    if (vendor.id == widget.vendor.id) {
      return;
    }
    await Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(
        builder:
            (_) => StoreDetailPage(
              vendor: vendor,
              allVendors: widget.allVendors,
              isGuest: widget.isGuest,
              onRequireLogin: widget.onRequireLogin,
            ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _sellerMenuController,
      builder: (BuildContext context, _) {
        return Scaffold(
          backgroundColor: kBackground,
          bottomNavigationBar:
              _checkoutDraft.isEmpty
                  ? null
                  : SafeArea(
                    top: false,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: kBorder),
                          boxShadow: const <BoxShadow>[
                            BoxShadow(
                              color: Color(0x120F172A),
                              blurRadius: 18,
                              offset: Offset(0, 8),
                            ),
                          ],
                        ),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Text(
                                    'Booking unit',
                                    style:
                                        Theme.of(context).textTheme.titleMedium,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    '$_checkoutItemKinds pilihan • $_checkoutUnits unit',
                                    style:
                                        Theme.of(context).textTheme.bodySmall,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                Text(
                                  formatRupiah(_checkoutTotal),
                                  style: Theme.of(context).textTheme.titleMedium
                                      ?.copyWith(color: kPrimaryDark),
                                ),
                                const SizedBox(height: 8),
                                FilledButton(
                                  onPressed: _openCheckoutSheet,
                                  style: FilledButton.styleFrom(
                                    backgroundColor: kPrimary,
                                  ),
                                  child: const Text('Buka checkout'),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
          body: NestedScrollView(
            headerSliverBuilder: (
              BuildContext context,
              bool innerBoxIsScrolled,
            ) {
              return <Widget>[
                SliverAppBar(
                  backgroundColor:
                      innerBoxIsScrolled ? Colors.white : Colors.transparent,
                  surfaceTintColor: Colors.transparent,
                  elevation: 0,
                  scrolledUnderElevation: 0.5,
                  pinned: true,
                  expandedHeight: 316,
                  title: innerBoxIsScrolled ? Text(widget.vendor.name) : null,
                  leading: Padding(
                    padding: const EdgeInsets.only(left: 12),
                    child: _FloatingHeaderButton(
                      onTap: () => Navigator.of(context).maybePop(),
                      icon: Icons.arrow_back_rounded,
                      solidBackground: !innerBoxIsScrolled,
                    ),
                  ),
                  leadingWidth: 60,
                  actions: <Widget>[
                    _FloatingHeaderButton(
                      onTap: _toggleFavorite,
                      icon:
                          _isFavorite
                              ? Icons.favorite_rounded
                              : Icons.favorite_border_rounded,
                      iconColor: _isFavorite ? Colors.redAccent : null,
                      solidBackground: !innerBoxIsScrolled,
                    ),
                    const SizedBox(width: 6),
                    Padding(
                      padding: const EdgeInsets.only(right: 12),
                      child: _FloatingHeaderButton(
                        onTap: _shareStore,
                        icon: Icons.share_outlined,
                        solidBackground: !innerBoxIsScrolled,
                      ),
                    ),
                  ],
                  flexibleSpace: FlexibleSpaceBar(
                    background: StoreGallery(gallery: _resolvedGallery),
                  ),
                ),
              ];
            },
            body: ListView(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
              children: <Widget>[
                const SizedBox(height: 16),
                Transform.translate(
                  offset: Offset.zero,
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 22),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: kBorder),
                      boxShadow: const <BoxShadow>[
                        BoxShadow(
                          color: Color(0x120F172A),
                          blurRadius: 24,
                          offset: Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    widget.vendor.name,
                                    style:
                                        Theme.of(
                                          context,
                                        ).textTheme.headlineSmall,
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    widget.vendor.description,
                                    style:
                                        Theme.of(context).textTheme.bodyLarge,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            _StoreStatusChip(isOpen: widget.vendor.isOpen),
                          ],
                        ),
                        const SizedBox(height: 14),
                        Wrap(
                          spacing: 10,
                          runSpacing: 10,
                          children: <Widget>[
                            _StoreMetaPill(
                              icon: Icons.star_rounded,
                              label:
                                  '${widget.vendor.rating} (${widget.vendor.reviewCount})',
                              iconColor: Colors.amber.shade700,
                            ),
                            _StoreMetaPill(
                              icon: Icons.place_rounded,
                              label: widget.vendor.locationLabel,
                            ),
                            _StoreMetaPill(
                              icon: Icons.shopping_bag_outlined,
                              label: widget.vendor.minimumOrderLabel,
                            ),
                            if (_brandProperties.length > 1)
                              _StoreMetaPill(
                                icon: Icons.apartment_rounded,
                                label: '${_brandProperties.length} lokasi',
                              ),
                          ],
                        ),
                        if (_brandProperties.length > 1) ...<Widget>[
                          const SizedBox(height: 14),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF8FAFC),
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(color: kBorder),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  'Cabang lain dari ${widget.vendor.brandName}',
                                  style:
                                      Theme.of(context).textTheme.titleMedium,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Pilih lokasi lain kalau kamu ingin membandingkan area dan harga sewa dari brand yang sama.',
                                  style: Theme.of(context).textTheme.bodyMedium,
                                ),
                                const SizedBox(height: 12),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children:
                                      _brandProperties.map((Vendor property) {
                                        final bool isCurrent =
                                            property.id == widget.vendor.id;
                                        return ChoiceChip(
                                          label: Text(property.areaGroup),
                                          selected: isCurrent,
                                          onSelected:
                                              isCurrent
                                                  ? null
                                                  : (_) => _openBrandProperty(
                                                    property,
                                                  ),
                                        );
                                      }).toList(),
                                ),
                              ],
                            ),
                          ),
                        ],
                        if (!widget.vendor.isOpen) ...<Widget>[
                          const SizedBox(height: 14),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFF7ED),
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(
                                color: const Color(0xFFF59E0B),
                              ),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                const Icon(
                                  Icons.store_mall_directory_outlined,
                                  color: Color(0xFF9A3412),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    'Properti sedang nonaktif. Detail dan chat tetap bisa dibuka, tapi booking sementara belum tersedia.',
                                    style: Theme.of(
                                      context,
                                    ).textTheme.bodyMedium?.copyWith(
                                      color: const Color(0xFF9A3412),
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                        const SizedBox(height: 18),
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: _StoreActionButton(
                                icon: Icons.chat_bubble_rounded,
                                title: 'Chat Pengelola',
                                subtitle: 'Tanya kamar dan ketersediaan',
                                filled: true,
                                onTap: () async {
                                  if (widget.isGuest) {
                                    await _requestLogin();
                                    return;
                                  }
                                  if (!context.mounted) {
                                    return;
                                  }
                                  Navigator.of(context).push(
                                    MaterialPageRoute<void>(
                                      builder:
                                          (_) => ChatRoomPage(
                                            vendor: widget.vendor,
                                          ),
                                    ),
                                  );
                                },
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: _StoreActionButton(
                                icon: Icons.edit_note_rounded,
                                title: 'Tanya Kamar',
                                subtitle: 'Survey & ketersediaan',
                                enabled: widget.vendor.isOpen,
                                onTap: () async {
                                  if (widget.isGuest) {
                                    await _requestLogin();
                                    return;
                                  }
                                  if (!context.mounted) {
                                    return;
                                  }
                                  Navigator.of(context).push(
                                    MaterialPageRoute<void>(
                                      builder:
                                          (_) => ChatRoomPage(
                                            vendor: widget.vendor,
                                            openRequestComposerOnStart: true,
                                          ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        InkWell(
                          borderRadius: BorderRadius.circular(18),
                          onTap: () async {
                            if (widget.isGuest) {
                              await _requestLogin();
                              return;
                            }
                            if (!context.mounted) {
                              return;
                            }
                            Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                builder:
                                    (_) => ChatRoomPage(vendor: widget.vendor),
                              ),
                            );
                          },
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF5FBF7),
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(
                                color: const Color(0xFFD5ECDC),
                              ),
                            ),
                            child: Text(
                              widget.vendor.chatHint,
                              style: Theme.of(
                                context,
                              ).textTheme.bodyMedium?.copyWith(
                                color: kPrimaryDark,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                Transform.translate(
                  offset: Offset.zero,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const _StoreSectionHeader(
                        title: 'Info Properti',
                        subtitle: 'Ringkas dan mudah dicek',
                      ),
                      const SizedBox(height: 12),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: kBorder),
                        ),
                        child: Column(
                          children: <Widget>[
                            _StoreInfoTile(
                              icon: Icons.phone_in_talk_rounded,
                              title: 'Kontak pengelola',
                              value: widget.vendor.contactLabel,
                            ),
                            const Divider(height: 24, color: kBorder),
                            _StoreInfoTile(
                              icon: Icons.map_outlined,
                              title: 'Area layanan',
                              value: widget.vendor.serviceAreaSummary,
                            ),
                            const Divider(height: 24, color: kBorder),
                            _StoreInfoTile(
                              icon: Icons.location_on_outlined,
                              title: 'Alamat properti',
                              value: widget.vendor.addressDetail,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      _StoreSectionHeader(
                        title: 'Kamar & Fasilitas',
                        subtitle:
                            '${_activeItems.length} pilihan di properti ini',
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        onChanged: (String value) {
                          setState(() {
                            _searchQuery = value;
                          });
                        },
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search_rounded),
                          hintText: 'Cari kamar di properti ini',
                        ),
                      ),
                      const SizedBox(height: 14),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children:
                              <String>[
                                'Paket',
                                'Makanan',
                                'Minuman',
                                'Lainnya',
                              ].map((String category) {
                                final bool selected =
                                    _activeCategory == category;
                                return Padding(
                                  padding: const EdgeInsets.only(right: 10),
                                  child: ChoiceChip(
                                    label: Text(category),
                                    selected: selected,
                                    onSelected: (_) {
                                      setState(() {
                                        _activeCategory = category;
                                      });
                                    },
                                    selectedColor: kPrimary,
                                    backgroundColor: Colors.white,
                                    labelStyle: TextStyle(
                                      color: selected ? Colors.white : kText,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                );
                              }).toList(),
                        ),
                      ),
                      const SizedBox(height: 18),
                      if (_activeItems.isEmpty)
                        const _EmptySectionCard(
                          message:
                              'Belum ada menu yang cocok dengan pencarian kamu.',
                        ),
                      ..._activeItems.map(
                        (MenuItemData item) => Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: StoreMenuCard(
                            item: item,
                            vendor: widget.vendor,
                            isGuest: widget.isGuest,
                            onRequireLogin: widget.onRequireLogin,
                            quantityInCheckout:
                                _checkoutDraft[item.name]?.quantity ?? 0,
                            onAddToCheckout: () => _addItemToCheckout(item),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class StoreGallery extends StatefulWidget {
  const StoreGallery({super.key, required this.gallery});

  final List<StoreMedia> gallery;

  @override
  State<StoreGallery> createState() => _StoreGalleryState();
}

class _FloatingHeaderButton extends StatelessWidget {
  const _FloatingHeaderButton({
    required this.onTap,
    required this.icon,
    this.iconColor,
    this.solidBackground = true,
  });

  final VoidCallback onTap;
  final IconData icon;
  final Color? iconColor;
  final bool solidBackground;

  @override
  Widget build(BuildContext context) {
    return Material(
      color:
          solidBackground ? Colors.white.withValues(alpha: 0.92) : Colors.white,
      elevation: solidBackground ? 8 : 0,
      shadowColor: const Color(0x1F0F172A),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 40,
          height: 40,
          child: Icon(
            icon,
            color: iconColor ?? const Color(0xFF0F172A),
            size: 22,
          ),
        ),
      ),
    );
  }
}

class _StoreGalleryState extends State<StoreGallery> {
  int _index = 0;
  late final PageController _pageController = PageController();

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _openPreview() async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder:
            (_) => _StoreGalleryPreviewPage(
              gallery: widget.gallery,
              initialIndex: _index,
            ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final StoreMedia media = widget.gallery[_index];
    return Stack(
      fit: StackFit.expand,
      children: <Widget>[
        if (media.imagePath != null)
          Image.file(
            File(media.imagePath!),
            fit: BoxFit.cover,
            errorBuilder:
                (_, __, ___) => Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: <Color>[media.color, Colors.white],
                    ),
                  ),
                ),
          )
        else
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[media.color, Colors.white],
              ),
            ),
          ),
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[
                Colors.black.withValues(alpha: 0.18),
                Colors.transparent,
                Colors.white.withValues(alpha: 0.05),
              ],
              stops: const <double>[0, 0.28, 1],
            ),
          ),
        ),
        PageView.builder(
          controller: _pageController,
          physics: const BouncingScrollPhysics(),
          allowImplicitScrolling: true,
          itemCount: widget.gallery.length,
          onPageChanged: (int value) {
            setState(() {
              _index = value;
            });
          },
          itemBuilder: (BuildContext context, int index) {
            final StoreMedia media = widget.gallery[index];
            return Stack(
              fit: StackFit.expand,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 98, 20, 92),
                  child: GestureDetector(
                    onTap: _openPreview,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(28),
                      child: Stack(
                        fit: StackFit.expand,
                        children: <Widget>[
                          if (media.imagePath != null)
                            Image.file(
                              File(media.imagePath!),
                              fit: BoxFit.cover,
                              errorBuilder:
                                  (_, __, ___) => DecoratedBox(
                                    decoration: BoxDecoration(
                                      color: media.color,
                                    ),
                                    child: Center(
                                      child: Icon(
                                        media.icon,
                                        size: 82,
                                        color: kPrimaryDark,
                                      ),
                                    ),
                                  ),
                            )
                          else
                            DecoratedBox(
                              decoration: BoxDecoration(color: media.color),
                              child: Center(
                                child: Icon(
                                  media.icon,
                                  size: 82,
                                  color: kPrimaryDark,
                                ),
                              ),
                            ),
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: <Color>[
                                  Colors.transparent,
                                  Colors.black.withValues(alpha: 0.62),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Positioned(
                  left: 28,
                  right: 28,
                  bottom: 54,
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 260),
                    switchInCurve: Curves.easeOutCubic,
                    switchOutCurve: Curves.easeInCubic,
                    transitionBuilder: (
                      Widget child,
                      Animation<double> animation,
                    ) {
                      return FadeTransition(
                        opacity: animation,
                        child: SlideTransition(
                          position: Tween<Offset>(
                            begin: const Offset(0, 0.08),
                            end: Offset.zero,
                          ).animate(animation),
                          child: child,
                        ),
                      );
                    },
                    child: Column(
                      key: ValueKey<String>('${media.title}-${media.subtitle}'),
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.22),
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.28),
                            ),
                          ),
                          child: const Text(
                            'Galeri Toko',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 12,
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          media.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.headlineSmall
                              ?.copyWith(color: Colors.white),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          media.subtitle,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(
                            context,
                          ).textTheme.bodyMedium?.copyWith(
                            color: Colors.white.withValues(alpha: 0.88),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: List<Widget>.generate(
                            widget.gallery.length,
                            (int indicatorIndex) {
                              final bool active = indicatorIndex == _index;
                              return GestureDetector(
                                onTap: () {
                                  _pageController.animateToPage(
                                    indicatorIndex,
                                    duration: const Duration(milliseconds: 260),
                                    curve: Curves.easeOutCubic,
                                  );
                                },
                                child: SizedBox(
                                  width: 22,
                                  height: 8,
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: AnimatedContainer(
                                      duration: const Duration(
                                        milliseconds: 220,
                                      ),
                                      curve: Curves.easeOutCubic,
                                      width: active ? 22 : 8,
                                      height: 8,
                                      margin: const EdgeInsets.only(right: 8),
                                      decoration: BoxDecoration(
                                        color:
                                            active
                                                ? Colors.white
                                                : Colors.white.withValues(
                                                  alpha: 0.38,
                                                ),
                                        borderRadius: BorderRadius.circular(
                                          999,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _StoreGalleryPreviewPage extends StatefulWidget {
  const _StoreGalleryPreviewPage({
    required this.gallery,
    required this.initialIndex,
  });

  final List<StoreMedia> gallery;
  final int initialIndex;

  @override
  State<_StoreGalleryPreviewPage> createState() =>
      _StoreGalleryPreviewPageState();
}

class _StoreGalleryPreviewPageState extends State<_StoreGalleryPreviewPage> {
  late int _index = widget.initialIndex;
  late final PageController _pageController = PageController(
    initialPage: widget.initialIndex,
  );

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final StoreMedia activeMedia = widget.gallery[_index];
    return Scaffold(
      backgroundColor: const Color(0xFF020617),
      body: Stack(
        children: <Widget>[
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[
                    activeMedia.color.withValues(alpha: 0.34),
                    const Color(0xFF020617),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  child: Row(
                    children: <Widget>[
                      _PreviewCircleButton(
                        icon: Icons.close_rounded,
                        onTap: () => Navigator.of(context).pop(),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.08),
                          ),
                        ),
                        child: Text(
                          '${_index + 1} / ${widget.gallery.length}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    physics: const BouncingScrollPhysics(),
                    allowImplicitScrolling: true,
                    itemCount: widget.gallery.length,
                    onPageChanged: (int value) {
                      setState(() {
                        _index = value;
                      });
                    },
                    itemBuilder: (BuildContext context, int index) {
                      final StoreMedia media = widget.gallery[index];
                      return Padding(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(28),
                          child: Container(
                            color: Colors.black,
                            child:
                                media.imagePath != null
                                    ? Image.file(
                                      File(media.imagePath!),
                                      fit: BoxFit.contain,
                                      errorBuilder:
                                          (_, __, ___) => Container(
                                            color: media.color,
                                            alignment: Alignment.center,
                                            child: Icon(
                                              media.icon,
                                              color: Colors.white,
                                              size: 72,
                                            ),
                                          ),
                                    )
                                    : Container(
                                      color: media.color,
                                      alignment: Alignment.center,
                                      child: Icon(
                                        media.icon,
                                        color: Colors.white,
                                        size: 72,
                                      ),
                                    ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Container(
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(26),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.08),
                    ),
                  ),
                  child: Column(
                    children: <Widget>[
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 220),
                        transitionBuilder: (
                          Widget child,
                          Animation<double> animation,
                        ) {
                          return FadeTransition(
                            opacity: animation,
                            child: child,
                          );
                        },
                        child: Column(
                          key: ValueKey<String>(
                            '${activeMedia.title}-${activeMedia.subtitle}',
                          ),
                          children: <Widget>[
                            Text(
                              activeMedia.title,
                              textAlign: TextAlign.center,
                              style: Theme.of(context).textTheme.titleLarge
                                  ?.copyWith(color: Colors.white),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              activeMedia.subtitle,
                              textAlign: TextAlign.center,
                              style: Theme.of(
                                context,
                              ).textTheme.bodyMedium?.copyWith(
                                color: Colors.white.withValues(alpha: 0.76),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List<Widget>.generate(widget.gallery.length, (
                          int indicatorIndex,
                        ) {
                          final bool active = indicatorIndex == _index;
                          return GestureDetector(
                            onTap: () {
                              _pageController.animateToPage(
                                indicatorIndex,
                                duration: const Duration(milliseconds: 260),
                                curve: Curves.easeOutCubic,
                              );
                            },
                            child: SizedBox(
                              width: 22,
                              height: 8,
                              child: Center(
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 220),
                                  curve: Curves.easeOutCubic,
                                  width: active ? 22 : 8,
                                  height: 8,
                                  margin: const EdgeInsets.symmetric(
                                    horizontal: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color:
                                        active
                                            ? Colors.white
                                            : Colors.white.withValues(
                                              alpha: 0.34,
                                            ),
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                ),
                              ),
                            ),
                          );
                        }),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PreviewCircleButton extends StatelessWidget {
  const _PreviewCircleButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: onTap,
      child: Ink(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
        ),
        child: Icon(icon, color: Colors.white),
      ),
    );
  }
}

class _StoreMetaPill extends StatelessWidget {
  const _StoreMetaPill({
    required this.icon,
    required this.label,
    this.iconColor = kPrimaryDark,
  });

  final IconData icon;
  final String label;
  final Color iconColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: kBorder),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, size: 16, color: iconColor),
          const SizedBox(width: 8),
          Text(
            label,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: kText,
              fontWeight: FontWeight.w600,
              fontSize: 12.5,
            ),
          ),
        ],
      ),
    );
  }
}

class _StoreActionButton extends StatelessWidget {
  const _StoreActionButton({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.filled = false,
    this.enabled = true,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final bool filled;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    final Color background =
        !enabled
            ? const Color(0xFFF1F5F9)
            : filled
            ? kPrimary
            : Colors.white;
    final Color foreground =
        !enabled
            ? kMuted
            : filled
            ? Colors.white
            : kPrimaryDark;
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: enabled ? onTap : null,
      child: Ink(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: background,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color:
                filled
                    ? kPrimary
                    : (enabled ? kBorder : const Color(0xFFE2E8F0)),
          ),
        ),
        child: Row(
          children: <Widget>[
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color:
                    filled
                        ? Colors.white.withValues(alpha: 0.18)
                        : kPrimarySoft,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: foreground),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(
                      context,
                    ).textTheme.titleMedium?.copyWith(color: foreground),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color:
                          filled
                              ? Colors.white.withValues(alpha: 0.78)
                              : (enabled ? kMuted : kMuted),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StoreSectionHeader extends StatelessWidget {
  const _StoreSectionHeader({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(title, style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6),
        Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
      ],
    );
  }
}

class _StoreInfoTile extends StatelessWidget {
  const _StoreInfoTile({
    required this.icon,
    required this.title,
    required this.value,
  });

  final IconData icon;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: kPrimarySoft,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Icon(icon, color: kPrimaryDark),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                title,
                style: Theme.of(
                  context,
                ).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 4),
              Text(value, style: Theme.of(context).textTheme.bodyLarge),
            ],
          ),
        ),
      ],
    );
  }
}

class _CustomMenuRequestSheet extends StatefulWidget {
  const _CustomMenuRequestSheet({
    required this.vendor,
    this.initialTitle = '',
    this.initialDescription = '',
    this.initialBudgetLabel = '',
    this.initialTargetPax = 30,
  });

  final Vendor vendor;
  final String initialTitle;
  final String initialDescription;
  final String initialBudgetLabel;
  final int initialTargetPax;

  @override
  State<_CustomMenuRequestSheet> createState() =>
      _CustomMenuRequestSheetState();
}

class _CustomMenuRequestSheetState extends State<_CustomMenuRequestSheet> {
  late BuyerProfileData _buyerProfile = BuyerProfileRepository.current();
  late final TextEditingController _titleController = TextEditingController(
    text: widget.initialTitle,
  );
  late final TextEditingController _descriptionController =
      TextEditingController(text: widget.initialDescription);
  late final TextEditingController _budgetController = TextEditingController(
    text: widget.initialBudgetLabel,
  );
  late int _targetPax = widget.initialTargetPax;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _hydrateBuyerProfile();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _budgetController.dispose();
    super.dispose();
  }

  Future<void> _hydrateBuyerProfile() async {
    await BuyerProfileRepository.ensureLoaded();
    if (!mounted) {
      return;
    }
    setState(() {
      _buyerProfile = BuyerProfileRepository.current();
    });
  }

  Future<void> _submit() async {
    final String title = _titleController.text.trim();
    final String description = _descriptionController.text.trim();
    final String budgetLabel = _budgetController.text.trim();

    if (title.isEmpty || description.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Isi nama request dan detail kebutuhan menunya dulu ya.',
          ),
        ),
      );
      return;
    }

    setState(() {
      _isSubmitting = true;
    });

    final CustomMenuRequest request =
        await CustomMenuRequestRepository.placeRequest(
          vendor: widget.vendor,
          buyerId: BuyerProfileRepository.buyerId,
          buyerName: _buyerProfile.name,
          title: title,
          description: description,
          targetPax: _targetPax,
          budgetLabel: budgetLabel.isEmpty ? 'Budget fleksibel' : budgetLabel,
        );
    await ChatRepository.sendMessage(
      vendorId: widget.vendor.id,
      text: buildCustomRequestChatPayload(
        requestId: request.id,
        title: title,
        description: description,
        targetPax: _targetPax,
        budgetLabel: budgetLabel.isEmpty ? 'Budget fleksibel' : budgetLabel,
      ),
      senderId: BuyerProfileRepository.buyerId,
      senderLabel: _buyerProfile.name,
    );

    if (!mounted) {
      return;
    }
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        20,
        20,
        MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Request menu custom',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              widget.initialTitle.isEmpty
                  ? 'Kirim kebutuhan paket khusus ke ${widget.vendor.name} tanpa menambah menu umum toko.'
                  : 'Lanjutkan negosiasi dengan detail sebelumnya. Kamu tinggal ubah bagian yang perlu saja.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 18),
            TextField(
              controller: _titleController,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: 'Nama request',
                hintText: 'Contoh: Paket meeting 35 pax',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _descriptionController,
              minLines: 3,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: 'Detail kebutuhan menu',
                hintText:
                    'Contoh: nasi ayam, tahu, tempe, sambal, air mineral, tanpa pedas',
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: <Widget>[
                const Text('Jumlah pax'),
                const Spacer(),
                IconButton(
                  onPressed:
                      _targetPax > 1
                          ? () {
                            setState(() {
                              _targetPax -= 1;
                            });
                          }
                          : null,
                  icon: const Icon(Icons.remove_circle_outline_rounded),
                ),
                Text(
                  '$_targetPax',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                IconButton(
                  onPressed: () {
                    setState(() {
                      _targetPax += 1;
                    });
                  },
                  icon: const Icon(Icons.add_circle_outline_rounded),
                ),
              ],
            ),
            const SizedBox(height: 6),
            TextField(
              controller: _budgetController,
              keyboardType: TextInputType.text,
              decoration: const InputDecoration(
                labelText: 'Budget (opsional)',
                hintText: 'Contoh: Rp35.000 / pax atau maksimal Rp1.200.000',
              ),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: _isSubmitting ? null : _submit,
              icon:
                  _isSubmitting
                      ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                      : const Icon(Icons.send_rounded),
              label: Text(
                _isSubmitting ? 'Mengirim request...' : 'Kirim Request',
              ),
              style: FilledButton.styleFrom(
                backgroundColor: kPrimary,
                minimumSize: const Size.fromHeight(52),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class StoreMenuCard extends StatelessWidget {
  const StoreMenuCard({
    super.key,
    required this.item,
    required this.vendor,
    required this.quantityInCheckout,
    required this.onAddToCheckout,
    this.isGuest = false,
    this.onRequireLogin,
  });

  final MenuItemData item;
  final Vendor vendor;
  final int quantityInCheckout;
  final VoidCallback onAddToCheckout;
  final bool isGuest;
  final Future<void> Function(BuildContext context, {AppMode? preferredMode})?
  onRequireLogin;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      item.name,
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      item.description,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Text(
                formatRupiah(item.price),
                style: Theme.of(
                  context,
                ).textTheme.titleMedium?.copyWith(color: kPrimaryDark),
              ),
            ],
          ),
          if (item.components.isNotEmpty) ...<Widget>[
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children:
                  item.components
                      .map(
                        (String component) => Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: kPrimarySoft,
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            component,
                            style: const TextStyle(
                              color: kPrimaryDark,
                              fontWeight: FontWeight.w700,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      )
                      .toList(),
            ),
          ],
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: vendor.isOpen ? onAddToCheckout : null,
                  icon: const Icon(Icons.add_shopping_cart_rounded),
                  label: Text(
                    vendor.isOpen ? 'Tambah ke booking' : 'Properti nonaktif',
                  ),
                ),
              ),
              if (quantityInCheckout > 0) ...<Widget>[
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: kPrimarySoft,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    'x$quantityInCheckout',
                    style: const TextStyle(
                      color: kPrimaryDark,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _CartCheckoutSheet extends StatefulWidget {
  const _CartCheckoutSheet({required this.vendor, required this.initialItems});

  final Vendor vendor;
  final List<_CheckoutDraftItem> initialItems;

  @override
  State<_CartCheckoutSheet> createState() => _CartCheckoutSheetState();
}

class _CartCheckoutSheetState extends State<_CartCheckoutSheet> {
  late BuyerProfileData _buyerProfile = BuyerProfileRepository.current();
  late final TextEditingController _addressController = TextEditingController(
    text: BuyerProfileRepository.current().primaryAddress,
  );
  late final TextEditingController _notesController = TextEditingController();
  late List<_CheckoutDraftItem> _items;
  final Map<String, TextEditingController> _quantityControllers =
      <String, TextEditingController>{};
  bool _isSubmitting = false;
  DateTime _deliveryDate = DateTime.now().add(const Duration(days: 1));
  TimeOfDay _deliveryTime = const TimeOfDay(hour: 11, minute: 30);

  @override
  void initState() {
    super.initState();
    _items =
        widget.initialItems
            .map(
              (_CheckoutDraftItem item) =>
                  _CheckoutDraftItem(item: item.item, quantity: item.quantity),
            )
            .toList();
    _hydrateBuyerProfile();
  }

  @override
  void dispose() {
    for (final TextEditingController controller
        in _quantityControllers.values) {
      controller.dispose();
    }
    _addressController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _hydrateBuyerProfile() async {
    await BuyerProfileRepository.ensureLoaded();
    final BuyerProfileData profile = BuyerProfileRepository.current();
    if (!mounted) {
      return;
    }
    setState(() {
      _buyerProfile = profile;
      if (_addressController.text ==
          BuyerProfileRepository.fallback.primaryAddress) {
        _addressController.text = profile.primaryAddress;
      }
    });
  }

  String get _scheduleLabel {
    const List<String> monthNames = <String>[
      'Januari',
      'Februari',
      'Maret',
      'April',
      'Mei',
      'Juni',
      'Juli',
      'Agustus',
      'September',
      'Oktober',
      'November',
      'Desember',
    ];
    return '${_deliveryDate.day.toString().padLeft(2, '0')} ${monthNames[_deliveryDate.month - 1]} ${_deliveryDate.year} • ${_deliveryTime.hour.toString().padLeft(2, '0')}:${_deliveryTime.minute.toString().padLeft(2, '0')}';
  }

  int get _totalPrice => _items.fold<int>(
    0,
    (int sum, _CheckoutDraftItem item) => sum + item.subtotal,
  );

  int get _totalUnits => _items.fold<int>(
    0,
    (int sum, _CheckoutDraftItem item) => sum + item.quantity,
  );

  String get _checkoutLabel =>
      _items.length == 1
          ? _items.first.item.name
          : '${_items.first.item.name} +${_items.length - 1} lainnya';

  Future<void> _pickDate() async {
    final DateTime now = DateTime.now();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _deliveryDate,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: now.add(const Duration(days: 180)),
    );
    if (picked == null) {
      return;
    }
    setState(() {
      _deliveryDate = picked;
    });
  }

  Future<void> _pickTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _deliveryTime,
    );
    if (picked == null) {
      return;
    }
    setState(() {
      _deliveryTime = picked;
    });
  }

  void _changeItemQuantity(int index, int delta) {
    setState(() {
      final _CheckoutDraftItem current = _items[index];
      final int nextQuantity = current.quantity + delta;
      if (nextQuantity <= 0) {
        _quantityControllers.remove(current.item.name)?.dispose();
        _items.removeAt(index);
      } else {
        _items[index] = _CheckoutDraftItem(
          item: current.item,
          quantity: nextQuantity,
        );
        _controllerForItem(_items[index]).text = nextQuantity.toString();
      }
    });
    if (_items.isEmpty) {
      Navigator.of(context).pop();
    }
  }

  TextEditingController _controllerForItem(_CheckoutDraftItem item) {
    return _quantityControllers.putIfAbsent(
      item.item.name,
      () => TextEditingController(text: item.quantity.toString()),
    );
  }

  void _commitItemQuantity(int index) {
    final _CheckoutDraftItem current = _items[index];
    final TextEditingController controller = _controllerForItem(current);
    final int? newQuantity = int.tryParse(controller.text.trim());
    if (newQuantity == null || newQuantity <= 0) {
      controller.text = current.quantity.toString();
      return;
    }
    setState(() {
      _items[index] = _CheckoutDraftItem(
        item: current.item,
        quantity: newQuantity,
      );
    });
    controller.text = newQuantity.toString();
  }

  Future<void> _submit() async {
    final String address = _addressController.text.trim();
    if (address.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Isi alamat pengantaran dulu ya.')),
      );
      return;
    }

    final int downPayment = _calculateDownPayment(_totalPrice);
    setState(() {
      _isSubmitting = true;
    });

    final bool paymentConfirmed = await _showMockQrisPaymentPage(
      context,
      vendorName: widget.vendor.name,
      menuName: _checkoutLabel,
      scheduleLabel: _scheduleLabel,
      totalPrice: downPayment,
      paymentStage: 'Bayar DP 50%',
    );
    if (!mounted) {
      return;
    }
    if (!paymentConfirmed) {
      setState(() {
        _isSubmitting = false;
      });
      return;
    }

    final OrderRecord order = await OrderRepository.placeCartOrder(
      vendor: widget.vendor,
      items:
          _items
              .map(
                (_CheckoutDraftItem entry) => OrderLineItem(
                  name: entry.item.name,
                  unitPrice: entry.item.price,
                  quantity: entry.quantity,
                ),
              )
              .toList(),
      scheduleLabel: _scheduleLabel,
      deliveryAddress: address,
      buyerId: BuyerProfileRepository.buyerId,
      buyerName: _buyerProfile.name,
      amountPaid: downPayment,
      paymentMethodLabel: 'QRIS',
      paymentStatus: 'DP 50%',
      notes: _notesController.text.trim(),
    );

    if (!mounted) {
      return;
    }
    Navigator.of(context).pop(order);
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      clipBehavior: Clip.antiAlias,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            16,
            20,
            MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          child: ListView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            children: <Widget>[
              Center(
                child: Container(
                  width: 52,
                  height: 5,
                  decoration: BoxDecoration(
                    color: const Color(0xFFD1D5DB),
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Booking unit',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 6),
              Text(
                '${widget.vendor.name} • ${_items.length} menu dipilih',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: <Widget>[
                  _StoreMetaPill(
                    icon: Icons.restaurant_menu_rounded,
                    label: '${_items.length} menu',
                  ),
                  _StoreMetaPill(
                    icon: Icons.groups_rounded,
                    label: '$_totalUnits unit',
                  ),
                  _StoreMetaPill(
                    icon: Icons.payments_outlined,
                    label:
                        'DP ${formatRupiah(_calculateDownPayment(_totalPrice))}',
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kBorder),
                ),
                child: Column(
                  children:
                      _items.asMap().entries.map((
                        MapEntry<int, _CheckoutDraftItem> entry,
                      ) {
                        final int index = entry.key;
                        final _CheckoutDraftItem cartItem = entry.value;
                        return Padding(
                          padding: EdgeInsets.only(
                            bottom: index == _items.length - 1 ? 0 : 12,
                          ),
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: kBorder),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Text(
                                        cartItem.item.name,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style:
                                            Theme.of(
                                              context,
                                            ).textTheme.titleMedium,
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        formatRupiah(cartItem.item.price),
                                        style:
                                            Theme.of(
                                              context,
                                            ).textTheme.bodyMedium,
                                      ),
                                      const SizedBox(height: 6),
                                      Text(
                                        'Subtotal ${formatRupiah(cartItem.subtotal)}',
                                        style:
                                            Theme.of(
                                              context,
                                            ).textTheme.bodySmall,
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    IconButton(
                                      onPressed:
                                          _isSubmitting
                                              ? null
                                              : () => _changeItemQuantity(
                                                index,
                                                -1,
                                              ),
                                      icon: const Icon(
                                        Icons.remove_circle_outline_rounded,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 46,
                                      child: TextField(
                                        controller: _controllerForItem(
                                          cartItem,
                                        ),
                                        enabled: !_isSubmitting,
                                        textAlign: TextAlign.center,
                                        keyboardType: TextInputType.number,
                                        inputFormatters: <TextInputFormatter>[
                                          FilteringTextInputFormatter
                                              .digitsOnly,
                                        ],
                                        onSubmitted:
                                            (_) => _commitItemQuantity(index),
                                        onTapOutside:
                                            (_) => _commitItemQuantity(index),
                                        decoration: InputDecoration(
                                          isDense: true,
                                          contentPadding:
                                              const EdgeInsets.symmetric(
                                                horizontal: 8,
                                                vertical: 8,
                                              ),
                                          filled: true,
                                          fillColor: const Color(0xFFF8FAFC),
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                            borderSide: const BorderSide(
                                              color: kBorder,
                                            ),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                            borderSide: const BorderSide(
                                              color: kBorder,
                                            ),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                            borderSide: const BorderSide(
                                              color: kPrimary,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    IconButton(
                                      onPressed:
                                          _isSubmitting
                                              ? null
                                              : () =>
                                                  _changeItemQuantity(index, 1),
                                      icon: const Icon(
                                        Icons.add_circle_outline_rounded,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      }).toList(),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: <Widget>[
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickDate,
                      icon: const Icon(Icons.calendar_today_rounded),
                      label: Text(
                        '${_deliveryDate.day.toString().padLeft(2, '0')}/${_deliveryDate.month.toString().padLeft(2, '0')}/${_deliveryDate.year}',
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickTime,
                      icon: const Icon(Icons.access_time_rounded),
                      label: Text(
                        '${_deliveryTime.hour.toString().padLeft(2, '0')}:${_deliveryTime.minute.toString().padLeft(2, '0')}',
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _addressController,
                minLines: 2,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Alamat pengantaran',
                  hintText: 'Masukkan alamat lengkap tujuan pesanan',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _notesController,
                minLines: 2,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Catatan pesanan',
                  hintText: 'Contoh: tambah sambal, tanpa timun',
                ),
              ),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: kBorder),
                ),
                child: Row(
                  children: <Widget>[
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: kPrimarySoft,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: const Icon(
                        Icons.qr_code_2_rounded,
                        color: kPrimaryDark,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Pembayaran QRIS',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Pembayaran DP akan terdeteksi otomatis, lalu pesanan langsung masuk.',
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              const _CancellationPolicyCard(
                title: 'Kebijakan DP & pembatalan',
                lines: <String>[
                  'Pesanan dikunci setelah DP 50% berhasil dibayar.',
                  'DP yang sudah dibayar tidak dapat dikembalikan jika pesanan dibatalkan.',
                  'Sisa pembayaran bisa dilunasi nanti dari halaman pesanan.',
                ],
              ),
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: kBorder),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    _InvoiceRow(label: 'Jadwal kirim', value: _scheduleLabel),
                    const SizedBox(height: 8),
                    _InvoiceRow(
                      label: 'Jumlah item',
                      value: '${_items.length} menu',
                    ),
                    const SizedBox(height: 8),
                    _InvoiceRow(
                      label: 'Total unit',
                      value: '$_totalUnits unit',
                    ),
                    const SizedBox(height: 8),
                    _InvoiceRow(
                      label: 'DP 50%',
                      value: formatRupiah(_calculateDownPayment(_totalPrice)),
                    ),
                    const SizedBox(height: 8),
                    _InvoiceRow(
                      label: 'Sisa pelunasan',
                      value: formatRupiah(
                        _totalPrice - _calculateDownPayment(_totalPrice),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const _InvoiceRow(label: 'Metode bayar', value: 'QRIS'),
                    const SizedBox(height: 8),
                    const _InvoiceRow(
                      label: 'Status bayar',
                      value: 'DP dibayar, sisa dilunasi nanti',
                    ),
                    const SizedBox(height: 8),
                    _InvoiceRow(
                      label: 'Total',
                      value: formatRupiah(_totalPrice),
                      emphasized: true,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _isSubmitting ? null : _submit,
                icon:
                    _isSubmitting
                        ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                        : const Icon(Icons.shopping_bag_rounded),
                label: Text(
                  _isSubmitting ? 'Memproses...' : 'Lanjut ke pembayaran',
                ),
                style: FilledButton.styleFrom(
                  backgroundColor: kPrimary,
                  minimumSize: const Size.fromHeight(52),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Future<bool> _showMockQrisPaymentPage(
  BuildContext context, {
  required String vendorName,
  required String menuName,
  required String scheduleLabel,
  required int totalPrice,
  required String paymentStage,
}) async {
  final bool? result = await Navigator.of(context).push<bool>(
    MaterialPageRoute<bool>(
      builder:
          (_) => _MockQrisPaymentPage(
            vendorName: vendorName,
            menuName: menuName,
            scheduleLabel: scheduleLabel,
            totalPrice: totalPrice,
            paymentStage: paymentStage,
          ),
    ),
  );
  return result ?? false;
}

class _MockQrisPaymentPage extends StatefulWidget {
  const _MockQrisPaymentPage({
    required this.vendorName,
    required this.menuName,
    required this.scheduleLabel,
    required this.totalPrice,
    required this.paymentStage,
  });

  final String vendorName;
  final String menuName;
  final String scheduleLabel;
  final int totalPrice;
  final String paymentStage;

  @override
  State<_MockQrisPaymentPage> createState() => _MockQrisPaymentPageState();
}

class _MockQrisPaymentPageState extends State<_MockQrisPaymentPage> {
  bool _isSubmitting = false;
  Timer? _autoTimer;

  @override
  void initState() {
    super.initState();
    _autoTimer = Timer(const Duration(seconds: 3), _confirmPayment);
  }

  @override
  void dispose() {
    _autoTimer?.cancel();
    super.dispose();
  }

  Future<void> _copyAmount() async {
    await Clipboard.setData(ClipboardData(text: widget.totalPrice.toString()));
    if (!mounted) {
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Nominal pembayaran disalin.')),
    );
  }

  Future<void> _confirmPayment() async {
    if (_isSubmitting) {
      return;
    }
    setState(() {
      _isSubmitting = true;
    });
    await Future<void>.delayed(const Duration(milliseconds: 700));
    if (!mounted) {
      return;
    }
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackground,
      appBar: AppBar(
        title: const Text('Pembayaran QRIS'),
        backgroundColor: kBackground,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
          child: Column(
            children: <Widget>[
              Expanded(
                child: ListView(
                  children: <Widget>[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: <Color>[Color(0xFFECFDF3), Colors.white],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(28),
                        border: Border.all(color: kBorder),
                        boxShadow: const <BoxShadow>[
                          BoxShadow(
                            color: Color(0x12000000),
                            blurRadius: 24,
                            offset: Offset(0, 12),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 7,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(999),
                                  border: Border.all(
                                    color: const Color(0xFFD1FAE5),
                                  ),
                                ),
                                child: const Text(
                                  'QRIS Demo',
                                  style: TextStyle(
                                    color: kPrimaryDark,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                              const Spacer(),
                              Text(
                                'Berlaku 10 menit',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          Text(
                            widget.paymentStage,
                            style: Theme.of(context).textTheme.headlineSmall,
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'Pembayaran sedang dipantau otomatis. Setelah terdeteksi, aplikasi akan lanjut sendiri.',
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                          const SizedBox(height: 14),
                          LinearProgressIndicator(
                            minHeight: 8,
                            borderRadius: BorderRadius.circular(999),
                            backgroundColor: const Color(0xFFD1FAE5),
                            color: kPrimary,
                          ),
                          const SizedBox(height: 18),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(color: kBorder),
                            ),
                            child: Column(
                              children: <Widget>[
                                _InvoiceRow(
                                  label: 'Vendor',
                                  value: widget.vendorName,
                                ),
                                const SizedBox(height: 10),
                                _InvoiceRow(
                                  label: 'Pesanan',
                                  value: widget.menuName,
                                ),
                                const SizedBox(height: 10),
                                _InvoiceRow(
                                  label: 'Jadwal kirim',
                                  value: widget.scheduleLabel,
                                ),
                                const Divider(height: 26),
                                _InvoiceRow(
                                  label: 'Total bayar',
                                  value: formatRupiah(widget.totalPrice),
                                  emphasized: true,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 18),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              color: const Color(0xFF0F172A),
                              borderRadius: BorderRadius.circular(28),
                            ),
                            child: Column(
                              children: <Widget>[
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.all(18),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(24),
                                  ),
                                  child: Column(
                                    children: <Widget>[
                                      Row(
                                        children: <Widget>[
                                          const Icon(
                                            Icons.qr_code_scanner_rounded,
                                            color: kPrimaryDark,
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            'ASKIA CATERING',
                                            style: Theme.of(context)
                                                .textTheme
                                                .labelLarge
                                                ?.copyWith(color: kPrimaryDark),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 16),
                                      Row(
                                        children: List<Widget>.generate(
                                          4,
                                          (int row) => Expanded(
                                            child: Column(
                                              children: List<Widget>.generate(
                                                6,
                                                (int column) => Container(
                                                  margin:
                                                      const EdgeInsets.symmetric(
                                                        horizontal: 4,
                                                        vertical: 4,
                                                      ),
                                                  height: 12,
                                                  decoration: BoxDecoration(
                                                    color:
                                                        (row + column).isEven
                                                            ? const Color(
                                                              0xFF0F172A,
                                                            )
                                                            : Colors.white,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          2,
                                                        ),
                                                    border: Border.all(
                                                      color: const Color(
                                                        0xFF0F172A,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 14),
                                      Text(
                                        'ASKIA.QRIS.DEMO.2026',
                                        style: Theme.of(context)
                                            .textTheme
                                            .labelLarge
                                            ?.copyWith(letterSpacing: 1.2),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 14),
                                Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: _PaymentInfoPill(
                                        icon: Icons.flash_on_rounded,
                                        label: 'Nominal pas',
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: _PaymentInfoPill(
                                        icon: Icons.verified_user_rounded,
                                        label: 'Siap diverifikasi',
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: _copyAmount,
                                  icon: const Icon(Icons.copy_rounded),
                                  label: const Text('Salin nominal'),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 14,
                                    vertical: 14,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(18),
                                    border: Border.all(color: kBorder),
                                  ),
                                  child: Text(
                                    'Status: Menunggu bayar',
                                    textAlign: TextAlign.center,
                                    style:
                                        Theme.of(context).textTheme.labelLarge,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed:
                      _isSubmitting
                          ? null
                          : () => Navigator.of(context).pop(false),
                  child: const Text('Kembali'),
                ),
              ),
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kBorder),
                ),
                child: Row(
                  children: <Widget>[
                    const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.4),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        _isSubmitting
                            ? 'Pembayaran terdeteksi, sedang memverifikasi...'
                            : 'Menunggu pembayaran QRIS terdeteksi otomatis...',
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PaymentInfoPill extends StatelessWidget {
  const _PaymentInfoPill({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF172554),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Icon(icon, size: 18, color: Colors.white),
          const SizedBox(width: 8),
          Flexible(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(
                context,
              ).textTheme.labelLarge?.copyWith(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}

class ChatRoomPage extends StatefulWidget {
  const ChatRoomPage({
    super.key,
    required this.vendor,
    this.sellerMode = false,
    this.openRequestComposerOnStart = false,
  });

  final Vendor vendor;
  final bool sellerMode;
  final bool openRequestComposerOnStart;

  @override
  State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  late final String _currentSenderId =
      widget.sellerMode
          ? 'seller-${widget.vendor.id}'
          : BuyerProfileRepository.buyerId;
  late final String _currentSenderLabel =
      widget.sellerMode ? 'Penjual' : BuyerProfileRepository.current().name;
  bool _didOpenRequestComposer = false;
  int _lastAutoScrolledCount = -1;

  CustomMenuRequest? get _latestNegotiationRequest {
    final List<CustomMenuRequest> requests =
        CustomMenuRequestRepository.localSellerRequests(widget.vendor.id)
            .where(
              (CustomMenuRequest request) =>
                  request.status != 'Dibatalkan' &&
                  request.status != 'Disetujui',
            )
            .toList();
    if (requests.isEmpty) {
      return null;
    }
    return requests.first;
  }

  @override
  void initState() {
    super.initState();
    ChatRepository.seedSampleConversation(widget.vendor.id);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ChatRepository.markConversationRead(
        vendorId: widget.vendor.id,
        currentSenderId: _currentSenderId,
      );
      if (widget.openRequestComposerOnStart &&
          !widget.sellerMode &&
          !_didOpenRequestComposer &&
          mounted) {
        _didOpenRequestComposer = true;
        _openCustomRequestComposer();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _sendMessage() async {
    final String text = _controller.text.trim();
    if (text.isEmpty) return;
    await ChatRepository.sendMessage(
      vendorId: widget.vendor.id,
      text: text,
      senderId: _currentSenderId,
      senderLabel: _currentSenderLabel,
    );
    _controller.clear();
    _scrollToBottom();
  }

  Future<void> _openCustomRequestComposer() async {
    await _openNegotiationComposer();
  }

  Future<void> _openNegotiationComposer({
    CustomMenuRequest? request,
    OfferChatPayload? offer,
  }) async {
    final bool? created = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (BuildContext context) {
        return _CustomMenuRequestSheet(
          vendor: widget.vendor,
          initialTitle: request?.title ?? offer?.title ?? '',
          initialDescription:
              request?.description ?? offer?.sellerResponse ?? '',
          initialBudgetLabel:
              request?.budgetLabel ?? offer?.quotedPriceLabel ?? '',
          initialTargetPax: request?.targetPax ?? offer?.targetPax ?? 30,
        );
      },
    );
    if (created == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Request menu custom sudah masuk ke chat penjual.'),
        ),
      );
    }
  }

  Future<void> _openOfferApproval(
    BuildContext context,
    OfferChatPayload offer,
  ) async {
    final CustomMenuRequest? request =
        CustomMenuRequestRepository.localRequestById(offer.requestId);
    if (request == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Detail request belum siap. Coba buka ulang chat atau kirim nego lagi.',
          ),
        ),
      );
      return;
    }
    final int unitPrice = _extractPrice(offer.quotedPriceLabel);
    if (unitPrice <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Penawaran harga belum terbaca. Minta seller isi nominal yang jelas ya.',
          ),
        ),
      );
      return;
    }
    final OrderRecord? order = await Navigator.of(context).push<OrderRecord>(
      MaterialPageRoute<OrderRecord>(
        builder:
            (_) => _CheckoutScaffold(
              title: 'Checkout request custom',
              child: _CustomRequestApprovalSheet(
                request: request,
                unitPrice: unitPrice,
              ),
            ),
      ),
    );
    if (order == null || !context.mounted) {
      return;
    }
    await Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => _OrderSuccessPage(order: order)),
    );
  }

  Future<void> _openSellerOfferComposer() async {
    final CustomMenuRequest? request = _latestNegotiationRequest;
    if (request == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Belum ada request aktif yang bisa dijadikan penawaran.',
          ),
        ),
      );
      return;
    }
    final _SellerOfferComposerResult? result =
        await showModalBottomSheet<_SellerOfferComposerResult>(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.white,
          builder: (BuildContext context) {
            return _SellerOfferComposerSheet(request: request);
          },
        );
    if (result == null) {
      return;
    }
    await CustomMenuRequestRepository.respondToRequest(
      requestId: request.id,
      status: 'Dijawab',
      title: result.title,
      description: result.description,
      targetPax: result.targetPax,
      sellerResponse: result.response,
      quotedPriceLabel: result.priceLabel,
    );
    await ChatRepository.sendMessage(
      vendorId: request.vendorId,
      text: buildOfferChatPayload(
        requestId: request.id,
        title: result.title,
        targetPax: result.targetPax,
        quotedPriceLabel: result.priceLabel,
        sellerResponse: result.response,
      ),
      senderId: _currentSenderId,
      senderLabel: _currentSenderLabel,
    );
    if (!mounted) {
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Penawaran sudah dikirim ke pembeli.')),
    );
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollController.hasClients) {
        return;
      }
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
      );
    });
  }

  void _syncAutoScroll(List<ChatMessage> messages) {
    if (messages.isEmpty) {
      return;
    }
    if (_lastAutoScrolledCount == messages.length) {
      return;
    }
    _lastAutoScrolledCount = messages.length;
    _scrollToBottom();
  }

  @override
  Widget build(BuildContext context) {
    final String sellerChatTitle =
        widget.sellerMode
            ? ChatRepository.localConversationLabel(
              vendorId: widget.vendor.id,
              currentSenderId: _currentSenderId,
              fallback: 'Pembeli',
            )
            : widget.vendor.name;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.sellerMode ? sellerChatTitle : widget.vendor.name),
        backgroundColor: Colors.white,
        actions: <Widget>[
          if (widget.sellerMode)
            FilledButton.tonalIcon(
              onPressed: _openSellerOfferComposer,
              icon: const Icon(Icons.local_offer_rounded),
              label: const Text('Offer'),
            ),
          if (!widget.sellerMode)
            FilledButton.tonalIcon(
              onPressed: _openCustomRequestComposer,
              icon: const Icon(Icons.edit_note_rounded),
              label: const Text('Request'),
            ),
        ],
      ),
      body: Column(
        children: <Widget>[
          Container(
            margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kBorder),
            ),
            child: Row(
              children: <Widget>[
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: kPrimarySoft,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(
                    widget.sellerMode
                        ? Icons.person_outline_rounded
                        : Icons.storefront_rounded,
                    color: kPrimaryDark,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        widget.sellerMode
                            ? sellerChatTitle
                            : widget.vendor.locationLabel,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        widget.sellerMode
                            ? 'Balas chat dan negosiasikan request menu dari pembeli.'
                            : 'Chat untuk tanya stok, request paket, atau detail pesanan.',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: StreamBuilder<List<ChatMessage>>(
              stream: ChatRepository.watchMessages(
                vendorId: widget.vendor.id,
                currentSenderId: _currentSenderId,
              ),
              initialData: const <ChatMessage>[],
              builder: (
                BuildContext context,
                AsyncSnapshot<List<ChatMessage>> snapshot,
              ) {
                final List<ChatMessage> messages =
                    snapshot.data ?? const <ChatMessage>[];
                _syncAutoScroll(messages);
                return ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
                  itemCount: messages.length,
                  itemBuilder: (BuildContext context, int index) {
                    final ChatMessage message = messages[index];
                    final CustomRequestChatPayload? requestPayload =
                        tryParseCustomRequestChatPayload(message.text);
                    final OfferChatPayload? offerPayload =
                        tryParseOfferChatPayload(message.text);
                    return Align(
                      alignment:
                          message.isMine
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        constraints: const BoxConstraints(maxWidth: 280),
                        decoration: BoxDecoration(
                          color:
                              requestPayload != null || offerPayload != null
                                  ? Colors.white
                                  : (message.isMine ? kPrimary : Colors.white),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(
                            color:
                                requestPayload != null || offerPayload != null
                                    ? const Color(0xFFD5ECDC)
                                    : (message.isMine ? kPrimary : kBorder),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment:
                              message.isMine
                                  ? CrossAxisAlignment.end
                                  : CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 10,
                              ),
                              child: Column(
                                crossAxisAlignment:
                                    message.isMine
                                        ? CrossAxisAlignment.end
                                        : CrossAxisAlignment.start,
                                children: <Widget>[
                                  if (!message.isMine &&
                                      message
                                          .senderLabel
                                          .isNotEmpty) ...<Widget>[
                                    Text(
                                      message.senderLabel,
                                      style: const TextStyle(
                                        color: kPrimaryDark,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 12,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                  ],
                                  if (requestPayload == null &&
                                      offerPayload == null)
                                    Text(
                                      message.text,
                                      style: TextStyle(
                                        color:
                                            message.isMine
                                                ? Colors.white
                                                : kText,
                                        height: 1.4,
                                      ),
                                    )
                                  else if (requestPayload != null)
                                    _CustomRequestChatCard(
                                      payload: requestPayload,
                                      isMine: message.isMine,
                                    )
                                  else
                                    _OfferChatCard(
                                      payload: offerPayload!,
                                      isMine: message.isMine,
                                      sellerMode: widget.sellerMode,
                                      onAccept:
                                          widget.sellerMode
                                              ? null
                                              : () => _openOfferApproval(
                                                context,
                                                offerPayload,
                                              ),
                                      onNegotiate:
                                          widget.sellerMode
                                              ? null
                                              : () => _openNegotiationComposer(
                                                request:
                                                    CustomMenuRequestRepository.localRequestById(
                                                      offerPayload.requestId,
                                                    ),
                                                offer: offerPayload,
                                              ),
                                    ),
                                  const SizedBox(height: 6),
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      Text(
                                        message.time,
                                        style: TextStyle(
                                          color:
                                              message.isMine
                                                  ? Colors.white70
                                                  : kMuted,
                                          fontSize: 11,
                                        ),
                                      ),
                                      if (message.isMine) ...<Widget>[
                                        const SizedBox(width: 4),
                                        Icon(
                                          message.deliveryStatus == 'read'
                                              ? Icons.done_all_rounded
                                              : Icons.done_rounded,
                                          size: 16,
                                          color:
                                              message.deliveryStatus == 'read'
                                                  ? const Color(0xFFBFDBFE)
                                                  : Colors.white70,
                                        ),
                                      ],
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 14),
            color: Colors.white,
            child: Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _controller,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _sendMessage(),
                    decoration: const InputDecoration(
                      hintText: 'Tulis pesan...',
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                FilledButton(
                  onPressed: _sendMessage,
                  style: FilledButton.styleFrom(
                    backgroundColor: kPrimary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: const Icon(Icons.send_rounded),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ChatListTile extends StatelessWidget {
  const ChatListTile({
    super.key,
    required this.vendor,
    this.sellerMode = false,
  });

  final Vendor vendor;
  final bool sellerMode;

  String get _currentSenderId =>
      sellerMode ? 'seller-${vendor.id}' : BuyerProfileRepository.buyerId;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder:
                (_) => ChatRoomPage(vendor: vendor, sellerMode: sellerMode),
          ),
        );
      },
      child: Ink(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: kBorder),
        ),
        child: StreamBuilder<List<ChatMessage>>(
          stream: ChatRepository.watchMessages(
            vendorId: vendor.id,
            currentSenderId: _currentSenderId,
          ),
          initialData: const <ChatMessage>[],
          builder: (
            BuildContext context,
            AsyncSnapshot<List<ChatMessage>> snapshot,
          ) {
            final List<ChatMessage> messages =
                snapshot.data ?? const <ChatMessage>[];
            final ChatMessage latest =
                messages.isNotEmpty
                    ? messages.last
                    : ChatMessage(
                      text:
                          sellerMode
                              ? 'Pembeli menanyakan custom paket.'
                              : vendor.chatHint,
                      isMine: false,
                      time: '',
                    );
            final String sellerConversationTitle =
                ChatRepository.localConversationLabel(
                  vendorId: vendor.id,
                  currentSenderId: _currentSenderId,
                  fallback: 'Pembeli',
                );
            final bool isRequestPreview = latest.text.startsWith(
              customRequestChatPrefix,
            );
            final bool isOfferPreview = latest.text.startsWith(offerChatPrefix);
            final bool showUnread =
                !latest.isMine &&
                latest.text.isNotEmpty &&
                latest.deliveryStatus != 'read';
            final bool showOutgoingStatus =
                latest.senderId.isNotEmpty && latest.isMine;

            return Row(
              children: <Widget>[
                const CircleAvatar(
                  radius: 24,
                  backgroundColor: kPrimarySoft,
                  child: Icon(Icons.storefront_rounded, color: kPrimary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        sellerMode ? sellerConversationTitle : vendor.name,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: <Widget>[
                          if (isRequestPreview) ...<Widget>[
                            const Icon(
                              Icons.edit_note_rounded,
                              size: 16,
                              color: kPrimaryDark,
                            ),
                            const SizedBox(width: 4),
                          ] else if (isOfferPreview) ...<Widget>[
                            const Icon(
                              Icons.local_offer_rounded,
                              size: 16,
                              color: Color(0xFFB45309),
                            ),
                            const SizedBox(width: 4),
                          ],
                          if (showOutgoingStatus) ...<Widget>[
                            Icon(
                              latest.deliveryStatus == 'read'
                                  ? Icons.done_all_rounded
                                  : Icons.done_rounded,
                              size: 16,
                              color:
                                  latest.deliveryStatus == 'read'
                                      ? const Color(0xFF1D4ED8)
                                      : kMuted,
                            ),
                            const SizedBox(width: 4),
                          ],
                          Expanded(
                            child: Text(
                              chatPreviewText(latest.text),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    if (latest.time.isNotEmpty)
                      Text(
                        latest.time,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    if (showUnread) ...<Widget>[
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: kPrimary,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: const Text(
                          'Baru',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ] else
                      const Icon(Icons.chevron_right_rounded),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _CustomRequestChatCard extends StatelessWidget {
  const _CustomRequestChatCard({required this.payload, required this.isMine});

  final CustomRequestChatPayload payload;
  final bool isMine;

  @override
  Widget build(BuildContext context) {
    final Color titleColor = const Color(0xFF0F172A);
    final Color bodyColor = const Color(0xFF475569);
    final Color cardBackground =
        isMine ? const Color(0xFFF6FBF7) : const Color(0xFFFAFBFC);
    final Color cardBorder =
        isMine ? const Color(0xFFD6ECDC) : const Color(0xFFE2E8F0);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardBackground,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: const Color(0xFFE8F5EC),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.edit_note_rounded,
                  color: kPrimaryDark,
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Request menu custom',
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    color: titleColor,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            payload.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(
              context,
            ).textTheme.titleMedium?.copyWith(color: titleColor),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              _ChatMetaChip(
                icon: Icons.groups_rounded,
                label: '${payload.targetPax} pax',
              ),
              _ChatMetaChip(
                icon: Icons.payments_outlined,
                label: payload.budgetLabel,
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            payload.description,
            maxLines: 4,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(
              context,
            ).textTheme.bodyMedium?.copyWith(color: bodyColor, height: 1.4),
          ),
        ],
      ),
    );
  }
}

class _OfferChatCard extends StatelessWidget {
  const _OfferChatCard({
    required this.payload,
    required this.isMine,
    required this.sellerMode,
    this.onAccept,
    this.onNegotiate,
  });

  final OfferChatPayload payload;
  final bool isMine;
  final bool sellerMode;
  final VoidCallback? onAccept;
  final VoidCallback? onNegotiate;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFCF4),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFF8D99A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF3D6),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.local_offer_rounded,
                  color: Color(0xFFB45309),
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Penawaran seller',
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    color: const Color(0xFF92400E),
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            payload.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.titleMedium,
          ),
          if (payload.sellerResponse.trim().isNotEmpty) ...<Widget>[
            const SizedBox(height: 10),
            Text(
              payload.sellerResponse,
              maxLines: 4,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: const Color(0xFF475569),
                height: 1.4,
              ),
            ),
          ],
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              _ChatMetaChip(
                icon: Icons.groups_rounded,
                label: '${payload.targetPax} pax',
                accentColor: const Color(0xFFB45309),
                backgroundColor: const Color(0xFFFFF3D6),
              ),
              _ChatMetaChip(
                icon: Icons.payments_outlined,
                label: payload.quotedPriceLabel,
                accentColor: const Color(0xFFB45309),
                backgroundColor: const Color(0xFFFFF3D6),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (sellerMode)
            Text(
              'Penawaran ini sudah terkirim ke pembeli.',
              style: Theme.of(context).textTheme.bodySmall,
            )
          else
            Row(
              children: <Widget>[
                Expanded(
                  child: FilledButton(
                    onPressed: onAccept,
                    style: FilledButton.styleFrom(
                      backgroundColor: kPrimary,
                      minimumSize: const Size.fromHeight(40),
                    ),
                    child: const Text('Terima'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton(
                    onPressed: onNegotiate,
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(40),
                    ),
                    child: const Text('Nego lagi'),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}

class _SellerOfferComposerResult {
  const _SellerOfferComposerResult({
    required this.title,
    required this.description,
    required this.targetPax,
    required this.priceLabel,
    required this.response,
  });

  final String title;
  final String description;
  final int targetPax;
  final String priceLabel;
  final String response;
}

class _SellerOfferComposerSheet extends StatefulWidget {
  const _SellerOfferComposerSheet({required this.request});

  final CustomMenuRequest request;

  @override
  State<_SellerOfferComposerSheet> createState() =>
      _SellerOfferComposerSheetState();
}

class _SellerOfferComposerSheetState extends State<_SellerOfferComposerSheet> {
  late final TextEditingController _titleController = TextEditingController(
    text: widget.request.title,
  );
  late final TextEditingController _descriptionController =
      TextEditingController(text: widget.request.description);
  late final TextEditingController _priceController = TextEditingController(
    text: widget.request.quotedPriceLabel,
  );
  late final TextEditingController _responseController = TextEditingController(
    text: widget.request.sellerResponse,
  );
  late int _targetPax = widget.request.targetPax;

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    _responseController.dispose();
    super.dispose();
  }

  void _submit() {
    final String title = _titleController.text.trim();
    final String description = _descriptionController.text.trim();
    final String priceLabel = _priceController.text.trim();
    final String response = _responseController.text.trim();
    if (title.isEmpty || description.isEmpty || priceLabel.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Isi nama paket, isi menu, dan harga penawaran dulu ya.',
          ),
        ),
      );
      return;
    }
    Navigator.of(context).pop(
      _SellerOfferComposerResult(
        title: title,
        description: description,
        targetPax: _targetPax,
        priceLabel: priceLabel,
        response: response,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        20,
        20,
        MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Susun penawaran',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              'Rapikan hasil negosiasi jadi paket final yang jelas untuk pembeli.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Nama paket',
                hintText: 'Contoh: Paket ayam bakar + sate kulit',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _descriptionController,
              minLines: 3,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: 'Isi menu final',
                hintText:
                    'Contoh: nasi, ayam bakar, sate kulit, sambal, air mineral',
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                const Text('Jumlah pax'),
                const Spacer(),
                IconButton(
                  onPressed:
                      _targetPax > 1
                          ? () {
                            setState(() {
                              _targetPax -= 1;
                            });
                          }
                          : null,
                  icon: const Icon(Icons.remove_circle_outline_rounded),
                ),
                Text(
                  '$_targetPax',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                IconButton(
                  onPressed: () {
                    setState(() {
                      _targetPax += 1;
                    });
                  },
                  icon: const Icon(Icons.add_circle_outline_rounded),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _priceController,
              decoration: const InputDecoration(
                labelText: 'Harga penawaran',
                hintText: 'Contoh: 25rb per pax atau 25.000',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _responseController,
              minLines: 2,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'Catatan untuk pembeli',
                hintText:
                    'Contoh: tambahan sate kulit sudah masuk harga ini ya kak',
              ),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: _submit,
              icon: const Icon(Icons.local_offer_rounded),
              label: const Text('Kirim penawaran'),
              style: FilledButton.styleFrom(
                backgroundColor: kPrimary,
                minimumSize: const Size.fromHeight(52),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChatMetaChip extends StatelessWidget {
  const _ChatMetaChip({
    required this.icon,
    required this.label,
    this.accentColor = kPrimaryDark,
    this.backgroundColor = const Color(0xFFEFF6F1),
  });

  final IconData icon;
  final String label;
  final Color accentColor;
  final Color backgroundColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, size: 14, color: accentColor),
          const SizedBox(width: 6),
          Text(
            label,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: accentColor,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class AppLogo extends StatelessWidget {
  const AppLogo({super.key, this.size = 48});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: kPrimarySoft,
        borderRadius: BorderRadius.circular(size * 0.28),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          Icon(Icons.apartment_rounded, color: kPrimaryDark, size: size * 0.46),
          Positioned(
            bottom: size * 0.14,
            right: size * 0.14,
            child: Container(
              width: size * 0.22,
              height: size * 0.22,
              decoration: const BoxDecoration(
                color: kPrimary,
                shape: BoxShape.circle,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class NotificationBellButton extends StatelessWidget {
  const NotificationBellButton({
    super.key,
    required this.count,
    required this.onTap,
  });

  final int count;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: onTap,
      icon: Stack(
        clipBehavior: Clip.none,
        children: <Widget>[
          const Icon(Icons.notifications_none_rounded),
          if (count > 0)
            Positioned(
              right: -2,
              top: -2,
              child: Container(
                width: 18,
                height: 18,
                decoration: const BoxDecoration(
                  color: Color(0xFFDC2626),
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: Text(
                  count > 9 ? '9+' : '$count',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class DemoModeBanner extends StatelessWidget {
  const DemoModeBanner({super.key, required this.title, required this.message});

  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: <Color>[Color(0xFFF3FBF6), Color(0xFFFFFFFF)],
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: kBorder),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: kPrimarySoft,
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.rocket_launch_rounded, color: kPrimary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(title, style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(message, style: Theme.of(context).textTheme.bodyMedium),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _HomeShortcutCard extends StatelessWidget {
  const _HomeShortcutCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: kBorder),
          ),
          child: Row(
            children: <Widget>[
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: kPrimarySoft,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: kPrimary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(title, style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded),
            ],
          ),
        ),
      ),
    );
  }
}

class _PinnedSearchBarDelegate extends SliverPersistentHeaderDelegate {
  const _PinnedSearchBarDelegate({required this.child});

  final Widget child;

  @override
  double get minExtent => 76;

  @override
  double get maxExtent => 76;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return Container(
      color: const Color(0xFFF6FAF7),
      alignment: Alignment.center,
      child: child,
    );
  }

  @override
  bool shouldRebuild(covariant _PinnedSearchBarDelegate oldDelegate) {
    return oldDelegate.child != child;
  }
}

class _PromoBox extends StatelessWidget {
  const _PromoBox({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: Color(0xFFB91C1C),
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class OrderStatusCard extends StatelessWidget {
  const OrderStatusCard({
    super.key,
    required this.status,
    required this.title,
    required this.subtitle,
    required this.total,
    required this.schedule,
    this.order,
    this.embedded = false,
  });

  final String status;
  final String title;
  final String subtitle;
  final String total;
  final String schedule;
  final OrderRecord? order;
  final bool embedded;

  @override
  Widget build(BuildContext context) {
    final AppStatusStyle statusStyle = _orderStatusStyle(status);
    final String? orderCode = order == null ? null : _buildOrderCode(order!.id);
    final Widget content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Row(
          children: <Widget>[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: statusStyle.background,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                status,
                style: TextStyle(
                  color: statusStyle.foreground,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const Spacer(),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(total, style: Theme.of(context).textTheme.titleMedium),
                if (orderCode != null) ...<Widget>[
                  const SizedBox(height: 4),
                  Text(orderCode, style: Theme.of(context).textTheme.bodySmall),
                ],
              ],
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(title, style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6),
        Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
        const SizedBox(height: 10),
        Row(
          children: <Widget>[
            const Icon(Icons.calendar_today_rounded, size: 16, color: kMuted),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                schedule,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ],
        ),
        if (order != null) ...<Widget>[
          const SizedBox(height: 10),
          Row(
            children: <Widget>[
              const Icon(
                Icons.account_balance_wallet_outlined,
                size: 16,
                color: kMuted,
              ),
              const SizedBox(width: 8),
              _PaymentStatusPill(status: order!.paymentStatus),
              if (order!.remainingPayment > 0) ...<Widget>[
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Sisa ${formatRupiah(order!.remainingPayment)}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ),
              ] else
                Expanded(
                  child: Text(
                    '${order!.paymentMethodLabel} • lunas penuh',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ),
            ],
          ),
        ],
      ],
    );
    if (embedded) {
      return content;
    }
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap:
          order == null
              ? null
              : () {
                showOrderDetailsSheet(
                  context,
                  order: order!,
                  title: title,
                  subtitle: subtitle,
                  footer: _BuyerOrderActionFooter(order: order!),
                );
              },
      child: Ink(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: kBorder),
        ),
        child: Column(
          children: <Widget>[
            content,
            if (order != null) ...<Widget>[
              const SizedBox(height: 12),
              Row(
                children: <Widget>[
                  Text(
                    'Lihat rincian invoice',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const Spacer(),
                  const Icon(Icons.chevron_right_rounded, color: kMuted),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _BuyerCancelOrderFooter extends StatelessWidget {
  const _BuyerCancelOrderFooter({required this.order});

  final OrderRecord order;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            'Butuh ubah rencana?',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 8),
          Text(
            order.amountPaid > 0
                ? 'Pesanan ini masih bisa dibatalkan sebelum masuk tahap pengiriman. DP yang sudah dibayar tidak dapat dikembalikan.'
                : 'Pesanan ini masih bisa dibatalkan sebelum masuk tahap pengiriman.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () async {
                final String? reason = await showModalBottomSheet<String>(
                  context: context,
                  backgroundColor: Colors.white,
                  isScrollControlled: true,
                  builder: (BuildContext context) {
                    return _CancelOrderReasonSheet(order: order);
                  },
                );
                if (reason == null || !context.mounted) {
                  return;
                }
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Pesanan berhasil dibatalkan.')),
                );
              },
              icon: const Icon(Icons.close_rounded),
              label: const Text('Batalkan pesanan'),
            ),
          ),
        ],
      ),
    );
  }
}

class _BuyerOrderActionFooter extends StatelessWidget {
  const _BuyerOrderActionFooter({required this.order});

  final OrderRecord order;

  @override
  Widget build(BuildContext context) {
    final bool canCancel = _canBuyerCancelOrder(order);
    final bool canPayRemaining =
        order.paymentStatus != 'Lunas' && order.remainingPayment > 0;
    if (!canCancel && !canPayRemaining) {
      return const SizedBox.shrink();
    }
    return Column(
      children: <Widget>[
        if (canPayRemaining)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: kBorder),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Sisa pembayaran',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 8),
                _PaymentStatusPill(status: order.paymentStatus),
                const SizedBox(height: 10),
                Text(
                  'Lunasi sisa ${formatRupiah(order.remainingPayment)} agar pembayaran pesanan tercatat penuh.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () async {
                      final bool success = await _showMockQrisPaymentPage(
                        context,
                        vendorName: order.vendorName,
                        menuName: order.compactMenuLabel,
                        scheduleLabel: order.scheduleLabel,
                        totalPrice: order.remainingPayment,
                        paymentStage: 'Lunasi sisa pembayaran',
                      );
                      if (!context.mounted || !success) {
                        return;
                      }
                      await OrderRepository.completePayment(orderId: order.id);
                      if (!context.mounted) {
                        return;
                      }
                      Navigator.of(context).pop();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Pelunasan berhasil tercatat.'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.qr_code_2_rounded),
                    style: FilledButton.styleFrom(
                      backgroundColor: kPrimary,
                      minimumSize: const Size.fromHeight(50),
                    ),
                    label: const Text('Lunasi sekarang'),
                  ),
                ),
              ],
            ),
          ),
        if (canCancel) ...<Widget>[
          if (canPayRemaining) const SizedBox(height: 16),
          _BuyerCancelOrderFooter(order: order),
        ],
      ],
    );
  }
}

class _CancellationPolicyCard extends StatelessWidget {
  const _CancellationPolicyCard({required this.title, required this.lines});

  final String title;
  final List<String> lines;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFBEB),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFFDE68A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.info_outline_rounded,
                  color: Color(0xFFB45309),
                  size: 18,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: const Color(0xFF92400E),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...lines.map(
            (String line) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Icon(
                      Icons.circle,
                      size: 6,
                      color: Color(0xFFB45309),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      line,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: const Color(0xFF92400E),
                        height: 1.45,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

Future<void> showOrderDetailsSheet(
  BuildContext context, {
  required OrderRecord order,
  required String title,
  required String subtitle,
  Widget? footer,
  bool stackedDetails = false,
}) {
  final int unitPrice =
      order.quantity == 0 ? 0 : order.totalPrice ~/ order.quantity;
  final AppStatusStyle statusStyle = _orderStatusStyle(order.status);
  final List<_OrderTrackingStepData> trackingSteps = _buildOrderTrackingSteps(
    order,
  );
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (BuildContext context) {
      return DraggableScrollableSheet(
        initialChildSize: 0.58,
        minChildSize: 0.38,
        maxChildSize: 0.85,
        expand: false,
        builder: (BuildContext context, ScrollController controller) {
          return Container(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
            ),
            child: ListView(
              controller: controller,
              children: <Widget>[
                Center(
                  child: Container(
                    width: 48,
                    height: 5,
                    decoration: BoxDecoration(
                      color: const Color(0xFFD7DEE7),
                      borderRadius: BorderRadius.circular(999),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                        title,
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: statusStyle.background,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        order.status,
                        style: TextStyle(
                          color: statusStyle.foreground,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  _buildOrderCode(order.id),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(height: 4),
                Text(subtitle, style: Theme.of(context).textTheme.bodyLarge),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: kBorder),
                  ),
                  child: Column(
                    children: <Widget>[
                      _InvoiceRow(
                        label: 'Vendor',
                        value: order.vendorName,
                        stacked: stackedDetails,
                      ),
                      const SizedBox(height: 10),
                      _InvoiceRow(
                        label:
                            order.lineItems.length > 1
                                ? 'Ringkasan pesanan'
                                : 'Nama paket',
                        value: order.compactMenuLabel,
                        stacked: stackedDetails,
                      ),
                      const SizedBox(height: 10),
                      _InvoiceRow(
                        label: 'Harga satuan',
                        value: formatRupiah(unitPrice),
                        stacked: stackedDetails,
                      ),
                      const SizedBox(height: 10),
                      _InvoiceRow(
                        label: 'Jumlah paket',
                        value: '${order.totalUnits} unit',
                        stacked: stackedDetails,
                      ),
                      const SizedBox(height: 10),
                      _InvoiceRow(
                        label: 'Metode bayar',
                        value: order.paymentMethodLabel,
                        stacked: stackedDetails,
                      ),
                      const SizedBox(height: 10),
                      _InvoiceRow(
                        label: 'DP dibayar',
                        value: formatRupiah(order.amountPaid),
                        stacked: stackedDetails,
                      ),
                      const SizedBox(height: 10),
                      _InvoiceRow(
                        label: 'Sisa pelunasan',
                        value: formatRupiah(order.remainingPayment),
                        stacked: stackedDetails,
                      ),
                      const SizedBox(height: 10),
                      _InvoiceRow(
                        label: 'Status bayar',
                        value: order.paymentStatus,
                        stacked: stackedDetails,
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: _PaymentSummaryCard(
                              label: 'DP dibayar',
                              value: formatRupiah(order.amountPaid),
                              accent: kPrimaryDark,
                              background: const Color(0xFFF0FDF4),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _PaymentSummaryCard(
                              label: 'Sisa',
                              value: formatRupiah(order.remainingPayment),
                              accent: const Color(0xFFB45309),
                              background: const Color(0xFFFFFBEB),
                            ),
                          ),
                        ],
                      ),
                      if (order.lineItems.isNotEmpty) ...<Widget>[
                        const Divider(height: 24),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Rincian item',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        ),
                        const SizedBox(height: 12),
                        ...order.lineItems.map(
                          (OrderLineItem item) => Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: kBorder),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    item.name,
                                    style:
                                        Theme.of(context).textTheme.titleSmall,
                                  ),
                                  const SizedBox(height: 6),
                                  _InvoiceRow(
                                    label: 'Per item',
                                    value: formatRupiah(item.unitPrice),
                                    stacked: stackedDetails,
                                  ),
                                  const SizedBox(height: 6),
                                  _InvoiceRow(
                                    label: 'Jumlah',
                                    value: '${item.quantity} unit',
                                    stacked: stackedDetails,
                                  ),
                                  const SizedBox(height: 6),
                                  _InvoiceRow(
                                    label: 'Subtotal',
                                    value: formatRupiah(item.subtotal),
                                    emphasized: true,
                                    stacked: stackedDetails,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ] else ...<Widget>[
                        const Divider(height: 24),
                        _InvoiceRow(
                          label: 'Subtotal',
                          value:
                              '${formatRupiah(unitPrice)} x ${order.quantity}',
                          stacked: stackedDetails,
                        ),
                      ],
                      const SizedBox(height: 10),
                      _InvoiceRow(
                        label: 'Total invoice',
                        value: formatRupiah(order.totalPrice),
                        emphasized: true,
                        stacked: stackedDetails,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: kBorder),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Tracking pesanan',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 14),
                      ...trackingSteps.map(
                        (_OrderTrackingStepData step) => Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: _OrderTrackingTile(
                            step: step,
                            isLast: identical(step, trackingSteps.last),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: kBorder),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Detail pesanan',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 12),
                      _InvoiceRow(
                        label: 'Jadwal',
                        value: order.scheduleLabel,
                        stacked: stackedDetails,
                      ),
                      if (order.deliveryAddress.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 10),
                        _InvoiceRow(
                          label: 'Alamat kirim',
                          value: order.deliveryAddress,
                          stacked: stackedDetails,
                        ),
                      ],
                      const SizedBox(height: 10),
                      _InvoiceRow(
                        label: 'Pembeli',
                        value: order.buyerName,
                        stacked: stackedDetails,
                      ),
                      const SizedBox(height: 10),
                      _InvoiceRow(
                        label: 'Pembayaran',
                        value:
                            '${order.paymentMethodLabel} • ${order.paymentStatus}',
                        stacked: stackedDetails,
                      ),
                      if (order.notes.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 10),
                        _InvoiceRow(
                          label: 'Catatan',
                          value: order.notes,
                          stacked: stackedDetails,
                        ),
                      ],
                      if (order.cancelReason.isNotEmpty) ...<Widget>[
                        const SizedBox(height: 10),
                        _InvoiceRow(
                          label: 'Alasan batal',
                          value: order.cancelReason,
                          stacked: stackedDetails,
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                ValueListenableBuilder<int>(
                  valueListenable: PaymentTransactionRepository.updates,
                  builder: (BuildContext context, int _, __) {
                    final List<PaymentTransactionRecord> payments =
                        PaymentTransactionRepository.localTransactionsForOrder(
                          order.id,
                        );
                    if (payments.isEmpty) {
                      return const SizedBox.shrink();
                    }
                    return Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: kBorder),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Riwayat pembayaran',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 12),
                          ...payments.map(
                            (PaymentTransactionRecord payment) => Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: Container(
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF8FAFC),
                                  borderRadius: BorderRadius.circular(18),
                                  border: Border.all(color: kBorder),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: Text(
                                            payment.stageLabel,
                                            style:
                                                Theme.of(
                                                  context,
                                                ).textTheme.titleMedium,
                                          ),
                                        ),
                                        Text(
                                          formatRupiah(payment.amount),
                                          style: Theme.of(context)
                                              .textTheme
                                              .titleMedium
                                              ?.copyWith(color: kPrimaryDark),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      '${payment.methodLabel} • ${payment.status}',
                                      style:
                                          Theme.of(
                                            context,
                                          ).textTheme.bodyMedium,
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      payment.gatewayReference.isEmpty
                                          ? payment.createdAtLabel
                                          : '${payment.createdAtLabel} • ${payment.gatewayReference}',
                                      style:
                                          Theme.of(context).textTheme.bodySmall,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                if (footer != null) ...<Widget>[
                  const SizedBox(height: 16),
                  footer,
                ],
              ],
            ),
          );
        },
      );
    },
  );
}

class _InvoiceRow extends StatelessWidget {
  const _InvoiceRow({
    required this.label,
    required this.value,
    this.emphasized = false,
    this.stacked = false,
  });

  final String label;
  final String value;
  final bool emphasized;
  final bool stacked;

  @override
  Widget build(BuildContext context) {
    final TextStyle? valueStyle =
        emphasized
            ? Theme.of(
              context,
            ).textTheme.titleMedium?.copyWith(color: kPrimaryDark)
            : Theme.of(context).textTheme.bodyLarge;
    if (stacked) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label, style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 4),
          Text(value, style: valueStyle),
        ],
      );
    }
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Expanded(
          child: Text(label, style: Theme.of(context).textTheme.bodyMedium),
        ),
        const SizedBox(width: 12),
        Flexible(
          child: Text(value, textAlign: TextAlign.right, style: valueStyle),
        ),
      ],
    );
  }
}

class _PaymentStatusPill extends StatelessWidget {
  const _PaymentStatusPill({required this.status});

  final String status;

  @override
  Widget build(BuildContext context) {
    final bool isPaidOff = status == 'Lunas';
    final Color background =
        isPaidOff ? const Color(0xFFDFF7E7) : const Color(0xFFFFF4DB);
    final Color foreground =
        isPaidOff ? const Color(0xFF166534) : const Color(0xFFB45309);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        status,
        style: TextStyle(color: foreground, fontWeight: FontWeight.w700),
      ),
    );
  }
}

class _PaymentSummaryCard extends StatelessWidget {
  const _PaymentSummaryCard({
    required this.label,
    required this.value,
    required this.accent,
    required this.background,
  });

  final String label;
  final String value;
  final Color accent;
  final Color background;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label, style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 6),
          Text(
            value,
            style: Theme.of(
              context,
            ).textTheme.titleMedium?.copyWith(color: accent),
          ),
        ],
      ),
    );
  }
}

class _OrderTrackingTile extends StatelessWidget {
  const _OrderTrackingTile({required this.step, this.isLast = false});

  final _OrderTrackingStepData step;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    final bool isCurrent = step.state == 'current';
    final bool isDone = step.state == 'done';
    final bool isCancelled = step.state == 'cancelled';
    final Color indicatorColor =
        isCancelled
            ? const Color(0xFFB91C1C)
            : isDone || isCurrent
            ? kPrimary
            : const Color(0xFFCBD5E1);
    final Color surfaceColor =
        isCancelled
            ? const Color(0xFFFFF1F2)
            : isCurrent
            ? const Color(0xFFF0FDF4)
            : const Color(0xFFF8FAFC);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Column(
          children: <Widget>[
            Container(
              width: 18,
              height: 18,
              decoration: BoxDecoration(
                color: indicatorColor,
                shape: BoxShape.circle,
              ),
              child: Icon(
                isCancelled
                    ? Icons.close_rounded
                    : isDone
                    ? Icons.check_rounded
                    : Icons.circle,
                size: isCurrent ? 8 : 12,
                color: Colors.white,
              ),
            ),
            if (!isLast)
              Container(width: 2, height: 46, color: const Color(0xFFE2E8F0)),
          ],
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: surfaceColor,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color:
                    isCurrent
                        ? const Color(0xFFBBF7D0)
                        : isCancelled
                        ? const Color(0xFFFECDD3)
                        : kBorder,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                        step.title,
                        style: Theme.of(
                          context,
                        ).textTheme.titleMedium?.copyWith(
                          color:
                              isCancelled
                                  ? const Color(0xFFB91C1C)
                                  : (isCurrent ? kPrimaryDark : kText),
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        step.timeLabel,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  step.subtitle,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _CancelOrderReasonSheet extends StatefulWidget {
  const _CancelOrderReasonSheet({required this.order});

  final OrderRecord order;

  @override
  State<_CancelOrderReasonSheet> createState() =>
      _CancelOrderReasonSheetState();
}

class _CancelOrderReasonSheetState extends State<_CancelOrderReasonSheet> {
  final TextEditingController _controller = TextEditingController();
  bool _isSubmitting = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final String reason = _controller.text.trim();
    if (reason.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Isi alasan pembatalan dulu ya.')),
      );
      return;
    }
    setState(() {
      _isSubmitting = true;
    });
    await OrderRepository.updateOrderStatus(
      orderId: widget.order.id,
      status: 'Dibatalkan',
      cancelReason: reason,
    );
    if (!mounted) {
      return;
    }
    Navigator.of(context).pop(reason);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        20,
        20,
        MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            'Batalkan pesanan',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          Text(
            'Tuliskan alasan supaya pesanan kamu tercatat dengan jelas.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _controller,
            minLines: 3,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'Alasan pembatalan',
              hintText: 'Contoh: acara diundur atau jumlah pax berubah',
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _isSubmitting ? null : _submit,
            icon:
                _isSubmitting
                    ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                    : const Icon(Icons.close_rounded),
            label: Text(_isSubmitting ? 'Membatalkan...' : 'Konfirmasi batal'),
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFB91C1C),
              minimumSize: const Size.fromHeight(52),
            ),
          ),
        ],
      ),
    );
  }
}

class _OrderSuccessPage extends StatelessWidget {
  const _OrderSuccessPage({required this.order});

  final OrderRecord order;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackground,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 28),
          child: Column(
            children: <Widget>[
              const Spacer(),
              Container(
                width: 112,
                height: 112,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: <Color>[Color(0xFFDFF7E7), Color(0xFFF0FDF4)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(34),
                  boxShadow: const <BoxShadow>[
                    BoxShadow(
                      color: Color(0x14000000),
                      blurRadius: 24,
                      offset: Offset(0, 12),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.check_circle_rounded,
                  color: kPrimaryDark,
                  size: 58,
                ),
              ),
              const SizedBox(height: 22),
              Text(
                order.paymentStatus == 'Lunas'
                    ? 'Pelunasan berhasil'
                    : 'DP berhasil dibayar',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              Text(
                order.paymentStatus == 'Lunas'
                    ? 'Invoice ${_buildOrderCode(order.id)} sudah tercatat lunas. Kamu bisa pantau statusnya dari tab Pesanan.'
                    : 'Invoice ${_buildOrderCode(order.id)} sudah masuk dengan status DP 50%. Kamu bisa pantau status dan melunasi sisa pembayaran dari tab Pesanan.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              const SizedBox(height: 20),
              _PaymentStatusPill(status: order.paymentStatus),
              const SizedBox(height: 16),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: kBorder),
                ),
                child: Column(
                  children: <Widget>[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: kBorder),
                      ),
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: 42,
                            height: 42,
                            decoration: BoxDecoration(
                              color: kPrimarySoft,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: const Icon(
                              Icons.receipt_long_rounded,
                              color: kPrimaryDark,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  'Status sekarang',
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  order.status,
                                  style:
                                      Theme.of(context).textTheme.titleMedium,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    _InvoiceRow(label: 'Vendor', value: order.vendorName),
                    const SizedBox(height: 10),
                    _InvoiceRow(label: 'Menu', value: order.compactMenuLabel),
                    const SizedBox(height: 10),
                    _InvoiceRow(label: 'Jadwal', value: order.scheduleLabel),
                    const SizedBox(height: 10),
                    _InvoiceRow(
                      label: 'Total',
                      value: formatRupiah(order.totalPrice),
                      emphasized: true,
                    ),
                    const SizedBox(height: 10),
                    _InvoiceRow(
                      label: 'DP dibayar',
                      value: formatRupiah(order.amountPaid),
                    ),
                    if (order.remainingPayment > 0) ...<Widget>[
                      const SizedBox(height: 10),
                      _InvoiceRow(
                        label: 'Sisa pelunasan',
                        value: formatRupiah(order.remainingPayment),
                      ),
                    ],
                  ],
                ),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () {
                    showOrderDetailsSheet(
                      context,
                      order: order,
                      title: order.vendorName,
                      subtitle:
                          '${order.compactMenuLabel} • ${order.totalUnits} unit',
                    );
                  },
                  child: const Text('Lihat ringkasan invoice'),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () {
                    _buyerOpenOrdersSignal.value++;
                    Navigator.of(
                      context,
                    ).popUntil((Route<dynamic> route) => route.isFirst);
                  },
                  style: FilledButton.styleFrom(
                    backgroundColor: kPrimary,
                    minimumSize: const Size.fromHeight(52),
                  ),
                  child: const Text('Selesai'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StoreStatusChip extends StatelessWidget {
  const _StoreStatusChip({required this.isOpen});

  final bool isOpen;

  @override
  Widget build(BuildContext context) {
    final Color background =
        isOpen ? const Color(0xFFDFF7E7) : const Color(0xFFFEE2E2);
    final Color foreground =
        isOpen ? const Color(0xFF166534) : const Color(0xFFB91C1C);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        isOpen ? 'Buka' : 'Tutup',
        style: TextStyle(color: foreground, fontWeight: FontWeight.w700),
      ),
    );
  }
}

List<AppNotificationItem> _buildBuyerNotifications(List<Vendor> vendors) {
  final List<AppNotificationItem> items = <AppNotificationItem>[];

  for (final OrderRecord order in OrderRepository.localBuyerOrders(
    BuyerProfileRepository.buyerId,
  )) {
    if (order.status == 'Diproses') {
      items.add(
        AppNotificationItem(
          title: 'Pesanan sedang diproses',
          message:
              '${order.vendorName} sedang menyiapkan ${order.compactMenuLabel}.',
          timeLabel: order.scheduleLabel,
          icon: Icons.receipt_long_rounded,
          accent: const Color(0xFFB45309),
          category: AppNotificationCategory.orders,
          route: AppNotificationRoute.orders,
        ),
      );
    } else if (order.status == 'Dikirim') {
      items.add(
        AppNotificationItem(
          title: 'Pesanan sedang dikirim',
          message:
              '${order.compactMenuLabel} dari ${order.vendorName} sedang menuju lokasi.',
          timeLabel: order.scheduleLabel,
          icon: Icons.local_shipping_rounded,
          accent: const Color(0xFF2563EB),
          category: AppNotificationCategory.orders,
          route: AppNotificationRoute.orders,
        ),
      );
    }
  }

  for (final CustomMenuRequest request
      in CustomMenuRequestRepository.localBuyerRequests(
        BuyerProfileRepository.buyerId,
      )) {
    if (request.status == 'Dijawab') {
      items.add(
        AppNotificationItem(
          title: 'Penawaran custom siap ditinjau',
          message:
              '${request.vendorName} membalas ${request.title} dengan ${request.quotedPriceLabel.isEmpty ? 'penawaran baru' : request.quotedPriceLabel}.',
          timeLabel: request.createdAtLabel,
          icon: Icons.fact_check_rounded,
          accent: kPrimary,
          category: AppNotificationCategory.request,
          route: AppNotificationRoute.orders,
        ),
      );
    }
  }

  for (final Vendor vendor in vendors.take(5)) {
    if (ChatRepository.localHasUnreadMessage(
      vendorId: vendor.id,
      currentSenderId: BuyerProfileRepository.buyerId,
    )) {
      final ChatMessage? latest = ChatRepository.localLatestMessage(
        vendorId: vendor.id,
        currentSenderId: BuyerProfileRepository.buyerId,
      );
      if (latest != null) {
        items.add(
          AppNotificationItem(
            title: 'Chat baru dari ${vendor.name}',
            message: chatPreviewText(latest.text),
            timeLabel: latest.time.isEmpty ? 'Baru saja' : latest.time,
            icon: Icons.chat_bubble_rounded,
            accent: const Color(0xFF1D4ED8),
            category: AppNotificationCategory.chat,
            route: AppNotificationRoute.chat,
          ),
        );
      }
    }
  }

  return items.take(6).toList();
}

class AppNotificationItem {
  const AppNotificationItem({
    required this.title,
    required this.message,
    required this.timeLabel,
    required this.icon,
    required this.accent,
    required this.category,
    required this.route,
  });

  final String title;
  final String message;
  final String timeLabel;
  final IconData icon;
  final Color accent;
  final AppNotificationCategory category;
  final AppNotificationRoute route;
}

enum AppNotificationRoute { orders, chat }

enum AppNotificationCategory { orders, chat, request }

bool _canBuyerCancelOrder(OrderRecord order) {
  return order.status == 'Diproses';
}

int _calculateDownPayment(int totalPrice) {
  return (totalPrice / 2).ceil();
}

class _OrderTrackingStepData {
  const _OrderTrackingStepData({
    required this.title,
    required this.subtitle,
    required this.state,
    this.timeLabel = '',
  });

  final String title;
  final String subtitle;
  final String state;
  final String timeLabel;
}

List<_OrderTrackingStepData> _buildOrderTrackingSteps(OrderRecord order) {
  if (order.status == 'Dibatalkan') {
    return <_OrderTrackingStepData>[
      const _OrderTrackingStepData(
        title: 'Pesanan dibuat',
        subtitle: 'Invoice sudah tercatat di aplikasi.',
        state: 'done',
        timeLabel: 'Baru saja',
      ),
      _OrderTrackingStepData(
        title: 'Pesanan dibatalkan',
        subtitle:
            order.cancelReason.isEmpty
                ? 'Pesanan dibatalkan oleh pembeli.'
                : order.cancelReason,
        state: 'cancelled',
        timeLabel: 'Status terakhir',
      ),
    ];
  }
  final List<String> statuses = <String>['Diproses', 'Dikirim', 'Selesai'];
  final Map<String, String> descriptions = <String, String>{
    'Diproses': 'Pesanan sedang disiapkan oleh penjual.',
    'Dikirim': 'Pesanan sedang menuju alamat pengantaran.',
    'Selesai': 'Pesanan sudah selesai diterima.',
  };
  final int currentIndex = statuses.indexOf(order.status);
  return statuses.asMap().entries.map((MapEntry<int, String> entry) {
    final int index = entry.key;
    final String status = entry.value;
    final String state;
    if (currentIndex == -1) {
      state = 'upcoming';
    } else if (index < currentIndex) {
      state = 'done';
    } else if (index == currentIndex) {
      state = 'current';
    } else {
      state = 'upcoming';
    }
    return _OrderTrackingStepData(
      title: status,
      subtitle: descriptions[status] ?? '',
      state: state,
      timeLabel:
          index <= currentIndex && currentIndex != -1
              ? order.scheduleLabel
              : 'Menunggu update',
    );
  }).toList();
}

bool _isBuyerActiveOrder(OrderRecord order) {
  return switch (order.status) {
    'Diproses' || 'Dikirim' => true,
    _ => false,
  };
}

String _buildOrderCode(String id) {
  final String compact =
      id.replaceAll(RegExp(r'[^A-Za-z0-9]'), '').toUpperCase();
  final String suffix =
      compact.length <= 6 ? compact : compact.substring(compact.length - 6);
  return 'INV-$suffix';
}

class AppStatusStyle {
  const AppStatusStyle({required this.background, required this.foreground});

  final Color background;
  final Color foreground;
}

AppStatusStyle _orderStatusStyle(String status) {
  switch (status) {
    case 'Diproses':
      return const AppStatusStyle(
        background: Color(0xFFE0F2FE),
        foreground: Color(0xFF0369A1),
      );
    case 'Dikirim':
      return const AppStatusStyle(
        background: Color(0xFFE8EEFF),
        foreground: Color(0xFF1D4ED8),
      );
    case 'Selesai':
      return const AppStatusStyle(
        background: Color(0xFFDFF7E7),
        foreground: Color(0xFF166534),
      );
    case 'Dibatalkan':
      return const AppStatusStyle(
        background: Color(0xFFFEE2E2),
        foreground: Color(0xFFB91C1C),
      );
    default:
      return const AppStatusStyle(
        background: kPrimarySoft,
        foreground: kPrimaryDark,
      );
  }
}

String formatRupiah(int value) {
  final String raw = value.toString();
  final StringBuffer buffer = StringBuffer();
  for (int i = 0; i < raw.length; i++) {
    final int reverseIndex = raw.length - i;
    buffer.write(raw[i]);
    if (reverseIndex > 1 && reverseIndex % 3 == 1) {
      buffer.write('.');
    }
  }
  return 'Rp$buffer';
}

int _extractPrice(String label) {
  final String lower = label.toLowerCase().trim();
  final RegExpMatch? millionMatch = RegExp(
    r'(\d+(?:[.,]\d+)?)\s*(jt|juta)',
  ).firstMatch(lower);
  if (millionMatch != null) {
    final double? parsed = double.tryParse(
      millionMatch.group(1)!.replaceAll(',', '.'),
    );
    if (parsed != null) {
      return (parsed * 1000000).round();
    }
  }
  final RegExpMatch? thousandMatch = RegExp(
    r'(\d+(?:[.,]\d+)?)\s*(rb|ribu|k)\b',
  ).firstMatch(lower);
  if (thousandMatch != null) {
    final double? parsed = double.tryParse(
      thousandMatch.group(1)!.replaceAll(',', '.'),
    );
    if (parsed != null) {
      return (parsed * 1000).round();
    }
  }
  final String digitsOnly = label.replaceAll(RegExp(r'[^0-9]'), '');
  if (digitsOnly.isEmpty) {
    return 0;
  }
  return int.tryParse(digitsOnly) ?? 0;
}

Future<BitmapDescriptor> _buildSingleMarker() async {
  const double size = 120;
  final ui.PictureRecorder recorder = ui.PictureRecorder();
  final Canvas canvas = Canvas(recorder);
  final Paint shadowPaint = Paint()..color = const Color(0x22000000);
  canvas.drawCircle(const Offset(size / 2, size / 2 + 8), 34, shadowPaint);

  final Paint fillPaint = Paint()..color = Colors.white;
  canvas.drawCircle(const Offset(size / 2, size / 2), 34, fillPaint);

  final Paint borderPaint =
      Paint()
        ..color = kPrimary
        ..style = PaintingStyle.stroke
        ..strokeWidth = 8;
  canvas.drawCircle(const Offset(size / 2, size / 2), 34, borderPaint);

  final TextPainter painter = TextPainter(textDirection: TextDirection.ltr);
  painter.text = const TextSpan(
    text: 'A',
    style: TextStyle(
      color: kPrimaryDark,
      fontWeight: FontWeight.w800,
      fontSize: 34,
    ),
  );
  painter.layout();
  painter.paint(
    canvas,
    Offset((size - painter.width) / 2, (size - painter.height) / 2 - 2),
  );

  final ui.Image image = await recorder.endRecording().toImage(
    size.toInt(),
    size.toInt(),
  );
  final ByteData? data = await image.toByteData(format: ui.ImageByteFormat.png);
  return BitmapDescriptor.bytes(data!.buffer.asUint8List());
}

Future<BitmapDescriptor> _buildClusterMarker(int count) async {
  const double size = 140;
  final ui.PictureRecorder recorder = ui.PictureRecorder();
  final Canvas canvas = Canvas(recorder);
  final Paint shadowPaint = Paint()..color = const Color(0x22000000);
  canvas.drawCircle(const Offset(size / 2, size / 2 + 8), 38, shadowPaint);

  final Paint fillPaint = Paint()..color = kPrimary;
  canvas.drawCircle(const Offset(size / 2, size / 2), 38, fillPaint);

  final TextPainter painter = TextPainter(textDirection: TextDirection.ltr);
  painter.text = TextSpan(
    text: '$count',
    style: const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w800,
      fontSize: 30,
    ),
  );
  painter.layout();
  painter.paint(
    canvas,
    Offset((size - painter.width) / 2, (size - painter.height) / 2),
  );

  final ui.Image image = await recorder.endRecording().toImage(
    size.toInt(),
    size.toInt(),
  );
  final ByteData? data = await image.toByteData(format: ui.ImageByteFormat.png);
  return BitmapDescriptor.bytes(data!.buffer.asUint8List());
}
