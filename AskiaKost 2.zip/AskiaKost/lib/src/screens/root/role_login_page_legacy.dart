import 'package:flutter/material.dart';

import '../../config/app_visibility_flags.dart';
import '../../models/app_models.dart';
import '../../state/app_session_controller.dart';
import '../../theme/app_theme.dart';

class RoleLoginPage extends StatefulWidget {
  const RoleLoginPage({
    super.key,
    required this.sessionController,
  });

  final AppSessionController sessionController;

  @override
  State<RoleLoginPage> createState() => _RoleLoginPageState();
}

class _RoleLoginPageState extends State<RoleLoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void _applyDemoPreset(AppMode mode) {
    setState(() {
      _emailController.text = switch (mode) {
        AppMode.buyer => 'buyer.demo@askia.app',
        AppMode.seller => 'seller.demo@askia.app',
        AppMode.admin => 'admin.demo@askia.app',
      };
      _passwordController.text = 'askia12345';
    });
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit(AppMode mode) async {
    await widget.sessionController.loginAs(
      mode: mode,
      email: _emailController.text,
      password: _passwordController.text,
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.sessionController,
      builder: (BuildContext context, _) {
        return Scaffold(
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(24, 28, 24, 32),
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Container(
                      width: 54,
                      height: 54,
                      decoration: BoxDecoration(
                        color: kPrimarySoft,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: const Icon(
                        Icons.restaurant_rounded,
                        color: kPrimaryDark,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Askia Catering',
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            color: kPrimaryDark,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text(
                          'Masuk sesuai kebutuhanmu',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 36),
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: <Color>[Color(0xFFFFFFFF), Color(0xFFF1FCF4)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: kBorder),
                    boxShadow: const <BoxShadow>[
                      BoxShadow(
                        color: Color(0x12000000),
                        blurRadius: 24,
                        offset: Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Satu aplikasi untuk pembeli dan penjual',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Cari vendor, atur toko, kelola pesanan, dan bangun alur katering online dalam satu aplikasi.',
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      const SizedBox(height: 14),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: const <Widget>[
                          _FeaturePill(label: 'Maps Vendor'),
                          _FeaturePill(label: 'Chat Realtime'),
                          _FeaturePill(label: 'Order Flow'),
                          _FeaturePill(label: 'Kelola Toko'),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                Text(
                  'Pilih mode masuk',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 10),
                Text(
                  'Masuk sebagai pembeli untuk mencari katering, atau sebagai penjual untuk mengelola toko dan pesanan.',
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                if (kShowInternalStatusBanners) ...<Widget>[
                  const SizedBox(height: 18),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF6FAF7),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: kBorder),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Icon(
                          widget.sessionController.firebaseReady
                              ? Icons.cloud_done_rounded
                              : Icons.cloud_off_rounded,
                          color: widget.sessionController.firebaseReady
                              ? kPrimary
                              : const Color(0xFFB45309),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            widget.sessionController.authStatus,
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 18),
                TextField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    hintText: 'contoh@askia.app',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Password',
                    hintText: 'Masukkan password akun kamu',
                  ),
                ),
                if (kShowDemoPresets) ...<Widget>[
                  const SizedBox(height: 14),
                  Text(
                    'Preset akun demo',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: <Widget>[
                      _DemoPresetChip(
                        label: 'Buyer Demo',
                        accent: kPrimary,
                        onTap: () => _applyDemoPreset(AppMode.buyer),
                      ),
                      _DemoPresetChip(
                        label: 'Seller Demo',
                        accent: const Color(0xFF1D4ED8),
                        onTap: () => _applyDemoPreset(AppMode.seller),
                      ),
                      _DemoPresetChip(
                        label: 'Admin Demo',
                        accent: const Color(0xFFB45309),
                        onTap: () => _applyDemoPreset(AppMode.admin),
                      ),
                    ],
                  ),
                ],
                const SizedBox(height: 28),
                _RoleCard(
                  icon: Icons.search_rounded,
                  title: 'Masuk sebagai Pembeli',
                  subtitle:
                      'Cari vendor, lihat toko, chat penjual, dan pesan paket.',
                  accent: kPrimary,
                  isBusy: widget.sessionController.isBusy,
                  onTap: () => _submit(AppMode.buyer),
                ),
                const SizedBox(height: 14),
                _RoleCard(
                  icon: Icons.storefront_rounded,
                  title: 'Masuk sebagai Penjual',
                  subtitle:
                      'Kelola menu, item satuan, pesanan masuk, dan chat pembeli.',
                  accent: const Color(0xFF1D4ED8),
                  isBusy: widget.sessionController.isBusy,
                  onTap: () => _submit(AppMode.seller),
                ),
                if (kShowAdminLoginOption) ...<Widget>[
                  const SizedBox(height: 14),
                  _RoleCard(
                    icon: Icons.admin_panel_settings_rounded,
                    title: 'Masuk sebagai Admin',
                    subtitle:
                        'Pantau vendor, menu, order, dan performa aplikasi dari satu dashboard.',
                    accent: const Color(0xFFB45309),
                    isBusy: widget.sessionController.isBusy,
                    onTap: () => _submit(AppMode.admin),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

class _RoleCard extends StatelessWidget {
  const _RoleCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.accent,
    required this.isBusy,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color accent;
  final bool isBusy;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(26),
      onTap: isBusy ? null : onTap,
      child: Ink(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: kBorder),
          boxShadow: const <BoxShadow>[
            BoxShadow(
              color: Color(0x10000000),
              blurRadius: 20,
              offset: Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: <Widget>[
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: accent.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Icon(icon, color: accent),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(title, style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 6),
                  Text(subtitle, style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
            isBusy
                ? SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: accent,
                    ),
                  )
                : Icon(Icons.arrow_forward_ios_rounded, size: 18, color: accent),
          ],
        ),
      ),
    );
  }
}

class _FeaturePill extends StatelessWidget {
  const _FeaturePill({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: kBorder),
      ),
      child: Text(label, style: Theme.of(context).textTheme.labelLarge),
    );
  }
}

class _DemoPresetChip extends StatelessWidget {
  const _DemoPresetChip({
    required this.label,
    required this.accent,
    required this.onTap,
  });

  final String label;
  final Color accent;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      onPressed: onTap,
      side: BorderSide(color: accent.withValues(alpha: 0.18)),
      avatar: Icon(Icons.bolt_rounded, size: 18, color: accent),
      backgroundColor: accent.withValues(alpha: 0.08),
      label: Text(
        label,
        style: Theme.of(
          context,
        ).textTheme.labelLarge?.copyWith(color: accent),
      ),
    );
  }
}
