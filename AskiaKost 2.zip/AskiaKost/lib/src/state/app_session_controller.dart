import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

import '../data/buyer_profile_repository.dart';
import '../data/seller_verification_repository.dart';
import '../data/vendor_cloud_repository.dart';
import '../models/app_models.dart';

class AppSessionController extends ChangeNotifier {
  AppMode? _activeMode;
  String? _activeEmail;
  bool _isBusy = false;
  bool _firebaseReady = false;
  String _authStatus =
      'Mode demo aktif. Tambahkan konfigurasi Firebase supaya login online bisa dipakai.';

  AppMode? get activeMode => _activeMode;
  String? get activeEmail => _activeEmail;
  bool get isBusy => _isBusy;
  bool get firebaseReady => _firebaseReady;
  String get authStatus => _authStatus;

  bool get isAuthenticated => _activeMode != null;

  Future<void> initializeFirebase() async {
    try {
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp();
      }
      _firebaseReady = true;
      _authStatus = 'Firebase aktif. Login akan tersimpan ke Auth dan Firestore.';
      await VendorCloudRepository.seedSampleVendors();
    } catch (error, stackTrace) {
      debugPrint('Askia Firebase init error: $error');
      debugPrintStack(stackTrace: stackTrace);
      _firebaseReady = false;
      _authStatus =
          'Mode demo aktif. Firebase belum siap: $error';
    }
    notifyListeners();
  }

  Future<void> loginAs({
    required AppMode mode,
    required String email,
    required String password,
  }) async {
    _isBusy = true;
    notifyListeners();

    final String normalizedEmail = email.trim().isEmpty
        ? (mode == AppMode.buyer
              ? 'buyer.demo@askia.app'
              : mode == AppMode.seller
              ? 'seller.demo@askia.app'
              : 'admin.demo@askia.app')
        : email.trim();
    final String normalizedPassword =
        password.isEmpty ? 'askia12345' : password;

    try {
      if (mode == AppMode.buyer) {
        BuyerProfileRepository.configureIdentity(
          buyerId: normalizedEmail,
          email: normalizedEmail,
        );
      }

      if (_firebaseReady) {
        try {
          final FirebaseAuth auth = FirebaseAuth.instance;
          UserCredential credential;
          try {
            credential = await auth
                .signInWithEmailAndPassword(
                  email: normalizedEmail,
                  password: normalizedPassword,
                )
                .timeout(const Duration(seconds: 25));
          } on FirebaseAuthException catch (error) {
            if (error.code == 'user-not-found' ||
                error.code == 'invalid-credential') {
              credential = await auth
                  .createUserWithEmailAndPassword(
                    email: normalizedEmail,
                    password: normalizedPassword,
                  )
                  .timeout(const Duration(seconds: 25));
            } else {
              rethrow;
            }
          }

          if (mode == AppMode.buyer) {
            BuyerProfileRepository.configureIdentity(
              buyerId: credential.user?.uid ?? normalizedEmail,
              email: normalizedEmail,
              displayName: credential.user?.displayName,
            );
          }

          _activeMode = mode;
          _activeEmail = normalizedEmail;
          _isBusy = false;
          notifyListeners();

          unawaited(
            _syncFirebaseSessionData(
              mode: mode,
              email: normalizedEmail,
              userId: credential.user?.uid ?? normalizedEmail,
            ),
          );
          _authStatus = 'Login Firebase aktif untuk $normalizedEmail.';
          return;
        } on TimeoutException catch (error, stackTrace) {
          debugPrint('Askia Firebase login timeout: $error');
          debugPrintStack(stackTrace: stackTrace);
          if (mode == AppMode.buyer &&
              FirebaseAuth.instance.currentUser == null &&
              normalizedEmail.trim().isEmpty) {
            BuyerProfileRepository.resetToDemoIdentity();
          }
          _authStatus =
              'Firebase aktif, tapi login di emulator masih timeout. Coba ulang, cek internet emulator, atau pakai emulator Google Play.';
        } catch (error, stackTrace) {
          debugPrint('Askia Firebase login error: $error');
          debugPrintStack(stackTrace: stackTrace);
          if (mode == AppMode.buyer &&
              FirebaseAuth.instance.currentUser == null &&
              normalizedEmail.trim().isEmpty) {
            BuyerProfileRepository.resetToDemoIdentity();
          }
          _authStatus =
              'Firebase aktif, tapi login belum berhasil: $error';
        }
      }

      _activeMode = mode;
      _activeEmail = normalizedEmail;
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  Future<void> registerAccount({
    required AppMode mode,
    required String name,
    required String email,
    required String phone,
    required String password,
  }) async {
    _isBusy = true;
    notifyListeners();

    final String normalizedName = name.trim();
    final String normalizedEmail = email.trim();
    final String normalizedPhone = phone.trim();
    final String normalizedPassword =
        password.trim().isEmpty ? 'askia12345' : password.trim();

    try {
      if (mode == AppMode.buyer) {
        await BuyerProfileRepository.ensureLoaded();
        final BuyerProfileData current = BuyerProfileRepository.current();
        BuyerProfileRepository.configureIdentity(
          buyerId: normalizedEmail,
          email: normalizedEmail,
          displayName: normalizedName,
        );
        await BuyerProfileRepository.save(
          BuyerProfileData(
            name: normalizedName,
            email: normalizedEmail,
            phone: normalizedPhone,
            primaryAddress: current.primaryAddress,
            secondaryAddress: current.secondaryAddress,
            preferenceSummary: current.preferenceSummary,
          ),
        );
      } else if (mode == AppMode.seller) {
        await SellerVerificationRepository.saveAccountBasics(
          ownerName: normalizedName,
          ownerEmail: normalizedEmail,
          ownerPhone: normalizedPhone,
        );
      }

      if (_firebaseReady) {
        final FirebaseAuth auth = FirebaseAuth.instance;
        UserCredential credential;
        try {
          credential = await auth
              .createUserWithEmailAndPassword(
                email: normalizedEmail,
                password: normalizedPassword,
              )
              .timeout(const Duration(seconds: 25));
        } on FirebaseAuthException catch (error) {
          if (error.code == 'email-already-in-use') {
            credential = await auth
                .signInWithEmailAndPassword(
                  email: normalizedEmail,
                  password: normalizedPassword,
                )
                .timeout(const Duration(seconds: 25));
          } else {
            rethrow;
          }
        }

        if (credential.user != null && normalizedName.isNotEmpty) {
          await credential.user!.updateDisplayName(normalizedName);
        }

        if (mode == AppMode.buyer) {
          BuyerProfileRepository.configureIdentity(
            buyerId: credential.user?.uid ?? normalizedEmail,
            email: normalizedEmail,
            displayName: normalizedName,
          );
        }

        _activeMode = mode;
        _activeEmail = normalizedEmail;
        _isBusy = false;
        notifyListeners();

        unawaited(
          _syncFirebaseSessionData(
            mode: mode,
            email: normalizedEmail,
            userId: credential.user?.uid ?? normalizedEmail,
            displayName: normalizedName,
            phone: normalizedPhone,
          ),
        );
        _authStatus = 'Akun ${mode.name} berhasil dibuat untuk $normalizedEmail.';
        return;
      }

      _activeMode = mode;
      _activeEmail = normalizedEmail;
      _authStatus =
          'Akun ${mode.name} tersimpan di mode lokal. Firebase akan dipakai saat sudah aktif penuh.';
    } catch (error, stackTrace) {
      debugPrint('Askia Firebase register error: $error');
      debugPrintStack(stackTrace: stackTrace);
      _authStatus = 'Pendaftaran belum berhasil: $error';
    } finally {
      _isBusy = false;
      notifyListeners();
    }
  }

  void switchMode(AppMode mode) {
    _activeMode = mode;
    notifyListeners();
  }

  Future<void> logout() async {
    if (_firebaseReady && Firebase.apps.isNotEmpty) {
      try {
        await FirebaseAuth.instance.signOut();
      } catch (_) {}
    }
    BuyerProfileRepository.resetToDemoIdentity();
    _activeMode = null;
    _activeEmail = null;
    notifyListeners();
  }

  Future<void> _syncFirebaseSessionData({
    required AppMode mode,
    required String email,
    required String userId,
    String? displayName,
    String? phone,
  }) async {
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .set(<String, Object?>{
            'email': email,
            'mode': mode.name,
            'displayName': displayName,
            'phone': phone,
            'updatedAt': FieldValue.serverTimestamp(),
          }, SetOptions(merge: true))
          .timeout(const Duration(seconds: 25));
      await VendorCloudRepository.seedSampleVendors().timeout(
        const Duration(seconds: 25),
      );
    } catch (error, stackTrace) {
      debugPrint('Askia Firebase session sync error: $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }
}
