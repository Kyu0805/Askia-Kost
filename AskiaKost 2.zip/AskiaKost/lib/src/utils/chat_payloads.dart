class CustomRequestChatPayload {
  const CustomRequestChatPayload({
    required this.requestId,
    required this.title,
    required this.targetPax,
    required this.budgetLabel,
    required this.description,
  });

  final String requestId;
  final String title;
  final int targetPax;
  final String budgetLabel;
  final String description;
}

class OfferChatPayload {
  const OfferChatPayload({
    required this.requestId,
    required this.title,
    required this.targetPax,
    required this.quotedPriceLabel,
    required this.sellerResponse,
  });

  final String requestId;
  final String title;
  final int targetPax;
  final String quotedPriceLabel;
  final String sellerResponse;
}

const String customRequestChatPrefix = '[ASKIA_REQUEST]';
const String offerChatPrefix = '[ASKIA_OFFER]';

String buildCustomRequestChatPayload({
  required String requestId,
  required String title,
  required String description,
  required int targetPax,
  required String budgetLabel,
}) {
  return '$customRequestChatPrefix\n$requestId\n$title\n$targetPax\n$budgetLabel\n$description';
}

CustomRequestChatPayload? tryParseCustomRequestChatPayload(String text) {
  if (!text.startsWith(customRequestChatPrefix)) {
    return null;
  }
  final List<String> lines = text.split('\n');
  if (lines.length >= 6) {
    return CustomRequestChatPayload(
      requestId: lines[1].trim(),
      title: lines[2].trim(),
      targetPax: int.tryParse(lines[3].trim()) ?? 0,
      budgetLabel: lines[4].trim(),
      description: lines.sublist(5).join('\n').trim(),
    );
  }
  if (lines.length >= 5) {
    return CustomRequestChatPayload(
      requestId: '',
      title: lines[1].trim(),
      targetPax: int.tryParse(lines[2].trim()) ?? 0,
      budgetLabel: lines[3].trim(),
      description: lines.sublist(4).join('\n').trim(),
    );
  }
  return null;
}

String buildOfferChatPayload({
  required String requestId,
  required String title,
  required int targetPax,
  required String quotedPriceLabel,
  required String sellerResponse,
}) {
  return '$offerChatPrefix\n$requestId\n$title\n$targetPax\n$quotedPriceLabel\n$sellerResponse';
}

OfferChatPayload? tryParseOfferChatPayload(String text) {
  if (!text.startsWith(offerChatPrefix)) {
    return null;
  }
  final List<String> lines = text.split('\n');
  if (lines.length < 5) {
    return null;
  }
  return OfferChatPayload(
    requestId: lines[1].trim(),
    title: lines[2].trim(),
    targetPax: int.tryParse(lines[3].trim()) ?? 0,
    quotedPriceLabel: lines[4].trim(),
    sellerResponse: lines.length >= 6
        ? lines.sublist(5).join('\n').trim()
        : '',
  );
}

String chatPreviewText(String text) {
  final CustomRequestChatPayload? request = tryParseCustomRequestChatPayload(text);
  if (request != null) {
    return 'Request menu: ${request.title} • ${request.targetPax} pax';
  }
  final OfferChatPayload? offer = tryParseOfferChatPayload(text);
  if (offer != null) {
    return 'Penawaran: ${offer.title} • ${offer.quotedPriceLabel}';
  }
  return text;
}
