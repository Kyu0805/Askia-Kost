import 'package:askia_kost_flutter/main.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('opens simplified role login from guest buyer flow', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const AskiaKostApp());
    await tester.pump(const Duration(milliseconds: 3600));
    await tester.pumpAndSettle();

    expect(find.text('Askia Kost'), findsWidgets);
    expect(find.text('Masuk'), findsOneWidget);

    await tester.tap(find.text('Masuk'));
    await tester.pumpAndSettle();

    expect(find.text('Masuk ke Askia Kost'), findsOneWidget);
    expect(find.text('Pembeli'), findsOneWidget);
    expect(find.text('Penjual'), findsOneWidget);
    expect(find.textContaining('Admin'), findsNothing);
  });
}
